@echo off
setlocal
chcp 65001 >nul
title SIEM Firewalls
cd /d "%~dp0"

if not exist "backend\.venv\Scripts\python.exe" (
  echo [ERRO] Ambiente nao instalado. Execute instalar.bat primeiro.
  pause & exit /b 1
)
if not exist "frontend\dist\index.html" (
  echo [AVISO] Frontend nao compilado. Compilando agora (npm run build)...
  pushd frontend & call npm run build & popd
)

echo Iniciando SIEM Firewalls em http://127.0.0.1:8000 ...
echo (feche esta janela ou pressione Ctrl+C para encerrar)
echo.
cd backend
.venv\Scripts\python.exe run.py
endlocal

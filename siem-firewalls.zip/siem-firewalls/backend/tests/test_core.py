"""Core business-rule tests (no database / no web framework required).

Run with:  pytest tests/test_core.py
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest  # noqa: E402

from app.core.dataset import Dataset, Filters, Rules  # noqa: E402
from app.core.diff import build_plan, compare_datasets  # noqa: E402
from app.core.excel_reader import ExcelReadError, parse_workbook  # noqa: E402
from app.core.excel_report import build_technical_excel, safe_text  # noqa: E402
from app.core.indicators import compute_indicators, executed_summary_rows  # noqa: E402
from app.core.pdf_report import build_executive_pdf  # noqa: E402
from tests.fixtures import build_workbook, exe_row, inv_row, sample_v1, sample_v2  # noqa: E402

NOW = "2026-10-18T10:00:00"


def _import(data: bytes, current: Dataset | None = None, import_id: int = 1, rules: Rules | None = None,
            known=None) -> tuple[Dataset, dict]:
    rules = rules or Rules()
    current = current or Dataset({}, {}, rules, None)
    parsed = parse_workbook(data, "arquivo.xlsx")
    plan = build_plan(parsed, current, rules, import_id, known or {}, NOW)
    return Dataset(plan.assets, plan.executions, rules, import_id), plan.summary


# 1. Importação inicial
def test_initial_import():
    ds, s = _import(sample_v1())
    c = compute_indicators(ds)["cards"]
    assert s["new_assets"] == 5 and s["new_executed"] == 1
    assert c["total_assets"] == 5 and c["total_executed"] == 1
    assert c["pct_executed"] == 20.0


# 2. Importação incremental acumulativa  / 4. novos executados
def test_incremental_cumulative_import():
    ds1, _ = _import(sample_v1())
    ds2, s2 = _import(sample_v2(), ds1, import_id=2)
    c = compute_indicators(ds2)["cards"]
    assert c["total_executed"] == 2            # not 1 + 2 = 3 (no summing of imports)
    assert s2["new_executed"] == 1 and s2["new_assets"] == 1
    assert c["new_executed_last_import"] == 1
    assert ds2.executions["FW-001"]["first_import_id"] == 1
    assert ds2.executions["FW-002"]["first_import_id"] == 2


# 3. Reimportação de arquivo idêntico
def test_identical_file_is_detected():
    data = sample_v1()
    ds1, _ = _import(data)
    parsed = parse_workbook(data, "arquivo.xlsx")
    plan = build_plan(parsed, ds1, Rules(), 2, {parsed.file_hash: 1}, NOW)
    assert plan.identical_to_import_id == 1
    assert plan.summary["new_executed"] == 0 and plan.summary["has_changes"] is False


# 5. Duplicidade de ID
def test_duplicate_ids_prefer_validated_row():
    exe = [exe_row("FW-001", **{"Validar Evidência": "Validado e OK", "Logs no SIEM": "Sim", "Mudança": "CHG-A"}),
           exe_row("FW-001", **{"Validar Evidência": None, "Logs no SIEM": "Não", "Mudança": "CHG-B"})]
    data = build_workbook([inv_row("FW-001"), inv_row("FW-002")], exe)
    ds, s = _import(data)
    assert s["duplicates_count"] == 1
    assert compute_indicators(ds)["cards"]["total_executed"] == 1
    rec = ds.merged("FW-001")
    assert rec["logs_siem"] == "Sim" and rec["mudanca"] == "CHG-A"
    assert len(rec["secondary_rows"]) == 1
    # alternative strategy: last row wins
    ds_last, _ = _import(data, rules=Rules(dedupe_strategy="ultima"))
    assert ds_last.merged("FW-001")["mudanca"] == "CHG-B"


# 6. Mudança de status
def test_status_change_is_recorded():
    ds1, _ = _import(sample_v1())
    parsed = parse_workbook(sample_v2(), "v2.xlsx")
    plan = build_plan(parsed, ds1, Rules(), 2, {}, NOW)
    changes = [c for c in plan.changes if c.change_type == "status_change" and c.asset_id == "FW-003"]
    assert changes and changes[0].old_value == "Em Andamento" and changes[0].new_value == "Concluído"
    assert plan.summary["status_changes"] >= 1


# 7. Executado e não concluído
def test_executed_not_concluded():
    ds1, _ = _import(sample_v1())
    ds2, _ = _import(sample_v2(), ds1, import_id=2)
    c = compute_indicators(ds2)["cards"]
    assert c["executed_concluded"] == 1 and c["executed_not_concluded"] == 1
    rec = ds2.merged("FW-002")
    assert rec["executed"] and rec["status_canonical"] == "em_andamento"
    assert "nao_concluido" in rec["pendencies"] and "logs_siem_nao" in rec["pendencies"]


# 8. Equipamento ausente em nova importação (não remover)
def test_missing_asset_is_kept_and_flagged():
    ds1, _ = _import(sample_v1())
    data = build_workbook([inv_row("FW-001"), inv_row("FW-002")], [exe_row("FW-001")])
    parsed = parse_workbook(data, "v3.xlsx")
    plan = build_plan(parsed, ds1, Rules(), 2, {}, NOW)
    assert "FW-003" in plan.assets and plan.assets["FW-003"]["present_in_last_import"] is False
    assert plan.summary["missing_assets"] == 3
    assert any(c.change_type == "missing_asset" and c.asset_id == "FW-003" for c in plan.changes)
    ds2 = Dataset(plan.assets, plan.executions, Rules(), 2)
    assert compute_indicators(ds2)["cards"]["total_assets"] == 5


# 9. Host executado ausente no inventário
def test_executed_orphan_not_in_inventory():
    data = build_workbook([inv_row("FW-001")], [exe_row("FW-001"), exe_row("FW-999")])
    ds, s = _import(data)
    assert s["orphans"] == ["FW-999"]
    c = compute_indicators(ds)["cards"]
    assert c["total_executed"] == 1 and c["orphans"] == 1   # orphan not counted in executed/inventory


# 10. Cabeçalhos em linhas diferentes
def test_header_detection_on_different_rows():
    data = build_workbook([inv_row("FW-001")], [exe_row("FW-001")], inv_title_rows=5, exe_title_rows=3)
    parsed = parse_workbook(data, "x.xlsx")
    assert parsed.inventory.header_row == 6 and parsed.executed.header_row == 4
    assert parsed.executed.columns["prova"] == "ip"
    assert len(parsed.inventory.rows) == 1


# 11. Valores vazios
def test_empty_values_are_not_informed():
    data = build_workbook([inv_row("FW-001", Estado=None, Região="")], [exe_row("FW-001", **{"Logs no SIEM": None})])
    ds, _ = _import(data)
    ind = compute_indicators(ds)
    assert ind["distributions"]["estado"][0]["label"] == "MA"  # exec value wins for executed (precedence)
    rec = ds.merged("FW-001")
    assert rec["logs_siem"] is None and "logs_siem_nao_informado" in rec["pendencies"]
    assert "logs_siem_nao" not in rec["pendencies"]        # empty is never treated as failure
    assert ds.assets["FW-001"]["regiao"] is None


# 12. Arquivo Excel inválido
def test_invalid_excel_file():
    with pytest.raises(ExcelReadError):
        parse_workbook(b"isto nao e um excel", "x.xlsx")
    with pytest.raises(ExcelReadError):
        parse_workbook(b"PK\x03\x04garbage", "x.xlsx")
    with pytest.raises(ExcelReadError):
        parse_workbook(sample_v1(), "x.csv")
    with pytest.raises(ExcelReadError):
        parse_workbook(build_workbook(None, None), "x.xlsx")   # no recognised sheets


# 13. Filtros combinados / 15-17 distribuições
def test_combined_filters_and_distributions():
    ds1, _ = _import(sample_v1())
    ds2, _ = _import(sample_v2(), ds1, import_id=2)
    ind = compute_indicators(ds2, Filters.from_params({"regiao": "Nordeste", "estado": "MA|PI"}))
    assert ind["universe_filtered"] is True
    assert ind["cards"]["total_assets"] == 2 and ind["cards"]["total_executed"] == 2
    full = compute_indicators(ds2)
    by_uf = {d["label"]: d for d in full["distributions"]["estado"]}
    assert by_uf["MA"]["executed"] == 1 and by_uf["PI"]["executed"] == 1 and by_uf["GO"]["executed"] == 0
    assert "Não informado" in by_uf and by_uf["Não informado"]["total"] == 1
    assert sum(d["executed"] for d in full["distributions"]["regiao"]) == full["cards"]["total_executed"]
    ondas = {d["label"]: d["executed"] for d in full["distributions"]["onda"]}
    assert ondas["Onda 1"] == 1 and ondas["Onda 2"] == 1
    assert sum(ondas.values()) == 2


# 14. Cálculo de percentual
def test_percentage_calculation():
    inv = [inv_row(f"FW-{i:03d}") for i in range(1, 8)]
    ds, _ = _import(build_workbook(inv, [exe_row("FW-001"), exe_row("FW-002")]))
    assert compute_indicators(ds)["cards"]["pct_executed"] == 28.57
    empty = compute_indicators(Dataset({}, {}, Rules(), None))["cards"]
    assert empty["pct_executed"] == 0.0 and empty["total_assets"] == 0


# 18. Exportação PDF
def test_pdf_export_single_page():
    ds, _ = _import(sample_v1())
    pdf = build_executive_pdf(compute_indicators(ds), last_import={"id": 1, "file_name": "a.xlsx", "created_at": "x"})
    assert pdf.startswith(b"%PDF") and pdf.count(b"/Type /Page\n") + pdf.count(b"/Type /Page ") >= 1
    assert b"/Count 1" in pdf


# 19. Exportação Excel
def test_excel_export_all_rows_and_safety():
    inv = [inv_row(f"FW-{i:03d}") for i in range(1, 60)]
    exe = [exe_row(f"FW-{i:03d}", **{"Observações": "@SUM(A1:A9)"}) for i in range(1, 60)]
    ds, _ = _import(build_workbook(inv, exe))
    ind = compute_indicators(ds)
    rows = executed_summary_rows(ds, None)
    data = build_technical_excel(rows, ind, columns=["id", "ip", "porta", "status", "observacoes"], group_by="estado")
    from openpyxl import load_workbook
    import io
    wb = load_workbook(io.BytesIO(data))
    assert wb.sheetnames[:2] == ["Resumo", "Executados"]
    ws = wb["Executados"]
    assert ws.max_row == 60                       # header + 59 rows (not only first page)
    assert ws["B2"].number_format == "@" and ws["A2"].value == "FW-001"
    assert str(ws["E2"].value).startswith("'@")   # formula injection neutralised
    assert ws.freeze_panes == "A2" and ws.auto_filter.ref is not None
    assert safe_text("-1") == "'-1" and safe_text(5) == 5


# 20. Preservação de snapshots / comparação
def test_compare_datasets():
    ds1, _ = _import(sample_v1())
    ds2, _ = _import(sample_v2(), ds1, import_id=2)
    cmp = compare_datasets(ds1, ds2)
    assert cmp["new_assets"] == ["FW-006"] and cmp["first_executed"] == ["FW-002"]
    assert any(s["asset_id"] == "FW-003" for s in cmp["status_changes"])
    assert cmp["a"]["total_executed"] == 1 and cmp["b"]["total_executed"] == 2


# Conflitos e precedência configurável
def test_precedence_and_conflicts():
    inv = [inv_row("FW-001", Onda="Onda 1", **{"Status Implementação": None})]
    exe = [exe_row("FW-001", Onda="Onda 3", **{"Status Implementação": "Concluído"})]
    data = build_workbook(inv, exe)
    ds_exec, s = _import(data)
    rec = ds_exec.merged("FW-001")
    assert rec["onda"] == "Onda 3" and rec["status_canonical"] == "concluido"
    assert any(c["field"] == "onda" for c in rec["conflicts"])
    assert s["conflicts"] >= 1
    ds_inv, _ = _import(data, rules=Rules(precedence="inventario"))
    rec2 = ds_inv.merged("FW-001")
    assert rec2["onda"] == "Onda 1" and rec2["status_canonical"] == "concluido"  # falls back when inventory empty


def test_not_started_rule_and_status_cards():
    ds, _ = _import(sample_v1())
    c = compute_indicators(ds)["cards"]
    # FW-002 and FW-005 empty & not executed -> not started; FW-003 in progress; FW-004 blocked
    assert c["not_started"] == 2 and c["in_progress"] == 1 and c["blocked"] == 1 and c["pending"] == 0


def test_tipo_equivalence_groups_variants():
    inv = [inv_row("FW-001", Tipo="SubEstação"), inv_row("FW-002", Tipo="SUBESTAÇÃO"),
           inv_row("FW-003", Tipo="Substação"), inv_row("FW-004", Tipo="Agência")]
    ds, _ = _import(build_workbook(inv, []))
    tipos = {d["label"]: d["total"] for d in compute_indicators(ds)["distributions"]["tipo"]}
    assert tipos == {"SubEstação": 3, "Agência": 1}
    assert ds.assets["FW-002"]["tipo"] == "SUBESTAÇÃO"   # original preserved


def test_extra_columns_preserved_and_text_types():
    data = build_workbook([{**inv_row("FW-001", IP="10.1.1.1", Porta=11001), "Coluna Nova": "valor"}], [], extra_inv_headers=["Coluna Nova"])
    parsed = parse_workbook(data, "x.xlsx")
    row = parsed.inventory.rows[0]
    assert row["extra"] == {"Coluna Nova": "valor"} and row["porta"] == "11001" and row["ip"] == "10.1.1.1"
    assert "Coluna Nova" in parsed.inventory.unmapped

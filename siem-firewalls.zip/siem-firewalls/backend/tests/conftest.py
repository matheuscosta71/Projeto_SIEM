"""Isolated SQLite database for the API tests (set before the app is imported)."""
import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

_TMP = Path(tempfile.mkdtemp(prefix="siem_fw_tests_"))
os.environ["DATABASE_URL"] = f"sqlite:///{(_TMP / 'test.db').as_posix()}"
os.environ["BACKUP_DIR"] = str(_TMP / "backups")
os.environ["FRONTEND_DIST"] = str(_TMP / "no-dist")
os.environ["OPEN_BROWSER"] = "false"

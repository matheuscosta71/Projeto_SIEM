"""Helpers to build small Excel workbooks that mimic the real structure."""
from __future__ import annotations

import io
from typing import Any, Dict, Iterable, List, Optional

from openpyxl import Workbook

INV_HEADERS = ["ID", "Nome do Ativo", "Fabricante / Modelo", "IP", "Onda", "Região", "Estado", "Cidade", "Tipo",
               "Criticidade", "Status Implementação", "Coletor", "Porta", "Descoberta", "Coleta Config.",
               "Logs no SIEM", "Mudança", "Data Prevista", "Data Real", "Responsável", "Observações"]
EXE_HEADERS = ["ID", "Nome do Ativo / hostname", "Nome do Ativo / Zabbix", "Fabricante / Modelo", "prova ", "Onda",
               "Região", "Estado", "Cidade", "Tipo", "Criticidade", "Status Implementação", "Coletor", "Porta",
               "Descoberta", "Coleta Config.", "Logs no SIEM", "Mudança", "Data Prevista", "Data Real",
               "Responsável", "Validar Evidência", "Observações"]


def inv_row(id_: str, **kw: Any) -> Dict[str, Any]:
    base = {"ID": id_, "Nome do Ativo": f"FW-HOST-{id_}", "Fabricante / Modelo": "fortinet/FortiGate-100F",
            "IP": None, "Onda": None, "Região": "Nordeste", "Estado": "MA", "Cidade": "Sao Luis", "Tipo": "SubEstação",
            "Criticidade": None, "Status Implementação": None}
    base.update(kw)
    return base


def exe_row(id_: str, **kw: Any) -> Dict[str, Any]:
    base = {"ID": id_, "Nome do Ativo / hostname": f"FW-HOST-{id_}", "Nome do Ativo / Zabbix": f"ZBX-{id_}",
            "Fabricante / Modelo": "fortinet/FortiGate-100F", "prova ": "10.0.0.1", "Onda": "Onda 1",
            "Região": "Nordeste", "Estado": "MA", "Cidade": "Sao Luis", "Tipo": "SubEstação", "Criticidade": "Crítico",
            "Status Implementação": "Concluído", "Coletor": "TO - MA - X (10.7.61.10)", "Porta": 11001,
            "Descoberta": "Sim", "Coleta Config.": "Sim", "Logs no SIEM": "Sim", "Mudança": "CHG0001",
            "Validar Evidência": "Validado e OK"}
    base.update(kw)
    return base


def build_workbook(inventory: Optional[Iterable[Dict[str, Any]]], executed: Optional[Iterable[Dict[str, Any]]], *,
                   inv_title_rows: int = 2, exe_title_rows: int = 0, inv_sheet: str = "Inventário_Ativos",
                   exe_sheet: str = "EXECUTADOS", extra_inv_headers: Optional[List[str]] = None) -> bytes:
    wb = Workbook()
    first = True

    def _sheet(title: str, headers: List[str], rows: Iterable[Dict[str, Any]], title_rows: int):
        nonlocal first
        if first:
            ws = wb.active
            ws.title = title
            first = False
        else:
            ws = wb.create_sheet(title)
        r = 1
        for _ in range(title_rows):
            ws.cell(row=r, column=1, value="Título da planilha — linha de formatação" if r == 1 else None)
            r += 1
        for c, h in enumerate(headers, start=1):
            ws.cell(row=r, column=c, value=h)
        for row in rows:
            r += 1
            for c, h in enumerate(headers, start=1):
                ws.cell(row=r, column=c, value=row.get(h))

    if inventory is not None:
        _sheet(inv_sheet, INV_HEADERS + (extra_inv_headers or []), inventory, inv_title_rows)
    if executed is not None:
        _sheet(exe_sheet, EXE_HEADERS, executed, exe_title_rows)
    if first:  # no sheets
        wb.active.title = "Vazio"
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def sample_v1() -> bytes:
    inv = [inv_row("FW-001", **{"Status Implementação": "Concluído", "Onda": "Onda 1", "Estado": "MA"}),
           inv_row("FW-002", Estado="PI", Região="Nordeste"),
           inv_row("FW-003", Estado="RS", Região="Sul", **{"Status Implementação": "Em Andamento"}),
           inv_row("FW-004", Estado="PA", Região="Norte", **{"Status Implementação": "Bloqueado"}),
           inv_row("FW-005", Estado=None, Região=None)]
    exe = [exe_row("FW-001", Estado="MA")]
    return build_workbook(inv, exe)


def sample_v2() -> bytes:
    """Cumulative: FW-001 still executed, FW-002 newly executed (not yet concluded), FW-006 new asset."""
    inv = [inv_row("FW-001", **{"Status Implementação": "Concluído", "Onda": "Onda 1"}),
           inv_row("FW-002", Estado="PI", **{"Status Implementação": "Em Andamento"}),
           inv_row("FW-003", Estado="RS", Região="Sul", **{"Status Implementação": "Concluído"}),
           inv_row("FW-004", Estado="PA", Região="Norte", **{"Status Implementação": "Bloqueado"}),
           inv_row("FW-005", Estado=None, Região=None),
           inv_row("FW-006", Estado="GO", Região="Centro-Oeste")]
    exe = [exe_row("FW-001"),
           exe_row("FW-002", Estado="PI", Onda="Onda 2", **{"Status Implementação": "Em Andamento", "Logs no SIEM": "Não"})]
    return build_workbook(inv, exe)

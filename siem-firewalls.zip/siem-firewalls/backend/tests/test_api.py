"""End-to-end API tests: import flow, persistence, snapshots, reports consistency,
backup/restore. Requires the full backend stack (FastAPI, SQLAlchemy).

Run with:  pytest tests/test_api.py
Tests are ordered (they build on a shared database on purpose).
"""
from __future__ import annotations

import io

import pytest
from fastapi.testclient import TestClient
from openpyxl import load_workbook

from app.database import init_db
from app.main import app
from tests.fixtures import sample_v1, sample_v2

init_db()  # the module-level client does not run the lifespan handlers
client = TestClient(app)


def _upload(data: bytes, name: str = "planilha.xlsx"):
    return client.post("/api/imports/preview", files={"file": (name, data, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")})


def _confirm(token: str, force: bool = False):
    return client.post(f"/api/imports/{token}/confirm", data={"force": str(force).lower()})


def test_health_and_empty_state():
    assert client.get("/api/health").json()["status"] == "ok"
    meta = client.get("/api/meta").json()
    assert meta["has_data"] is False
    ind = client.get("/api/indicators").json()
    assert ind["cards"]["total_assets"] == 0 and ind["cards"]["pct_executed"] == 0.0


# 1. Importação inicial (via API, com prévia + confirmação)
def test_initial_import_flow():
    r = _upload(sample_v1(), "v1.xlsx")
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["can_confirm"] and body["summary"]["new_assets"] == 5 and body["summary"]["new_executed"] == 1
    r2 = _confirm(body["token"])
    assert r2.status_code == 200, r2.text
    imp = r2.json()
    assert imp["id"] == 1 and imp["total_assets"] == 5 and imp["total_executed"] == 1
    ind = client.get("/api/indicators").json()
    assert ind["cards"]["total_assets"] == 5 and ind["cards"]["pct_executed"] == 20.0
    assert ind["cards"]["new_executed_last_import"] == 1


# 3. Reimportação de arquivo idêntico é bloqueada
def test_identical_reimport_blocked():
    body = _upload(sample_v1(), "v1-copia.xlsx").json()
    assert body["can_confirm"] is False and body["identical_to_import_id"] == 1
    r = _confirm(body["token"])
    assert r.status_code == 409
    assert len(client.get("/api/imports").json()) == 1


# 2/4. Importação incremental acumulativa + novos executados + snapshot
def test_incremental_import_and_snapshots():
    body = _upload(sample_v2(), "v2.xlsx").json()
    assert body["summary"]["new_executed"] == 1 and body["summary"]["new_assets"] == 1
    assert body["summary"]["status_changes"] >= 1
    r = _confirm(body["token"])
    assert r.status_code == 200, r.text
    ind = client.get("/api/indicators").json()
    assert ind["cards"]["total_assets"] == 6 and ind["cards"]["total_executed"] == 2
    assert ind["cards"]["executed_concluded"] == 1 and ind["cards"]["executed_not_concluded"] == 1
    assert len(ind["evolution"]) == 2 and ind["evolution"][-1]["total_executed"] == 2
    # 20. snapshot of import #1 still reproduces the old state
    snap1 = client.get("/api/imports/1/indicators").json()
    assert snap1["cards"]["total_assets"] == 5 and snap1["cards"]["total_executed"] == 1
    cmp = client.get("/api/imports/compare", params={"a": 1, "b": 2}).json()
    assert cmp["counts"]["first_executed"] == 1 and cmp["first_executed"] == ["FW-002"]
    detail = client.get("/api/imports/2").json()
    assert detail["change_counts"].get("new_execution") == 1


def test_asset_detail_history():
    d = client.get("/api/assets/FW-002").json()
    assert d["record"]["executed"] is True
    assert d["history"]["first_import"]["id"] == 1 and d["history"]["first_executed_import"]["id"] == 2
    assert any(c["change_type"] == "new_execution" for c in d["history"]["changes"])
    assert client.get("/api/assets/FW-404").status_code == 404


# 13. Filtros combinados via API
def test_filters_via_api():
    r = client.get("/api/executions", params={"estado": "MA|PI", "regiao": "Nordeste", "page_size": 10}).json()
    assert r["total"] == 2
    r = client.get("/api/assets", params={"status": "Bloqueado"}).json()
    assert r["total"] == 1 and r["items"][0]["id"] == "FW-004"
    r = client.get("/api/executions/pendencies").json()
    assert r["total"] == 1 and r["items"][0]["id"] == "FW-002"
    opts = client.get("/api/filters/options").json()["options"]
    assert "Não informado" in opts["estado"] and "Onda 2" in opts["onda"]


# 23. Consistência dashboard x relatórios / 18 / 19
def test_reports_match_dashboard():
    ind = client.get("/api/indicators").json()["cards"]
    r = client.post("/api/reports/pdf", json={"filters": {}})
    assert r.status_code == 200 and r.content.startswith(b"%PDF") and b"/Count 1" in r.content
    r = client.post("/api/reports/excel", json={"filters": {}, "scope": "executados", "group_by": "estado"})
    assert r.status_code == 200
    wb = load_workbook(io.BytesIO(r.content))
    ws_sum, ws_exe = wb["Resumo"], wb["Executados"]
    values = {ws_sum.cell(row=i, column=1).value: ws_sum.cell(row=i, column=2).value for i in range(3, 14)}
    assert values["Total de ativos"] == ind["total_assets"]
    assert values["Total executado acumulado"] == ind["total_executed"]
    assert values["Percentual executado (%)"] == ind["pct_executed"]
    assert ws_exe.max_row - 1 == ind["total_executed"]
    hist = client.get("/api/reports/history").json()
    assert len(hist) >= 2 and hist[0]["report_type"] == "excel_tecnico"


def test_settings_require_confirmation():
    r = client.put("/api/settings", json={"rules": {"precedence": "inventario"}})
    assert r.status_code == 400
    r = client.put("/api/settings", json={"rules": {"precedence": "inventario"}, "confirm": True})
    assert r.status_code == 200 and r.json()["rules"]["precedence"] == "inventario"
    # restore default
    client.put("/api/settings", json={"rules": {"precedence": "executados"}, "confirm": True})
    r = client.put("/api/settings", json={"rules": {"precedence": "errado"}, "confirm": True})
    assert r.status_code == 422


# 21. Backup e restauração
def test_backup_and_restore():
    r = client.post("/api/backups")
    assert r.status_code == 200, r.text
    assert client.get("/api/backups").json()["items"]
    exp = client.get("/api/backups/export")
    assert exp.status_code == 200 and exp.content.startswith(b"SQLite format 3")
    # restore without confirmation is refused
    assert client.post("/api/backups/restore", data={"confirm": "false"}, files={"file": ("b.db", exp.content)}).status_code == 400
    r = client.post("/api/backups/restore", data={"confirm": "true"}, files={"file": ("b.db", exp.content)})
    assert r.status_code == 200, r.text
    assert r.json()["restored"]["assets"] == 6
    assert client.get("/api/indicators").json()["cards"]["total_executed"] == 2
    # invalid file refused
    assert client.post("/api/backups/restore", data={"confirm": "true"}, files={"file": ("b.db", b"nope")}).status_code == 422


# 22. Persistência após reinicialização (novo engine/sessão sobre o mesmo arquivo)
def test_persistence_after_restart():
    from app.config import settings
    from app.database import _make_engine
    from sqlalchemy import text
    eng = _make_engine(settings.DATABASE_URL)
    with eng.connect() as conn:
        assert conn.execute(text("SELECT COUNT(*) FROM assets")).scalar_one() == 6
        assert conn.execute(text("SELECT COUNT(*) FROM executions")).scalar_one() == 2
        assert conn.execute(text("SELECT COUNT(*) FROM import_snapshots")).scalar_one() == 2
    eng.dispose()


# 12. Arquivo inválido via API
def test_invalid_upload():
    r = _upload(b"nao e excel", "x.xlsx")
    assert r.status_code == 422
    r = _upload(sample_v1(), "x.txt")
    assert r.status_code == 422


def test_openapi_available():
    spec = client.get("/api/openapi.json").json()
    assert "/api/imports/preview" in spec["paths"] and "/api/reports/pdf" in spec["paths"]

"""FastAPI application entry point. Serves the API under /api and the built
frontend (frontend/dist) at / when available."""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .config import APP_VERSION, settings
from .database import init_db
from .routers import data, imports, reports, settings_router

logging.basicConfig(level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO),
                    format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("siem")

@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    Path(settings.BACKUP_DIR).mkdir(parents=True, exist_ok=True)
    log.info("SIEM Firewalls %s iniciado em http://%s:%s", APP_VERSION, settings.HOST, settings.PORT)
    yield


app = FastAPI(
    lifespan=lifespan,
    title="SIEM Firewalls API",
    version=APP_VERSION,
    description="Acompanhamento do rollout de integração de firewalls ao SIEM. Execução local (127.0.0.1).",
    docs_url="/api/docs", redoc_url="/api/redoc", openapi_url="/api/openapi.json",
)

app.include_router(data.router)
app.include_router(imports.router)
app.include_router(reports.router)
app.include_router(settings_router.router)


@app.exception_handler(Exception)
async def _unhandled(request: Request, exc: Exception):  # noqa: ANN001
    log.exception("Erro não tratado em %s", request.url.path)
    return JSONResponse(status_code=500, content={"detail": "Erro interno. Consulte o log da aplicação."})


@app.get("/api/health", tags=["sistema"])
def health():
    return {"status": "ok", "version": APP_VERSION}


# ---- frontend (production build) ----
dist = Path(settings.FRONTEND_DIST)
if dist.exists() and (dist / "index.html").exists():
    if (dist / "assets").is_dir():
        app.mount("/assets", StaticFiles(directory=str(dist / "assets")), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    def spa(full_path: str):
        if full_path.startswith("api/") or full_path == "api":
            raise HTTPException(404, "Rota de API inexistente.")
        candidate = dist / full_path
        if full_path and candidate.is_file() and candidate.resolve().is_relative_to(dist.resolve()):
            return FileResponse(str(candidate))
        return FileResponse(str(dist / "index.html"))
else:
    @app.get("/", include_in_schema=False)
    def no_frontend():
        return JSONResponse({"detail": "Frontend não compilado. Execute instalar.bat (npm run build) ou use o modo dev (npm run dev)."})

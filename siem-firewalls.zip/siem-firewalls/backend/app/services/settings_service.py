"""Settings persisted as JSON documents in the ``settings`` table."""
from __future__ import annotations

from typing import Any, Dict

from sqlalchemy.orm import Session

from ..core.dataset import Rules
from ..core.normalizer import DEFAULT_FABRICANTE_MAP, DEFAULT_STATUS_MAP, DEFAULT_TIPO_MAP
from ..models import Setting

DEFAULTS: Dict[str, Any] = {
    "rules": Rules().to_dict(),
    "column_mapping": {"inventario": {}, "executados": {}},
    "preferences": {"theme": "system", "date_format": "DD/MM/YYYY", "page_size": 25},
    "backup": {"path": None},
}


def get_setting(db: Session, key: str) -> Any:
    row = db.get(Setting, key)
    if row is None:
        return DEFAULTS.get(key)
    return row.value


def set_setting(db: Session, key: str, value: Any) -> Any:
    row = db.get(Setting, key)
    if row is None:
        row = Setting(key=key, value=value)
        db.add(row)
    else:
        row.value = value
    db.flush()
    return value


def get_rules(db: Session) -> Rules:
    return Rules.from_dict(get_setting(db, "rules"))


def get_column_mapping(db: Session) -> Dict[str, Dict[str, str]]:
    cm = get_setting(db, "column_mapping") or {}
    return {"inventario": cm.get("inventario", {}) or {}, "executados": cm.get("executados", {}) or {}}


def all_settings(db: Session) -> Dict[str, Any]:
    return {
        "rules": get_rules(db).to_dict(),
        "column_mapping": get_column_mapping(db),
        "preferences": {**DEFAULTS["preferences"], **(get_setting(db, "preferences") or {})},
        "backup": {**DEFAULTS["backup"], **(get_setting(db, "backup") or {})},
        "defaults": {"status_map": DEFAULT_STATUS_MAP, "tipo_map": DEFAULT_TIPO_MAP, "fabricante_map": DEFAULT_FABRICANTE_MAP},
    }

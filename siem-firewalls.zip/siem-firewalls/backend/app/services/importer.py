"""Import orchestration: preview (parse + plan, kept in memory under a token)
and confirm (transactional persistence)."""
from __future__ import annotations

import secrets
import threading
import time
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlalchemy.orm import Session

from ..config import settings
from ..core.diff import ImportPlan, build_plan
from ..core.excel_reader import ExcelReadError, ParsedWorkbook, parse_workbook
from . import repository
from .settings_service import get_column_mapping, get_rules


class ImportError_(Exception):
    pass


@dataclass
class PendingImport:
    token: str
    parsed: ParsedWorkbook
    plan: ImportPlan
    created: float
    base_import_id: Optional[int]   # last confirmed import when the preview was built


_pending: Dict[str, PendingImport] = {}
_lock = threading.Lock()


def _purge() -> None:
    ttl = settings.PREVIEW_TTL_MINUTES * 60
    now = time.time()
    for k in [k for k, v in _pending.items() if now - v.created > ttl]:
        _pending.pop(k, None)


def safe_filename(name: str) -> str:
    base = name.replace("\\", "/").split("/")[-1]
    cleaned = "".join(ch for ch in base if ch.isalnum() or ch in "._- ()").strip()
    return cleaned[:200] or "planilha.xlsx"


def preview(db: Session, data: bytes, file_name: str) -> Dict[str, Any]:
    file_name = safe_filename(file_name)
    rules = get_rules(db)
    try:
        parsed = parse_workbook(data, file_name, get_column_mapping(db), settings.MAX_UPLOAD_MB * 1024 * 1024)
    except ExcelReadError as exc:
        raise ImportError_(str(exc)) from exc
    current = repository.load_dataset(db, rules)
    new_id = repository.next_import_id(db)
    plan = build_plan(parsed, current, rules, new_id, repository.known_hashes(db), datetime.now().isoformat(timespec="seconds"))
    token = secrets.token_urlsafe(24)
    with _lock:
        _purge()
        _pending[token] = PendingImport(token=token, parsed=parsed, plan=plan, created=time.time(),
                                        base_import_id=current.last_import_id)
    return {
        "token": token,
        "summary": _public_summary(plan.summary),
        "warnings": plan.warnings,
        "can_confirm": plan.identical_to_import_id is None,
        "identical_to_import_id": plan.identical_to_import_id,
        "changes_preview": _changes_preview(plan),
        "sample_rows": {
            "inventario": [_sample(r) for r in parsed.inventory.rows[:8]] if parsed.inventory else [],
            "executados": [_sample(r) for r in parsed.executed.rows[:8]] if parsed.executed else [],
        },
        "expires_in_minutes": settings.PREVIEW_TTL_MINUTES,
    }


def _sample(rec: Dict[str, Any]) -> Dict[str, Any]:
    return {k: v for k, v in rec.items() if k not in ("extra", "_row")} | {"_row": rec.get("_row")}


def _public_summary(summary: Dict[str, Any]) -> Dict[str, Any]:
    return {k: v for k, v in summary.items() if not k.startswith("_")}


def _changes_preview(plan: ImportPlan, limit: int = 200) -> Dict[str, List[Dict[str, Any]]]:
    out: Dict[str, List[Dict[str, Any]]] = {}
    for ch in plan.changes:
        bucket = out.setdefault(ch.change_type, [])
        if len(bucket) < limit:
            bucket.append(ch.to_dict())
    return out


def discard(token: str) -> bool:
    with _lock:
        return _pending.pop(token, None) is not None


def confirm(db: Session, token: str, reference_date: Optional[str] = None, force: bool = False) -> Dict[str, Any]:
    with _lock:
        _purge()
        pending = _pending.get(token)
    if pending is None:
        raise ImportError_("Prévia expirada ou inexistente. Envie a planilha novamente.")
    if pending.plan.identical_to_import_id is not None and not force:
        raise ImportError_(f"Arquivo idêntico ao da importação #{pending.plan.identical_to_import_id}. "
                           "Importação bloqueada para não gerar execuções duplicadas.")
    current_last = repository.last_confirmed_import(db)
    current_last_id = current_last.id if current_last else None
    if current_last_id != pending.base_import_id:
        discard(token)
        raise ImportError_("Outra importação foi confirmada após esta prévia. Gere a prévia novamente.")
    rules = get_rules(db)
    meta = {"file_name": pending.parsed.file_name, "file_hash": pending.parsed.file_hash,
            "size_bytes": pending.parsed.size_bytes}
    imp = repository.apply_plan(db, pending.plan, meta, rules, reference_date=reference_date)
    discard(token)
    return repository.import_to_dict(imp)

"""Persistence: load the live Dataset, apply an ImportPlan transactionally,
store/load full snapshots."""
from __future__ import annotations

import gzip
import json
from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..core.dataset import Dataset, Record, Rules
from ..core.diff import ImportPlan
from ..models import RECORD_COLUMNS, Asset, AssetChange, Execution, Import, ImportSnapshot
from .settings_service import get_rules

META_KEYS = ["first_import_id", "last_import_id", "present_in_last_import", "updated_at"]


def _row_to_record(row: Asset | Execution, id_attr: str) -> Record:
    rec: Record = {"id": getattr(row, id_attr)}
    for c in RECORD_COLUMNS:
        rec[c] = getattr(row, c)
    rec["extra"] = row.extra or {}
    for m in META_KEYS:
        rec[m] = getattr(row, m)
    if isinstance(row, Execution):
        rec["secondary_rows"] = row.secondary_rows or []
    return rec


def last_confirmed_import(db: Session) -> Optional[Import]:
    return db.execute(
        select(Import).where(Import.status == "confirmed").order_by(Import.id.desc()).limit(1)
    ).scalar_one_or_none()


def load_dataset(db: Session, rules: Optional[Rules] = None) -> Dataset:
    rules = rules or get_rules(db)
    assets = {a.id: _row_to_record(a, "id") for a in db.execute(select(Asset)).scalars()}
    executions = {e.asset_id: _row_to_record(e, "asset_id") for e in db.execute(select(Execution)).scalars()}
    last = last_confirmed_import(db)
    return Dataset(assets=assets, executions=executions, rules=rules, last_import_id=last.id if last else None)


def known_hashes(db: Session) -> Dict[str, int]:
    rows = db.execute(select(Import.file_hash, Import.id).where(Import.status == "confirmed")).all()
    out: Dict[str, int] = {}
    for h, i in rows:
        out.setdefault(h, i)
    return out


def next_import_id(db: Session) -> int:
    last = db.execute(select(Import.id).order_by(Import.id.desc()).limit(1)).scalar_one_or_none()
    return (last or 0) + 1


def _apply_record(obj: Asset | Execution, rec: Record) -> None:
    for c in RECORD_COLUMNS:
        setattr(obj, c, rec.get(c))
    obj.extra = rec.get("extra") or {}
    obj.first_import_id = rec.get("first_import_id")
    obj.last_import_id = rec.get("last_import_id")
    obj.present_in_last_import = bool(rec.get("present_in_last_import", True))
    obj.updated_at = rec.get("updated_at")
    if isinstance(obj, Execution):
        obj.secondary_rows = rec.get("secondary_rows") or []


def serialize_state(assets: Dict[str, Record], executions: Dict[str, Record]) -> bytes:
    payload = {"assets": list(assets.values()), "executions": list(executions.values())}
    return gzip.compress(json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8"))


def deserialize_state(blob: bytes) -> Dict[str, Any]:
    return json.loads(gzip.decompress(blob).decode("utf-8"))


def apply_plan(db: Session, plan: ImportPlan, parsed_meta: Dict[str, Any], rules: Rules,
               reference_date: Optional[str] = None) -> Import:
    """Persist the plan in ONE transaction. Any exception rolls everything back."""
    now = datetime.now()
    try:
        imp = Import(
            file_name=parsed_meta["file_name"], file_hash=parsed_meta["file_hash"],
            size_bytes=parsed_meta.get("size_bytes", 0), created_at=now, reference_date=reference_date,
            status="confirmed",
            total_assets=plan.summary["total_assets"], total_executed=plan.summary["total_executed"],
            new_assets=plan.summary["new_assets"], new_executed=plan.summary["new_executed"],
            total_concluded=plan.summary["executed_concluded"], total_pending=plan.summary["pending"],
            total_blocked=plan.summary["blocked"], pct_executed=plan.summary["pct_executed"],
            summary={k: v for k, v in plan.summary.items() if not k.startswith("_")},
            warnings=list(plan.warnings), rules=rules.to_dict(),
        )
        db.add(imp)
        db.flush()  # obtain id
        # The plan was built with a provisional id; realign if needed
        provisional = plan.summary.get("_provisional_import_id")
        if provisional is not None and provisional != imp.id:
            _realign_ids(plan, provisional, imp.id)

        existing_assets = {a.id: a for a in db.execute(select(Asset)).scalars()}
        for aid, rec in plan.assets.items():
            obj = existing_assets.get(aid)
            if obj is None:
                obj = Asset(id=aid)
                db.add(obj)
            _apply_record(obj, rec)
        existing_exec = {e.asset_id: e for e in db.execute(select(Execution)).scalars()}
        for aid, rec in plan.executions.items():
            obj = existing_exec.get(aid)
            if obj is None:
                obj = Execution(asset_id=aid)
                db.add(obj)
            _apply_record(obj, rec)

        for ch in plan.changes:
            db.add(AssetChange(import_id=imp.id, asset_id=ch.asset_id, change_type=ch.change_type, source=ch.source,
                               field=ch.field, old_value=ch.old_value, new_value=ch.new_value, detail=ch.detail,
                               created_at=now))
        db.add(ImportSnapshot(import_id=imp.id, kind="state",
                              record_count=len(plan.assets) + len(plan.executions),
                              payload=serialize_state(plan.assets, plan.executions)))
        db.commit()
        db.refresh(imp)
        return imp
    except Exception:
        db.rollback()
        raise


def _realign_ids(plan: ImportPlan, old: int, new: int) -> None:
    for coll in (plan.assets, plan.executions):
        for rec in coll.values():
            for k in ("first_import_id", "last_import_id"):
                if rec.get(k) == old:
                    rec[k] = new
    plan.summary["_provisional_import_id"] = new
    # realign change log entries that may reference the provisional id (none today, kept for safety)


def load_snapshot_dataset(db: Session, import_id: int, rules: Optional[Rules] = None) -> Optional[Dataset]:
    snap = db.execute(select(ImportSnapshot).where(ImportSnapshot.import_id == import_id,
                                                   ImportSnapshot.kind == "state")).scalar_one_or_none()
    if snap is None:
        return None
    imp = db.get(Import, import_id)
    state = deserialize_state(snap.payload)
    rules = rules or Rules.from_dict(imp.rules if imp and imp.rules else None)
    assets = {r["id"]: r for r in state["assets"]}
    executions = {r["id"]: r for r in state["executions"]}
    return Dataset(assets=assets, executions=executions, rules=rules, last_import_id=import_id)


def import_to_dict(imp: Import) -> Dict[str, Any]:
    return {
        "id": imp.id, "file_name": imp.file_name, "file_hash": imp.file_hash, "size_bytes": imp.size_bytes,
        "created_at": imp.created_at.isoformat(sep=" ", timespec="seconds") if imp.created_at else None,
        "reference_date": imp.reference_date, "status": imp.status,
        "total_assets": imp.total_assets, "total_executed": imp.total_executed,
        "new_assets": imp.new_assets, "new_executed": imp.new_executed,
        "total_concluded": imp.total_concluded, "total_pending": imp.total_pending,
        "total_blocked": imp.total_blocked, "pct_executed": imp.pct_executed,
        "summary": imp.summary or {}, "warnings": imp.warnings or [], "rules": imp.rules or {},
    }


def list_imports(db: Session) -> List[Dict[str, Any]]:
    return [import_to_dict(i) for i in db.execute(select(Import).order_by(Import.id.asc())).scalars()]


def asset_history(db: Session, asset_id: str) -> List[Dict[str, Any]]:
    rows = db.execute(select(AssetChange).where(AssetChange.asset_id == asset_id)
                      .order_by(AssetChange.import_id.asc(), AssetChange.id.asc())).scalars()
    return [{"import_id": c.import_id, "change_type": c.change_type, "source": c.source, "field": c.field,
             "old_value": c.old_value, "new_value": c.new_value, "detail": c.detail,
             "created_at": c.created_at.isoformat(sep=" ", timespec="seconds") if c.created_at else None} for c in rows]

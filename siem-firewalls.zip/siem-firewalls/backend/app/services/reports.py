"""Report generation reusing the exact dataset/indicator services of the dashboards."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..core.dataset import Filters
from ..core.excel_report import DEFAULT_COLUMNS, build_technical_excel
from ..core.indicators import compute_indicators, executed_summary_rows, inventory_rows, sort_records
from ..core.pdf_report import build_executive_pdf
from ..models import ReportHistory
from . import repository


def _last_import_meta(db: Session) -> Optional[Dict[str, Any]]:
    imp = repository.last_confirmed_import(db)
    if not imp:
        return None
    d = repository.import_to_dict(imp)
    return {"id": d["id"], "file_name": d["file_name"], "created_at": d["created_at"]}


def _stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M")


def generate_pdf(db: Session, filters: Filters) -> Dict[str, Any]:
    ds = repository.load_dataset(db)
    ind = compute_indicators(ds, filters)
    last = _last_import_meta(db)
    data = build_executive_pdf(ind, last_import=last, filters_text=filters.describe())
    name = f"SIEM_Firewalls_Executivo_{_stamp()}.pdf"
    _log(db, "pdf_executivo", name, filters, {}, ind["cards"]["total_executed"], last, len(data))
    return {"bytes": data, "file_name": name, "media_type": "application/pdf"}


def generate_excel(db: Session, filters: Filters, *, scope: str = "executados", columns: Optional[List[str]] = None,
                   group_by: Optional[str] = None, sort: Optional[str] = None, order: str = "asc") -> Dict[str, Any]:
    ds = repository.load_dataset(db)
    ind = compute_indicators(ds, filters)
    if scope == "inventario":
        rows = inventory_rows(ds, filters)
        title = "Inventário"
    elif scope == "pendencias":
        rows = [r for r in executed_summary_rows(ds, filters) if r.get("pendencies")]
        title = "Pendências"
    else:
        rows = executed_summary_rows(ds, filters)
        title = "Executados"
    rows = sort_records(rows, sort, order)
    last = _last_import_meta(db)
    data = build_technical_excel(rows, ind, columns=columns or DEFAULT_COLUMNS, filters_text=filters.describe(),
                                 last_import=last, group_by=group_by, sheet_title=title)
    suffix = f"_por_{group_by}" if group_by else ""
    name = f"SIEM_Firewalls_{title}{suffix}_{_stamp()}.xlsx"
    _log(db, "excel_tecnico", name, filters, {"scope": scope, "columns": columns, "group_by": group_by}, len(rows), last, len(data))
    return {"bytes": data, "file_name": name,
            "media_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}


def _log(db: Session, rtype: str, name: str, filters: Filters, options: Dict[str, Any], rows: int,
         last: Optional[Dict[str, Any]], size: int) -> None:
    db.add(ReportHistory(report_type=rtype, file_name=name, filters=filters.to_dict(), options=options,
                         row_count=rows, import_id=last["id"] if last else None, size_bytes=size))
    db.commit()


def history(db: Session, limit: int = 100) -> List[Dict[str, Any]]:
    rows = db.execute(select(ReportHistory).order_by(ReportHistory.id.desc()).limit(limit)).scalars()
    return [{"id": r.id, "created_at": r.created_at.isoformat(sep=" ", timespec="seconds"), "report_type": r.report_type,
             "file_name": r.file_name, "filters": r.filters, "options": r.options, "row_count": r.row_count,
             "import_id": r.import_id, "size_bytes": r.size_bytes} for r in rows]

"""Local SQLite backup / restore (uses the sqlite3 online-backup API so the
copy is consistent even while the app is running).

All sqlite3 connections are explicitly closed before files are read, moved
or deleted — required on Windows, where open handles block unlink/replace.
"""
from __future__ import annotations

import os
import sqlite3
from contextlib import closing
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..config import settings

REQUIRED_TABLES = {"assets", "executions", "imports", "import_snapshots", "asset_changes", "settings"}


class BackupError(Exception):
    pass


def _db_path() -> Path:
    p = settings.sqlite_path
    if p is None:
        raise BackupError("Backup automático disponível apenas para SQLite. Use as ferramentas do seu SGBD.")
    return p


def backup_dir(custom: Optional[str] = None) -> Path:
    d = Path(custom) if custom else Path(settings.BACKUP_DIR)
    d.mkdir(parents=True, exist_ok=True)
    return d


def _copy_db(src: Path, dest: Path) -> None:
    with closing(sqlite3.connect(str(src))) as s, closing(sqlite3.connect(str(dest))) as d:
        s.backup(d)


def create_backup(custom_dir: Optional[str] = None) -> Dict[str, Any]:
    src = _db_path()
    if not src.exists():
        raise BackupError("Banco de dados ainda não foi criado.")
    dest_dir = backup_dir(custom_dir)
    name = f"siem_firewalls_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
    dest = dest_dir / name
    _copy_db(src, dest)
    return {"file_name": name, "path": str(dest), "size_bytes": dest.stat().st_size,
            "created_at": datetime.now().isoformat(sep=" ", timespec="seconds")}


def export_backup_bytes() -> bytes:
    src = _db_path()
    if not src.exists():
        raise BackupError("Banco de dados ainda não foi criado.")
    tmp = src.with_name(f".export_{datetime.now().strftime('%H%M%S%f')}.db")
    try:
        _copy_db(src, tmp)
        return tmp.read_bytes()
    finally:
        tmp.unlink(missing_ok=True)


def list_backups(custom_dir: Optional[str] = None) -> List[Dict[str, Any]]:
    d = backup_dir(custom_dir)
    out = []
    for f in sorted(d.glob("*.db"), key=lambda p: p.stat().st_mtime, reverse=True):
        st = f.stat()
        out.append({"file_name": f.name, "path": str(f), "size_bytes": st.st_size,
                    "created_at": datetime.fromtimestamp(st.st_mtime).isoformat(sep=" ", timespec="seconds")})
    return out


def validate_sqlite_bytes(data: bytes) -> Dict[str, Any]:
    if not data.startswith(b"SQLite format 3\x00"):
        raise BackupError("O arquivo enviado não é um banco SQLite válido.")
    tmp = _db_path().parent / f".restore_check_{datetime.now().strftime('%H%M%S%f')}.db"
    tmp.parent.mkdir(parents=True, exist_ok=True)
    tmp.write_bytes(data)
    try:
        with closing(sqlite3.connect(str(tmp))) as c:
            tables = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if not REQUIRED_TABLES.issubset(tables):
                raise BackupError(f"Backup não contém as tabelas esperadas: {sorted(REQUIRED_TABLES - tables)}")
            n_assets = c.execute("SELECT COUNT(*) FROM assets").fetchone()[0]
            n_exec = c.execute("SELECT COUNT(*) FROM executions").fetchone()[0]
            n_imp = c.execute("SELECT COUNT(*) FROM imports").fetchone()[0]
            integrity = c.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity != "ok":
            raise BackupError(f"Falha na verificação de integridade: {integrity}")
        return {"assets": n_assets, "executions": n_exec, "imports": n_imp}
    finally:
        tmp.unlink(missing_ok=True)


def restore_from_bytes(data: bytes, engine, custom_dir: Optional[str] = None) -> Dict[str, Any]:
    """Replace the current database by the uploaded one (a safety backup is created first)."""
    info = validate_sqlite_bytes(data)
    dst = _db_path()
    safety = None
    if dst.exists():
        safety = create_backup(custom_dir)["path"]
    engine.dispose()  # release every pooled connection before touching the file
    tmp = dst.with_suffix(".restore.tmp")
    tmp.write_bytes(data)
    for side in ("-wal", "-shm"):
        p = Path(str(dst) + side)
        if p.exists():
            p.unlink()
    os.replace(str(tmp), str(dst))  # atomic on Windows and POSIX
    return {"restored": info, "safety_backup": safety}


def _inside(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def restore_from_path(path: str, engine, custom_dir: Optional[str] = None) -> Dict[str, Any]:
    p = Path(path)
    if not p.exists() or p.suffix != ".db":
        raise BackupError("Arquivo de backup não encontrado.")
    allowed = [backup_dir(None)] + ([Path(custom_dir)] if custom_dir else [])
    if not any(_inside(p, root) for root in allowed):
        raise BackupError("Somente arquivos dentro da pasta de backups podem ser restaurados.")
    return restore_from_bytes(p.read_bytes(), engine, custom_dir)

"""SQLAlchemy engine/session. SQLite locally; swap DATABASE_URL for PostgreSQL."""
from __future__ import annotations

from pathlib import Path
from typing import Iterator

from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from .config import settings


class Base(DeclarativeBase):
    pass


def _make_engine(url: str):
    kwargs = {}
    if url.startswith("sqlite"):
        kwargs["connect_args"] = {"check_same_thread": False}
        path = url.replace("sqlite:///", "", 1)
        if path and path != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
    eng = create_engine(url, future=True, **kwargs)
    if url.startswith("sqlite"):
        @event.listens_for(eng, "connect")
        def _sqlite_pragmas(dbapi_conn, _):  # noqa: ANN001
            cur = dbapi_conn.cursor()
            cur.execute("PRAGMA foreign_keys=ON")
            cur.execute("PRAGMA journal_mode=WAL")
            cur.close()
    return eng


engine = _make_engine(settings.DATABASE_URL)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, expire_on_commit=False, future=True)


def get_db() -> Iterator[Session]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db() -> None:
    """Create tables if missing and mark the Alembic revision as current, so a later
    `alembic upgrade head` does not try to recreate them."""
    from . import models  # noqa: F401  (register tables)
    Base.metadata.create_all(bind=engine)
    _stamp_alembic()


def _stamp_alembic() -> None:
    try:
        from sqlalchemy import inspect
        if "alembic_version" in inspect(engine).get_table_names():
            return
        from alembic import command
        from alembic.config import Config
        from .config import BACKEND_DIR
        ini = BACKEND_DIR / "alembic.ini"
        if not ini.exists():
            return
        cfg = Config(str(ini))
        cfg.set_main_option("script_location", str(BACKEND_DIR / "alembic"))
        cfg.set_main_option("sqlalchemy.url", settings.DATABASE_URL.replace("%", "%%"))
        command.stamp(cfg, "head")
    except Exception:  # noqa: BLE001 — stamping is best-effort; never block startup
        import logging
        logging.getLogger("siem").warning("Não foi possível registrar a revisão Alembic (stamp).", exc_info=True)

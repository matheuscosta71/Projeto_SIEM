"""ORM entities: Assets, Executions, Imports, ImportSnapshots, AssetChanges,
ReportHistory, Settings."""
from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import (JSON, Boolean, DateTime, Float, ForeignKey, Index, Integer, LargeBinary, String, Text,
                        UniqueConstraint)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base

# Column definitions shared by Asset and Execution (all text, original values preserved)
RECORD_COLUMNS = [
    "name", "hostname", "zabbix", "model", "ip", "onda", "regiao", "estado", "cidade", "tipo", "criticidade",
    "status", "coletor", "porta", "descoberta", "coleta_config", "logs_siem", "mudanca", "data_prevista",
    "data_real", "responsavel", "validar_evidencia", "observacoes",
]


class _RecordMixin:
    name: Mapped[str | None] = mapped_column(String(255))
    hostname: Mapped[str | None] = mapped_column(String(255))
    zabbix: Mapped[str | None] = mapped_column(String(255))
    model: Mapped[str | None] = mapped_column(String(255))
    ip: Mapped[str | None] = mapped_column(String(64))
    onda: Mapped[str | None] = mapped_column(String(64))
    regiao: Mapped[str | None] = mapped_column(String(64))
    estado: Mapped[str | None] = mapped_column(String(64))
    cidade: Mapped[str | None] = mapped_column(String(128))
    tipo: Mapped[str | None] = mapped_column(String(128))
    criticidade: Mapped[str | None] = mapped_column(String(64))
    status: Mapped[str | None] = mapped_column(String(128))
    coletor: Mapped[str | None] = mapped_column(String(255))
    porta: Mapped[str | None] = mapped_column(String(32))
    descoberta: Mapped[str | None] = mapped_column(String(64))
    coleta_config: Mapped[str | None] = mapped_column(String(64))
    logs_siem: Mapped[str | None] = mapped_column(String(64))
    mudanca: Mapped[str | None] = mapped_column(String(128))
    data_prevista: Mapped[str | None] = mapped_column(String(64))
    data_real: Mapped[str | None] = mapped_column(String(64))
    responsavel: Mapped[str | None] = mapped_column(String(128))
    validar_evidencia: Mapped[str | None] = mapped_column(String(255))
    observacoes: Mapped[str | None] = mapped_column(Text)
    extra: Mapped[dict] = mapped_column(JSON, default=dict)
    first_import_id: Mapped[int | None] = mapped_column(Integer)
    last_import_id: Mapped[int | None] = mapped_column(Integer)
    present_in_last_import: Mapped[bool] = mapped_column(Boolean, default=True)
    updated_at: Mapped[str | None] = mapped_column(String(32))


class Asset(_RecordMixin, Base):
    __tablename__ = "assets"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    __table_args__ = (Index("ix_assets_estado", "estado"), Index("ix_assets_status", "status"),
                      Index("ix_assets_onda", "onda"), Index("ix_assets_regiao", "regiao"))


class Execution(_RecordMixin, Base):
    __tablename__ = "executions"
    asset_id: Mapped[str] = mapped_column(String(64), primary_key=True)  # same identifier as Asset.id
    secondary_rows: Mapped[list] = mapped_column(JSON, default=list)


class Import(Base):
    __tablename__ = "imports"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    file_name: Mapped[str] = mapped_column(String(255))
    file_hash: Mapped[str] = mapped_column(String(64), index=True)
    size_bytes: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
    reference_date: Mapped[str | None] = mapped_column(String(32))
    status: Mapped[str] = mapped_column(String(16), default="confirmed")  # confirmed | failed
    total_assets: Mapped[int] = mapped_column(Integer, default=0)
    total_executed: Mapped[int] = mapped_column(Integer, default=0)
    new_assets: Mapped[int] = mapped_column(Integer, default=0)
    new_executed: Mapped[int] = mapped_column(Integer, default=0)
    total_concluded: Mapped[int] = mapped_column(Integer, default=0)       # executed & concluded
    total_pending: Mapped[int] = mapped_column(Integer, default=0)
    total_blocked: Mapped[int] = mapped_column(Integer, default=0)
    pct_executed: Mapped[float] = mapped_column(Float, default=0.0)
    summary: Mapped[dict] = mapped_column(JSON, default=dict)
    warnings: Mapped[list] = mapped_column(JSON, default=list)
    rules: Mapped[dict] = mapped_column(JSON, default=dict)
    snapshots = relationship("ImportSnapshot", back_populates="import_", cascade="all, delete-orphan")
    changes = relationship("AssetChange", back_populates="import_", cascade="all, delete-orphan")


class ImportSnapshot(Base):
    """Full state (assets + executions) after the import, gzip-compressed JSON."""
    __tablename__ = "import_snapshots"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    import_id: Mapped[int] = mapped_column(ForeignKey("imports.id", ondelete="CASCADE"), index=True)
    kind: Mapped[str] = mapped_column(String(16))   # 'state'
    record_count: Mapped[int] = mapped_column(Integer, default=0)
    payload: Mapped[bytes] = mapped_column(LargeBinary)
    import_ = relationship("Import", back_populates="snapshots")
    __table_args__ = (UniqueConstraint("import_id", "kind", name="uq_snapshot_import_kind"),)


class AssetChange(Base):
    __tablename__ = "asset_changes"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    import_id: Mapped[int] = mapped_column(ForeignKey("imports.id", ondelete="CASCADE"), index=True)
    asset_id: Mapped[str] = mapped_column(String(64), index=True)
    change_type: Mapped[str] = mapped_column(String(32), index=True)
    source: Mapped[str] = mapped_column(String(16))
    field: Mapped[str | None] = mapped_column(String(64))
    old_value: Mapped[str | None] = mapped_column(Text)
    new_value: Mapped[str | None] = mapped_column(Text)
    detail: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
    import_ = relationship("Import", back_populates="changes")


class ReportHistory(Base):
    __tablename__ = "report_history"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
    report_type: Mapped[str] = mapped_column(String(32))   # pdf_executivo | excel_tecnico
    file_name: Mapped[str] = mapped_column(String(255))
    filters: Mapped[dict] = mapped_column(JSON, default=dict)
    options: Mapped[dict] = mapped_column(JSON, default=dict)
    row_count: Mapped[int] = mapped_column(Integer, default=0)
    import_id: Mapped[int | None] = mapped_column(Integer)
    size_bytes: Mapped[int] = mapped_column(Integer, default=0)


class Setting(Base):
    __tablename__ = "settings"
    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[Any] = mapped_column(JSON, nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now, onupdate=datetime.now)

"""PDF / Excel generation and report history."""
from __future__ import annotations

import logging
from typing import List, Optional
from urllib.parse import quote

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from ..core.dataset import Filters
from ..core.excel_report import ALL_COLUMNS, DEFAULT_COLUMNS, EXTRA_LABELS
from ..core.fields import FILTER_FIELDS, label
from ..database import get_db
from ..services import reports

log = logging.getLogger("siem.reports")
router = APIRouter(prefix="/api/reports", tags=["relatorios"])


class FilterBody(BaseModel):
    values: dict[str, List[str]] = Field(default_factory=dict)
    q: Optional[str] = None
    executed: Optional[bool] = None
    pendency: Optional[str] = None
    has_conflict: Optional[bool] = None

    def to_filters(self) -> Filters:
        f = Filters()
        f.values = {k: set(v) for k, v in self.values.items() if k in FILTER_FIELDS and v}
        f.q, f.executed, f.pendency, f.has_conflict = self.q or None, self.executed, self.pendency or None, self.has_conflict
        return f


class PdfRequest(BaseModel):
    filters: FilterBody = Field(default_factory=FilterBody)


class ExcelRequest(BaseModel):
    filters: FilterBody = Field(default_factory=FilterBody)
    scope: str = Field("executados", pattern="^(executados|inventario|pendencias)$")
    columns: Optional[List[str]] = None
    group_by: Optional[str] = Field(None, pattern="^(estado|regiao|onda|status)$")
    sort: Optional[str] = None
    order: str = Field("asc", pattern="^(asc|desc)$")


def _file_response(result: dict) -> Response:
    headers = {"Content-Disposition": f"attachment; filename*=UTF-8''{quote(result['file_name'])}"}
    return Response(content=result["bytes"], media_type=result["media_type"], headers=headers)


@router.post("/pdf")
def pdf(req: PdfRequest, db: Session = Depends(get_db)):
    try:
        return _file_response(reports.generate_pdf(db, req.filters.to_filters()))
    except Exception:  # noqa: BLE001
        log.exception("Falha ao gerar PDF")
        raise HTTPException(500, "Erro ao gerar o PDF.")


@router.post("/excel")
def excel(req: ExcelRequest, db: Session = Depends(get_db)):
    try:
        return _file_response(reports.generate_excel(db, req.filters.to_filters(), scope=req.scope, columns=req.columns,
                                                     group_by=req.group_by, sort=req.sort, order=req.order))
    except Exception:  # noqa: BLE001
        log.exception("Falha ao gerar Excel")
        raise HTTPException(500, "Erro ao gerar o Excel.")


@router.get("/columns")
def columns():
    return {"default": DEFAULT_COLUMNS,
            "all": [{"key": k, "label": EXTRA_LABELS.get(k, label(k))} for k in ALL_COLUMNS]}


@router.get("/history")
def history(db: Session = Depends(get_db)):
    return reports.history(db)

"""Shared FastAPI dependencies (filters parsing)."""
from __future__ import annotations

from typing import Optional

from fastapi import Query

from ..core.dataset import Filters


def filters_dep(
    estado: Optional[str] = Query(None, description="Valores separados por '|'"),
    regiao: Optional[str] = Query(None),
    cidade: Optional[str] = Query(None),
    onda: Optional[str] = Query(None),
    tipo: Optional[str] = Query(None),
    criticidade: Optional[str] = Query(None),
    model: Optional[str] = Query(None, alias="modelo"),
    status: Optional[str] = Query(None),
    coletor: Optional[str] = Query(None),
    descoberta: Optional[str] = Query(None),
    coleta_config: Optional[str] = Query(None),
    logs_siem: Optional[str] = Query(None),
    q: Optional[str] = Query(None, max_length=200),
    executed: Optional[str] = Query(None),
    pendency: Optional[str] = Query(None),
    has_conflict: Optional[str] = Query(None),
) -> Filters:
    return Filters.from_params({
        "estado": estado, "regiao": regiao, "cidade": cidade, "onda": onda, "tipo": tipo,
        "criticidade": criticidade, "model": model, "status": status, "coletor": coletor,
        "descoberta": descoberta, "coleta_config": coleta_config, "logs_siem": logs_siem,
        "q": q, "executed": executed, "pendency": pendency, "has_conflict": has_conflict,
    })

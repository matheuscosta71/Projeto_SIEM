"""Import preview/confirm, import history, snapshots and comparison."""
from __future__ import annotations

import logging
from typing import Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import settings
from ..core.dataset import Filters
from ..core.diff import compare_datasets
from ..core.indicators import compute_indicators
from ..database import get_db
from ..models import AssetChange, Import
from ..services import importer, repository
from .deps import filters_dep

log = logging.getLogger("siem.imports")
router = APIRouter(prefix="/api/imports", tags=["importacao"])


@router.post("/preview")
async def preview(file: UploadFile = File(...), db: Session = Depends(get_db)):
    data = await file.read()
    if len(data) > settings.MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(413, f"Arquivo excede {settings.MAX_UPLOAD_MB} MB.")
    try:
        return importer.preview(db, data, file.filename or "planilha.xlsx")
    except importer.ImportError_ as exc:
        raise HTTPException(422, str(exc))
    except Exception:  # noqa: BLE001
        log.exception("Falha ao gerar prévia de importação")
        raise HTTPException(500, "Erro inesperado ao processar a planilha.")


@router.post("/{token}/confirm")
def confirm(token: str, reference_date: Optional[str] = Form(None), force: bool = Form(False),
            db: Session = Depends(get_db)):
    try:
        return importer.confirm(db, token, reference_date=reference_date, force=force)
    except importer.ImportError_ as exc:
        raise HTTPException(409, str(exc))
    except Exception:  # noqa: BLE001
        log.exception("Falha ao confirmar importação")
        raise HTTPException(500, "Erro ao gravar a importação. Nenhum dado parcial foi confirmado.")


@router.delete("/{token}")
def discard(token: str):
    return {"discarded": importer.discard(token)}


@router.get("")
def list_imports(db: Session = Depends(get_db)):
    return repository.list_imports(db)


@router.get("/compare")
def compare(a: int = Query(...), b: int = Query(...), db: Session = Depends(get_db)):
    if a == b:
        raise HTTPException(400, "Selecione duas importações diferentes.")
    if a > b:
        a, b = b, a
    da = repository.load_snapshot_dataset(db, a)
    dbb = repository.load_snapshot_dataset(db, b)
    if da is None or dbb is None:
        raise HTTPException(404, "Snapshot não encontrado para uma das importações.")
    result = compare_datasets(da, dbb)
    result["import_a"] = repository.import_to_dict(db.get(Import, a))
    result["import_b"] = repository.import_to_dict(db.get(Import, b))
    return result


@router.get("/{import_id}")
def import_detail(import_id: int, change_type: Optional[str] = None, page: int = Query(1, ge=1),
                  page_size: int = Query(50, ge=1, le=500), db: Session = Depends(get_db)):
    imp = db.get(Import, import_id)
    if imp is None:
        raise HTTPException(404, "Importação não encontrada.")
    stmt = select(AssetChange).where(AssetChange.import_id == import_id)
    if change_type:
        stmt = stmt.where(AssetChange.change_type == change_type)
    all_changes = db.execute(stmt.order_by(AssetChange.id)).scalars().all()
    counts = {}
    for c in db.execute(select(AssetChange.change_type).where(AssetChange.import_id == import_id)).scalars():
        counts[c] = counts.get(c, 0) + 1
    start = (page - 1) * page_size
    items = [{"asset_id": c.asset_id, "change_type": c.change_type, "source": c.source, "field": c.field,
              "old_value": c.old_value, "new_value": c.new_value, "detail": c.detail}
             for c in all_changes[start:start + page_size]]
    return {"import": repository.import_to_dict(imp), "change_counts": counts,
            "changes": {"items": items, "total": len(all_changes), "page": page, "page_size": page_size}}


@router.get("/{import_id}/indicators")
def import_indicators(import_id: int, filters: Filters = Depends(filters_dep), db: Session = Depends(get_db)):
    ds = repository.load_snapshot_dataset(db, import_id)
    if ds is None:
        raise HTTPException(404, "Snapshot não encontrado.")
    ind = compute_indicators(ds, filters)
    ind["import"] = repository.import_to_dict(db.get(Import, import_id))
    return ind

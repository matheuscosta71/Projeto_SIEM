"""Indicators, inventory, executions, pendencies, filter options."""
from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from ..core.dataset import PENDENCY_LABELS, Filters, filter_options
from ..core.fields import FIELDS, FILTER_FIELDS
from ..core.indicators import (compute_indicators, executed_summary_rows, inventory_rows, paginate, sort_records)
from ..database import get_db
from ..services import repository
from .deps import filters_dep

router = APIRouter(prefix="/api", tags=["dados"])


def _public(rec: dict) -> dict:
    out = {k: v for k, v in rec.items() if k != "secondary_rows"}
    out["secondary_rows_count"] = len(rec.get("secondary_rows") or [])
    return out


@router.get("/indicators")
def indicators(filters: Filters = Depends(filters_dep), db: Session = Depends(get_db)):
    ds = repository.load_dataset(db)
    ind = compute_indicators(ds, filters)
    ind["evolution"] = evolution_series(db)
    return ind


def evolution_series(db: Session):
    return [{"import_id": i["id"], "date": i["created_at"], "reference_date": i["reference_date"],
             "file_name": i["file_name"], "total_assets": i["total_assets"], "total_executed": i["total_executed"],
             "new_executed": i["new_executed"], "pct_executed": i["pct_executed"],
             "total_concluded": i["total_concluded"]} for i in repository.list_imports(db) if i["status"] == "confirmed"]


@router.get("/filters/options")
def options(db: Session = Depends(get_db)):
    ds = repository.load_dataset(db)
    return {"fields": FILTER_FIELDS, "labels": {k: FIELDS[k]["label"] for k in FILTER_FIELDS},
            "options": filter_options(ds.all_merged()), "pendencies": PENDENCY_LABELS}


@router.get("/assets")
def assets(filters: Filters = Depends(filters_dep), page: int = Query(1, ge=1), page_size: int = Query(25, ge=1, le=500),
           sort: Optional[str] = None, order: str = Query("asc", pattern="^(asc|desc)$"), db: Session = Depends(get_db)):
    ds = repository.load_dataset(db)
    rows = sort_records(inventory_rows(ds, filters), sort, order)
    page_data = paginate(rows, page, page_size)
    page_data["items"] = [_public(r) for r in page_data["items"]]
    return page_data


@router.get("/assets/{asset_id}")
def asset_detail(asset_id: str, db: Session = Depends(get_db)):
    ds = repository.load_dataset(db)
    rec = ds.merged(asset_id)
    if rec is None:
        raise HTTPException(404, "Equipamento não encontrado.")
    imports = {i["id"]: i for i in repository.list_imports(db)}
    def _imp(i):
        if i is None or i not in imports:
            return None
        return {"id": i, "created_at": imports[i]["created_at"], "file_name": imports[i]["file_name"],
                "reference_date": imports[i]["reference_date"]}
    return {
        "record": rec,
        "inventory_record": ds.assets.get(asset_id),
        "execution_record": ds.executions.get(asset_id),
        "history": {
            "first_import": _imp(rec.get("first_import_id")),
            "first_executed_import": _imp(rec.get("first_executed_import_id")),
            "last_import": _imp(rec.get("last_import_id")),
            "changes": repository.asset_history(db, asset_id),
            "updated_at": rec.get("updated_at"),
        },
    }


@router.get("/executions")
def executions(filters: Filters = Depends(filters_dep), page: int = Query(1, ge=1), page_size: int = Query(25, ge=1, le=500),
               sort: Optional[str] = None, order: str = Query("asc", pattern="^(asc|desc)$"), db: Session = Depends(get_db)):
    ds = repository.load_dataset(db)
    rows = sort_records(executed_summary_rows(ds, filters), sort, order)
    page_data = paginate(rows, page, page_size)
    page_data["items"] = [_public(r) for r in page_data["items"]]
    page_data["orphans"] = [_public(r) for r in ds.orphans()]
    return page_data


@router.get("/executions/pendencies")
def pendencies(filters: Filters = Depends(filters_dep), page: int = Query(1, ge=1), page_size: int = Query(25, ge=1, le=500),
               sort: Optional[str] = None, order: str = Query("asc", pattern="^(asc|desc)$"), db: Session = Depends(get_db)):
    ds = repository.load_dataset(db)
    ind = compute_indicators(ds, filters)
    rows = [r for r in executed_summary_rows(ds, filters) if r.get("pendencies")]
    rows = sort_records(rows, sort, order)
    page_data = paginate(rows, page, page_size)
    page_data["items"] = [_public(r) for r in page_data["items"]]
    page_data["counts"] = ind["pendencies"]
    page_data["executed_with_pendencies"] = ind["cards"]["executed_with_pendencies"]
    page_data["total_executed"] = ind["cards"]["total_executed"]
    return page_data

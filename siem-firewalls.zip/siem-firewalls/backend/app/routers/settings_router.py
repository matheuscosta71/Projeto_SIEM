"""Settings, metadata, backup and restore."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import Response
from pydantic import BaseModel
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..config import APP_VERSION, settings
from ..core.fields import FIELDS
from ..database import engine, get_db
from ..models import Asset, AssetChange, Execution, Import, ImportSnapshot
from ..services import backup, repository
from ..services.settings_service import all_settings, get_setting, set_setting

log = logging.getLogger("siem.settings")
router = APIRouter(prefix="/api", tags=["configuracoes"])


@router.get("/meta")
def meta(db: Session = Depends(get_db)):
    last = repository.last_confirmed_import(db)
    path = settings.sqlite_path
    size = path.stat().st_size if path and path.exists() else None
    counts = {
        "assets": db.execute(select(func.count()).select_from(Asset)).scalar_one(),
        "executions": db.execute(select(func.count()).select_from(Execution)).scalar_one(),
        "imports": db.execute(select(func.count()).select_from(Import)).scalar_one(),
        "snapshots": db.execute(select(func.count()).select_from(ImportSnapshot)).scalar_one(),
        "changes": db.execute(select(func.count()).select_from(AssetChange)).scalar_one(),
    }
    return {
        "app": settings.APP_NAME, "version": APP_VERSION, "host": settings.HOST, "port": settings.PORT,
        "database": {"url": _mask(settings.DATABASE_URL), "engine": engine.dialect.name, "size_bytes": size,
                     "path": str(path) if path else None, "counts": counts},
        "last_import": repository.import_to_dict(last) if last else None,
        "fields": {k: v["label"] for k, v in FIELDS.items()},
        "has_data": counts["assets"] > 0,
    }


def _mask(url: str) -> str:
    if "@" in url and "://" in url:
        head, tail = url.split("://", 1)
        creds, host = tail.rsplit("@", 1)
        return f"{head}://***@{host}"
    return url


@router.get("/settings")
def read_settings(db: Session = Depends(get_db)):
    return all_settings(db)


class SettingsUpdate(BaseModel):
    rules: Optional[Dict[str, Any]] = None
    column_mapping: Optional[Dict[str, Dict[str, str]]] = None
    preferences: Optional[Dict[str, Any]] = None
    backup: Optional[Dict[str, Any]] = None
    confirm: bool = False


@router.put("/settings")
def update_settings(body: SettingsUpdate, db: Session = Depends(get_db)):
    critical = body.rules is not None or body.column_mapping is not None or body.backup is not None
    if critical and not body.confirm:
        raise HTTPException(400, "Alterações críticas exigem confirmação explícita (confirm=true).")
    if body.rules is not None:
        current = get_setting(db, "rules") or {}
        merged = {**current, **body.rules}
        if merged.get("precedence") not in ("executados", "inventario"):
            raise HTTPException(422, "precedence deve ser 'executados' ou 'inventario'.")
        if merged.get("dedupe_strategy") not in ("validada", "ultima", "primeira"):
            raise HTTPException(422, "dedupe_strategy inválida.")
        for mkey in ("status_map", "tipo_map", "fabricante_map"):
            m = merged.get(mkey) or {}
            if not isinstance(m, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in m.items()):
                raise HTTPException(422, f"{mkey} deve ser um mapa texto→texto.")
        set_setting(db, "rules", merged)
    if body.column_mapping is not None:
        cm = {"inventario": {}, "executados": {}}
        for sheet in cm:
            for header, canon in (body.column_mapping.get(sheet) or {}).items():
                if canon not in FIELDS:
                    raise HTTPException(422, f"Campo canônico desconhecido: {canon}")
                cm[sheet][str(header)[:120]] = canon
        set_setting(db, "column_mapping", cm)
    if body.preferences is not None:
        current = get_setting(db, "preferences") or {}
        set_setting(db, "preferences", {**current, **body.preferences})
    if body.backup is not None:
        p = body.backup.get("path")
        if p:
            try:
                Path(p).mkdir(parents=True, exist_ok=True)
            except OSError:
                raise HTTPException(422, "Caminho de backup inválido ou sem permissão.")
        set_setting(db, "backup", {"path": p or None})
    db.commit()
    return all_settings(db)


# ---------- backup ----------
def _custom_dir(db: Session) -> Optional[str]:
    return (get_setting(db, "backup") or {}).get("path")


@router.get("/backups")
def list_backups(db: Session = Depends(get_db)):
    try:
        return {"dir": str(backup.backup_dir(_custom_dir(db))), "items": backup.list_backups(_custom_dir(db))}
    except backup.BackupError as exc:
        raise HTTPException(400, str(exc))


@router.post("/backups")
def create_backup(db: Session = Depends(get_db)):
    try:
        return backup.create_backup(_custom_dir(db))
    except backup.BackupError as exc:
        raise HTTPException(400, str(exc))


@router.get("/backups/export")
def export_backup():
    try:
        data = backup.export_backup_bytes()
    except backup.BackupError as exc:
        raise HTTPException(400, str(exc))
    from datetime import datetime
    name = f"siem_firewalls_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
    return Response(content=data, media_type="application/octet-stream",
                    headers={"Content-Disposition": f"attachment; filename={name}"})


@router.post("/backups/restore")
def restore_backup(file: Optional[UploadFile] = File(None), path: Optional[str] = Form(None),
                   confirm: bool = Form(False), db: Session = Depends(get_db)):
    if not confirm:
        raise HTTPException(400, "A restauração substitui o banco atual e exige confirmação explícita.")
    custom = _custom_dir(db)
    db.close()  # release this request's connection before the engine is disposed
    try:
        if file is not None:
            data = file.file.read()
            result = backup.restore_from_bytes(data, engine, custom)
        elif path:
            result = backup.restore_from_path(path, engine, custom)
        else:
            raise HTTPException(400, "Envie um arquivo ou informe o caminho de um backup.")
    except backup.BackupError as exc:
        raise HTTPException(422, str(exc))
    except Exception:  # noqa: BLE001
        log.exception("Falha ao restaurar backup")
        raise HTTPException(500, "Erro ao restaurar o backup.")
    from ..database import init_db
    init_db()
    return result

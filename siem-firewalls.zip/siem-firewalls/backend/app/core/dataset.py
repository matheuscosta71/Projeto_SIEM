"""In-memory dataset: the single place where inventory and executed records are
merged, classified and filtered. Both the live database state and historical
snapshots are turned into a ``Dataset`` so every indicator, table and report
is computed by exactly the same code.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Set

from .fields import CONFLICT_FIELDS, FIELD_ORDER, FILTER_FIELDS
from .normalizer import (NOT_INFORMED, ST_CONCLUIDO, YES, NO, NA, canonical_status, display, fabricante_of,
                         normalize_tipo, norm_key, status_label)


@dataclass
class Rules:
    """Configurable business rules (persisted in Settings)."""
    precedence: str = "executados"            # 'executados' | 'inventario' (field precedence for executed assets)
    dedupe_strategy: str = "validada"          # 'validada' | 'ultima' | 'primeira'
    status_map: Dict[str, str] = field(default_factory=dict)
    tipo_map: Dict[str, str] = field(default_factory=dict)
    fabricante_map: Dict[str, str] = field(default_factory=dict)
    not_started_requires_not_executed: bool = True

    @classmethod
    def from_dict(cls, d: Optional[Dict[str, Any]]) -> "Rules":
        d = d or {}
        r = cls()
        for k in ("precedence", "dedupe_strategy", "status_map", "tipo_map", "fabricante_map",
                  "not_started_requires_not_executed"):
            if k in d and d[k] is not None:
                setattr(r, k, d[k])
        return r

    def to_dict(self) -> Dict[str, Any]:
        return {
            "precedence": self.precedence, "dedupe_strategy": self.dedupe_strategy,
            "status_map": self.status_map, "tipo_map": self.tipo_map, "fabricante_map": self.fabricante_map,
            "not_started_requires_not_executed": self.not_started_requires_not_executed,
        }


# A record is a dict with canonical keys + metadata keys:
#   extra, first_import_id, last_import_id, present_in_last_import, updated_at,
#   (executions only) secondary_rows
Record = Dict[str, Any]


@dataclass
class Dataset:
    assets: Dict[str, Record]
    executions: Dict[str, Record]
    rules: Rules
    last_import_id: Optional[int] = None

    # ---------- merging ----------
    def merged(self, asset_id: str) -> Optional[Dict[str, Any]]:
        a = self.assets.get(asset_id)
        e = self.executions.get(asset_id)
        if a is None and e is None:
            return None
        return merge_record(a, e, self.rules, self.last_import_id)

    def all_merged(self) -> List[Dict[str, Any]]:
        ids = list(self.assets.keys())
        return [merge_record(self.assets[i], self.executions.get(i), self.rules, self.last_import_id) for i in ids]

    def orphans(self) -> List[Dict[str, Any]]:
        """Executed records not present in the inventory."""
        return [merge_record(None, e, self.rules, self.last_import_id)
                for i, e in self.executions.items() if i not in self.assets]


def field_equal(field_name: str, a: Optional[str], b: Optional[str], rules: Rules) -> bool:
    """Semantic equality used for conflict detection (status/tipo compared after equivalence maps)."""
    if field_name == "status":
        return canonical_status(a, rules.status_map) == canonical_status(b, rules.status_map)
    if field_name == "tipo":
        return norm_key(normalize_tipo(a, rules.tipo_map)) == norm_key(normalize_tipo(b, rules.tipo_map))
    return norm_key(a) == norm_key(b)


def _pick(a_val: Optional[str], e_val: Optional[str], precedence: str, executed: bool) -> Optional[str]:
    if not executed:
        return a_val
    if precedence == "inventario":
        return a_val if a_val not in (None, "") else e_val
    return e_val if e_val not in (None, "") else a_val


def merge_record(a: Optional[Record], e: Optional[Record], rules: Rules, last_import_id: Optional[int]) -> Dict[str, Any]:
    executed = e is not None
    in_inventory = a is not None
    src_a = a or {}
    src_e = e or {}
    out: Dict[str, Any] = {}
    for key in FIELD_ORDER:
        out[key] = _pick(src_a.get(key), src_e.get(key), rules.precedence, executed) if in_inventory else src_e.get(key)
    # inventory name vs executed hostname: keep both visible
    out["name"] = src_a.get("name") or src_e.get("hostname") or src_e.get("name")
    out["hostname"] = src_e.get("hostname") or src_a.get("hostname") or src_a.get("name")
    out["zabbix"] = src_e.get("zabbix") or src_a.get("zabbix")

    conflicts: List[Dict[str, Any]] = []
    if executed and in_inventory:
        for f in CONFLICT_FIELDS:
            av, ev = src_a.get(f), src_e.get(f)
            if av not in (None, "") and ev not in (None, "") and not field_equal(f, av, ev, rules):
                conflicts.append({"field": f, "inventario": av, "executados": ev})

    canon = canonical_status(out.get("status"), rules.status_map)
    tipo_norm = normalize_tipo(out.get("tipo"), rules.tipo_map)
    out.update({
        "executed": executed,
        "in_inventory": in_inventory,
        "status_canonical": canon,
        "status_label": status_label(out.get("status"), rules.status_map),
        "tipo_normalizado": tipo_norm,
        "fabricante": fabricante_of(out.get("model"), rules.fabricante_map),
        "conflicts": conflicts,
        "has_conflict": bool(conflicts),
        "inventory_status": src_a.get("status"),
        "executed_status": src_e.get("status"),
        "extra": {**(src_a.get("extra") or {}), **(src_e.get("extra") or {})},
        "first_import_id": src_a.get("first_import_id"),
        "last_import_id": src_a.get("last_import_id"),
        "first_executed_import_id": src_e.get("first_import_id"),
        "present_in_last_import": src_a.get("present_in_last_import", True) if in_inventory else src_e.get("present_in_last_import", True),
        "executed_present_in_last_import": src_e.get("present_in_last_import", True) if executed else None,
        "is_new_executed": executed and last_import_id is not None and src_e.get("first_import_id") == last_import_id,
        "updated_at": src_e.get("updated_at") or src_a.get("updated_at"),
        "secondary_rows": src_e.get("secondary_rows") or [],
    })
    out["pendencies"] = technical_pendencies(out) if executed else []
    return out


def technical_pendencies(rec: Dict[str, Any]) -> List[str]:
    """Technical (SIEM integration) pendencies for an executed record.
    Empty fields are reported as 'not informed', never as failures."""
    p: List[str] = []
    if rec.get("status_canonical") != ST_CONCLUIDO:
        p.append("nao_concluido")
    for key, tag in (("descoberta", "descoberta"), ("coleta_config", "coleta_config"), ("logs_siem", "logs_siem")):
        v = rec.get(key)
        if v is None or v == "":
            p.append(f"{tag}_nao_informado")
        elif v == NO:
            p.append(f"{tag}_nao")
        elif v in (YES, NA):
            pass
        else:
            p.append(f"{tag}_valor_inesperado")
    if not rec.get("coletor") or not rec.get("porta"):
        p.append("campos_tecnicos_incompletos")
    return p


PENDENCY_LABELS = {
    "nao_concluido": "Executado não concluído",
    "descoberta_nao": "Descoberta = Não",
    "descoberta_nao_informado": "Descoberta não informada",
    "descoberta_valor_inesperado": "Descoberta com valor inesperado",
    "coleta_config_nao": "Coleta Config. = Não",
    "coleta_config_nao_informado": "Coleta Config. não informada",
    "coleta_config_valor_inesperado": "Coleta Config. com valor inesperado",
    "logs_siem_nao": "Logs no SIEM = Não",
    "logs_siem_nao_informado": "Logs no SIEM não informado",
    "logs_siem_valor_inesperado": "Logs no SIEM com valor inesperado",
    "campos_tecnicos_incompletos": "Coletor/Porta não preenchidos",
}


# ---------- filtering ----------
@dataclass
class Filters:
    values: Dict[str, Set[str]] = field(default_factory=dict)   # field -> set of accepted display values
    q: Optional[str] = None
    executed: Optional[bool] = None
    pendency: Optional[str] = None     # pendency tag
    has_conflict: Optional[bool] = None

    def is_empty(self) -> bool:
        return not self.values and not self.q and self.executed is None and self.pendency is None and self.has_conflict is None

    def affects_universe(self) -> bool:
        """True when the filter changes the denominator (total de ativos)."""
        return bool(self.values) or bool(self.q) or self.has_conflict is not None

    def describe(self) -> str:
        parts = []
        for f, vals in self.values.items():
            from .fields import label as _label
            parts.append(f"{_label(f)}: {', '.join(sorted(vals))}")
        if self.q:
            parts.append(f"Busca: {self.q}")
        if self.executed is not None:
            parts.append("Executados" if self.executed else "Não executados")
        if self.pendency:
            parts.append(f"Pendência: {PENDENCY_LABELS.get(self.pendency, self.pendency)}")
        return "; ".join(parts) if parts else "Nenhum"

    def to_dict(self) -> Dict[str, Any]:
        return {"values": {k: sorted(v) for k, v in self.values.items()}, "q": self.q, "executed": self.executed,
                "pendency": self.pendency, "has_conflict": self.has_conflict}

    @classmethod
    def from_params(cls, params: Dict[str, Any]) -> "Filters":
        f = cls()
        for key in FILTER_FIELDS:
            raw = params.get(key)
            if raw is None:
                continue
            if isinstance(raw, str):
                items = [x for x in raw.split("|") if x != ""]
            else:
                items = [x for x in raw if x not in (None, "")]
            if items:
                f.values[key] = set(items)
        f.q = (params.get("q") or None)
        ex = params.get("executed")
        if ex in (True, "true", "1", "sim"):
            f.executed = True
        elif ex in (False, "false", "0", "nao"):
            f.executed = False
        f.pendency = params.get("pendency") or None
        hc = params.get("has_conflict")
        if hc in (True, "true", "1"):
            f.has_conflict = True
        elif hc in (False, "false", "0"):
            f.has_conflict = False
        return f


def dimension_value(rec: Dict[str, Any], field_name: str) -> str:
    """Display value used for grouping/filtering a dimension."""
    if field_name == "status":
        return rec.get("status_label") or NOT_INFORMED
    if field_name == "tipo":
        return display(rec.get("tipo_normalizado"))
    return display(rec.get(field_name))


def apply_filters(records: Iterable[Dict[str, Any]], f: Optional[Filters]) -> List[Dict[str, Any]]:
    if f is None or f.is_empty():
        return list(records)
    q = norm_key(f.q) if f.q else None
    out = []
    for r in records:
        ok = True
        for fld, accepted in f.values.items():
            if dimension_value(r, fld) not in accepted:
                ok = False
                break
        if not ok:
            continue
        if f.executed is not None and bool(r.get("executed")) != f.executed:
            continue
        if f.has_conflict is not None and bool(r.get("has_conflict")) != f.has_conflict:
            continue
        if f.pendency and f.pendency not in (r.get("pendencies") or []):
            continue
        if q:
            hay = " ".join(norm_key(r.get(k)) for k in ("id", "name", "hostname", "zabbix", "ip", "cidade"))
            if q not in hay:
                continue
        out.append(r)
    return out


def filter_options(records: Iterable[Dict[str, Any]]) -> Dict[str, List[str]]:
    opts: Dict[str, Set[str]] = {k: set() for k in FILTER_FIELDS}
    for r in records:
        for k in FILTER_FIELDS:
            opts[k].add(dimension_value(r, k))
    def _sort(vals: Set[str]) -> List[str]:
        normal = sorted(v for v in vals if v != NOT_INFORMED)
        return normal + ([NOT_INFORMED] if NOT_INFORMED in vals else [])
    return {k: _sort(v) for k, v in opts.items()}

"""Canonical field definitions and header aliases.

The canonical keys are the only names used inside the application. The Excel
headers are mapped onto these keys through ``ALIASES`` (auto-detection) or via
the manual column mapping stored in Settings.

Aliases are compared after ``squash`` (lowercase, no accents, alphanumerics
only), so "Coleta Config.", "coleta config" and "Coleta  Config" all match.
"""
from __future__ import annotations

import re
import unicodedata
from typing import Dict, List, Optional

# canonical_key -> (display label, aliases)
FIELDS: Dict[str, Dict] = {
    "id": {"label": "ID", "aliases": ["id", "codigo", "cod", "identificador"]},
    "name": {"label": "Nome do Ativo", "aliases": ["nome do ativo", "nome", "ativo", "nome ativo"]},
    "hostname": {"label": "Nome do Ativo / Hostname", "aliases": ["nome do ativo / hostname", "hostname", "host"]},
    "zabbix": {"label": "Nome do Ativo / Zabbix", "aliases": ["nome do ativo / zabbix", "zabbix", "nome zabbix"]},
    "model": {"label": "Fabricante / Modelo", "aliases": ["fabricante / modelo", "modelo", "fabricante modelo", "fabricante"]},
    # "prova" is the real header used for the IP column in the EXECUTADOS sheet
    "ip": {"label": "IP", "aliases": ["ip", "endereco ip", "prova", "ip address"]},
    "onda": {"label": "Onda", "aliases": ["onda", "wave"]},
    "regiao": {"label": "Região", "aliases": ["regiao", "region"]},
    "estado": {"label": "Estado", "aliases": ["estado", "uf", "grupo / uf", "grupo uf", "grupo"]},
    "cidade": {"label": "Cidade", "aliases": ["cidade", "municipio", "localidade"]},
    "tipo": {"label": "Tipo", "aliases": ["tipo", "tipo de instalacao", "tipo instalacao"]},
    "criticidade": {"label": "Criticidade", "aliases": ["criticidade", "criticality"]},
    "status": {"label": "Status Implementação", "aliases": ["status implementacao", "status", "status implantacao"]},
    "coletor": {"label": "Coletor", "aliases": ["coletor", "collector"]},
    "porta": {"label": "Porta", "aliases": ["porta", "port"]},
    "descoberta": {"label": "Descoberta", "aliases": ["descoberta", "discovery"]},
    "coleta_config": {"label": "Coleta Config.", "aliases": ["coleta config", "coleta config.", "coleta de configuracao", "coleta configuracao"]},
    "logs_siem": {"label": "Logs no SIEM?", "aliases": ["logs no siem", "logs no siem?", "logs siem", "logs"]},
    "mudanca": {"label": "Mudança", "aliases": ["mudanca", "change", "chg"]},
    "data_prevista": {"label": "Data Prevista", "aliases": ["data prevista", "previsao"]},
    "data_real": {"label": "Data Real", "aliases": ["data real", "data execucao"]},
    "responsavel": {"label": "Responsável", "aliases": ["responsavel", "owner"]},
    "validar_evidencia": {"label": "Validar Evidência", "aliases": ["validar evidencia", "evidencia"]},
    "observacoes": {"label": "Observações", "aliases": ["observacoes", "observacao", "obs"]},
}

FIELD_ORDER: List[str] = list(FIELDS.keys())

# Fields whose values are "Sim / Não / N/A"
YES_NO_FIELDS = {"descoberta", "coleta_config", "logs_siem"}

# Fields that must always be stored/exported as text (never numbers)
TEXT_FIELDS = {"id", "ip", "porta", "mudanca"}

# Fields used for cross-sheet conflict detection (executed records)
CONFLICT_FIELDS = ["status", "onda", "regiao", "estado", "cidade", "tipo", "criticidade", "model", "hostname"]

# Filterable dimensions
FILTER_FIELDS = [
    "estado", "regiao", "cidade", "onda", "tipo", "criticidade", "model",
    "status", "coletor", "descoberta", "coleta_config", "logs_siem",
]

SHEET_INVENTORY = "inventario"
SHEET_EXECUTED = "executados"
SHEET_ALIASES = {
    SHEET_INVENTORY: ["inventario_ativos", "inventarioativos", "inventario", "ativos", "inventory"],
    SHEET_EXECUTED: ["executados", "executado", "executed"],
}

_SQUASH_RE = re.compile(r"[^a-z0-9]+")


def strip_accents(text: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFKD", text) if not unicodedata.combining(c))


def squash(text: Optional[str]) -> str:
    """Normalize a header/value for comparisons: lowercase, no accents, alnum only."""
    if text is None:
        return ""
    return _SQUASH_RE.sub("", strip_accents(str(text)).lower())


_ALIAS_INDEX: Dict[str, str] = {}
for _key, _meta in FIELDS.items():
    _ALIAS_INDEX[squash(_key)] = _key
    _ALIAS_INDEX[squash(_meta["label"])] = _key
    for _a in _meta["aliases"]:
        _ALIAS_INDEX.setdefault(squash(_a), _key)


def canonical_for_header(header: Optional[str], mapping: Optional[Dict[str, str]] = None) -> Optional[str]:
    """Return the canonical key for an Excel header, honouring a manual mapping first."""
    if header is None:
        return None
    raw = str(header).strip()
    if not raw:
        return None
    if mapping:
        for original, canonical in mapping.items():
            if squash(original) == squash(raw) and canonical in FIELDS:
                return canonical
    return _ALIAS_INDEX.get(squash(raw))


def sheet_kind(title: str) -> Optional[str]:
    s = squash(title)
    for kind, aliases in SHEET_ALIASES.items():
        if s in [squash(a) for a in aliases]:
            return kind
    for kind, aliases in SHEET_ALIASES.items():
        if any(squash(a) in s for a in aliases):
            return kind
    return None


def label(key: str) -> str:
    return FIELDS.get(key, {}).get("label", key)

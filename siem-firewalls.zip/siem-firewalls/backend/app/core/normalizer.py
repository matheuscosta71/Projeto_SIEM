"""Value normalization.

Original values are always preserved as text; normalization produces
*derived* keys used for grouping, filtering and comparisons.
"""
from __future__ import annotations

import datetime as dt
from typing import Any, Dict, Optional

from .fields import squash, strip_accents

YES = "Sim"
NO = "Não"
NA = "N/A"
NOT_INFORMED = "Não informado"

# Canonical status categories
ST_CONCLUIDO = "concluido"
ST_ANDAMENTO = "em_andamento"
ST_PENDENTE = "pendente"
ST_BLOQUEADO = "bloqueado"
ST_NAO_INICIADO = "nao_iniciado"
ST_OUTRO = "outro"

STATUS_LABELS = {
    ST_CONCLUIDO: "Concluído",
    ST_ANDAMENTO: "Em Andamento",
    ST_PENDENTE: "Pendente",
    ST_BLOQUEADO: "Bloqueado",
    ST_NAO_INICIADO: "Não iniciado",
    ST_OUTRO: "Outro",
}

# Default equivalence map (squashed raw value -> canonical). Editable in Settings.
DEFAULT_STATUS_MAP: Dict[str, str] = {
    "concluido": ST_CONCLUIDO, "concluida": ST_CONCLUIDO, "finalizado": ST_CONCLUIDO,
    "finalizada": ST_CONCLUIDO, "done": ST_CONCLUIDO, "completed": ST_CONCLUIDO,
    "emandamento": ST_ANDAMENTO, "andamento": ST_ANDAMENTO, "emexecucao": ST_ANDAMENTO,
    "inprogress": ST_ANDAMENTO, "executando": ST_ANDAMENTO,
    "pendente": ST_PENDENTE, "pending": ST_PENDENTE, "aguardando": ST_PENDENTE,
    "bloqueado": ST_BLOQUEADO, "bloqueada": ST_BLOQUEADO, "impedido": ST_BLOQUEADO,
    "blocked": ST_BLOQUEADO, "falha": ST_BLOQUEADO,
    "naoiniciado": ST_NAO_INICIADO, "naoiniciada": ST_NAO_INICIADO, "notstarted": ST_NAO_INICIADO,
}

# Default equivalence for "Tipo" (squashed -> display). Editable in Settings.
DEFAULT_TIPO_MAP: Dict[str, str] = {
    "subestacao": "SubEstação", "substacao": "SubEstação", "se": "SubEstação",
    "sede": "Sede", "agencia": "Agência", "escritorio": "Escritório",
    "datacenter": "Data Center", "regional": "Regional", "repetidora": "Repetidora",
    "parceiro": "Parceiro", "prodepa": "Prodepa", "clientelivre": "Cliente Livre",
}

# Default equivalence for manufacturer prefix in "Fabricante / Modelo"
DEFAULT_FABRICANTE_MAP: Dict[str, str] = {"fortigate": "fortinet", "fortinet": "fortinet", "ciscoasa": "cisco"}


def to_text(value: Any) -> Optional[str]:
    """Convert any cell value to a trimmed string, preserving IDs/IPs/ports as text."""
    if value is None:
        return None
    if isinstance(value, bool):
        return "Sim" if value else "Não"
    if isinstance(value, float):
        if value != value:  # NaN
            return None
        if value.is_integer():
            return str(int(value))
        return repr(value)
    if isinstance(value, int):
        return str(value)
    if isinstance(value, dt.datetime):
        if value.hour == 0 and value.minute == 0 and value.second == 0:
            return value.date().isoformat()
        return value.isoformat(sep=" ")
    if isinstance(value, dt.date):
        return value.isoformat()
    text = str(value).strip()
    return text or None


def norm_key(value: Optional[str]) -> str:
    """Comparison key for values (case/accents/space-insensitive)."""
    return squash(value)


def normalize_yes_no(value: Optional[str]) -> Optional[str]:
    """Return 'Sim', 'Não', 'N/A', None (not informed) or the original text."""
    if value is None:
        return None
    k = squash(value)
    if k in {"sim", "s", "yes", "y", "ok", "true", "1", "x"}:
        return YES
    if k in {"nao", "n", "no", "false", "0"}:
        return NO
    if k in {"na", "naoaplicavel", "naoseaplica", "notapplicable"}:
        return NA
    return value


def canonical_status(value: Optional[str], status_map: Optional[Dict[str, str]] = None) -> str:
    """Map a raw status to a canonical category. Empty -> nao_iniciado."""
    if value is None or not str(value).strip():
        return ST_NAO_INICIADO
    m = dict(DEFAULT_STATUS_MAP)
    if status_map:
        m.update({squash(k): v for k, v in status_map.items()})
    return m.get(squash(value), ST_OUTRO)


def status_label(value: Optional[str], status_map: Optional[Dict[str, str]] = None) -> str:
    canon = canonical_status(value, status_map)
    if canon == ST_OUTRO and value:
        return str(value)
    return STATUS_LABELS[canon]


def normalize_tipo(value: Optional[str], tipo_map: Optional[Dict[str, str]] = None) -> Optional[str]:
    if value is None:
        return None
    m = dict(DEFAULT_TIPO_MAP)
    if tipo_map:
        m.update({squash(k): v for k, v in tipo_map.items()})
    return m.get(squash(value), str(value).strip())


def fabricante_of(model: Optional[str], fab_map: Optional[Dict[str, str]] = None) -> Optional[str]:
    if not model:
        return None
    prefix = str(model).split("/")[0].strip()
    if not prefix:
        return None
    m = dict(DEFAULT_FABRICANTE_MAP)
    if fab_map:
        m.update({squash(k): v for k, v in fab_map.items()})
    return m.get(squash(prefix), strip_accents(prefix).lower())


def display(value: Optional[str]) -> str:
    return value if value not in (None, "") else NOT_INFORMED


def values_equal(a: Optional[str], b: Optional[str]) -> bool:
    return norm_key(a) == norm_key(b)

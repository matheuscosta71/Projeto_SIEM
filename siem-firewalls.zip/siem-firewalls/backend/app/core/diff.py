"""Import planning: deduplicates sheet rows, compares the parsed workbook with
the current dataset and produces the *next* state plus a change log.

Nothing here touches the database: ``build_plan`` returns a ``ImportPlan`` the
persistence layer applies inside a single transaction.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .dataset import Dataset, Record, Rules, field_equal
from .excel_reader import ParsedWorkbook, SheetData
from .fields import CONFLICT_FIELDS, FIELD_ORDER
from .normalizer import ST_CONCLUIDO, YES, canonical_status, norm_key, squash

TRACKED_FIELDS = [k for k in FIELD_ORDER if k != "id"]


@dataclass
class Change:
    asset_id: str
    change_type: str      # new_asset | new_execution | status_change | field_change | missing_asset | missing_execution | conflict | duplicate | orphan
    source: str           # inventario | executados | cruzamento
    field: Optional[str] = None
    old_value: Optional[str] = None
    new_value: Optional[str] = None
    detail: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {"asset_id": self.asset_id, "change_type": self.change_type, "source": self.source,
                "field": self.field, "old_value": self.old_value, "new_value": self.new_value, "detail": self.detail}


@dataclass
class ImportPlan:
    assets: Dict[str, Record]
    executions: Dict[str, Record]
    changes: List[Change]
    summary: Dict[str, Any]
    warnings: List[str] = field(default_factory=list)
    identical_to_import_id: Optional[int] = None


def _row_score(rec: Record) -> int:
    score = 0
    if squash(rec.get("validar_evidencia")).startswith("validado"):
        score += 8
    if rec.get("logs_siem") == YES:
        score += 4
    if rec.get("descoberta") == YES:
        score += 1
    if rec.get("coleta_config") == YES:
        score += 1
    if canonical_status(rec.get("status")) == ST_CONCLUIDO:
        score += 1
    score += sum(1 for k in TRACKED_FIELDS if rec.get(k) not in (None, "")) * 0  # tie-break handled below
    return score


def _filled(rec: Record) -> int:
    return sum(1 for k in TRACKED_FIELDS if rec.get(k) not in (None, ""))


def dedupe_rows(sheet: SheetData, strategy: str) -> Dict[str, Record]:
    """Collapse duplicate IDs. Returns id -> chosen record (with 'secondary_rows')."""
    groups: Dict[str, List[Record]] = {}
    order: List[str] = []
    for rec in sheet.rows:
        key = rec["id"]
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(rec)
    out: Dict[str, Record] = {}
    for key in order:
        rows = groups[key]
        if len(rows) == 1:
            chosen = rows[0]
        elif strategy == "ultima":
            chosen = rows[-1]
        elif strategy == "primeira":
            chosen = rows[0]
        else:  # validada (default): highest score, then most filled, then first
            chosen = sorted(rows, key=lambda r: (-_row_score(r), -_filled(r), r["_row"]))[0]
        chosen = dict(chosen)
        chosen["secondary_rows"] = [
            {k: v for k, v in r.items() if k not in ("secondary_rows",)} for r in rows if r is not chosen and r["_row"] != chosen["_row"]
        ]
        out[key] = chosen
    return out


def _strip_meta(rec: Record) -> Record:
    return {k: rec.get(k) for k in FIELD_ORDER} | {"extra": rec.get("extra") or {}}


def build_plan(parsed: ParsedWorkbook, current: Dataset, rules: Rules, new_import_id: int,
               known_hashes: Dict[str, int], now_iso: str) -> ImportPlan:
    changes: List[Change] = []
    warnings = list(parsed.warnings)

    identical = known_hashes.get(parsed.file_hash)

    # ----- inventory -----
    next_assets: Dict[str, Record] = {k: dict(v) for k, v in current.assets.items()}
    new_assets = updated_assets = status_changes = 0
    inv_ids: set = set()
    duplicates: List[Dict[str, Any]] = []
    if parsed.inventory:
        for d in parsed.inventory.duplicates:
            duplicates.append({"sheet": "Inventário_Ativos", **d})
            changes.append(Change(d["id"], "duplicate", "inventario", detail=f"ID repetido nas linhas {d['rows']}"))
        inv_rows = dedupe_rows(parsed.inventory, "primeira" if rules.dedupe_strategy == "primeira" else "validada")
        for aid, row in inv_rows.items():
            inv_ids.add(aid)
            data = _strip_meta(row)
            existing = next_assets.get(aid)
            if existing is None:
                rec = {**data, "first_import_id": new_import_id, "last_import_id": new_import_id,
                       "present_in_last_import": True, "updated_at": now_iso}
                next_assets[aid] = rec
                new_assets += 1
                changes.append(Change(aid, "new_asset", "inventario"))
            else:
                changed = False
                for f in TRACKED_FIELDS:
                    old, new = existing.get(f), data.get(f)
                    if norm_key(old) != norm_key(new):
                        changed = True
                        ctype = "status_change" if f == "status" else "field_change"
                        if f == "status":
                            status_changes += 1
                        changes.append(Change(aid, ctype, "inventario", f, old, new))
                if (existing.get("extra") or {}) != (data.get("extra") or {}):
                    changed = True
                if changed:
                    updated_assets += 1
                merged = {**existing, **data, "last_import_id": new_import_id, "present_in_last_import": True,
                          "first_import_id": existing.get("first_import_id") or new_import_id}
                if changed:
                    merged["updated_at"] = now_iso
                next_assets[aid] = merged
        # assets absent from this file are kept, flagged
        missing_assets = 0
        for aid, rec in next_assets.items():
            if aid not in inv_ids:
                if rec.get("present_in_last_import", True):
                    changes.append(Change(aid, "missing_asset", "inventario", detail="Ausente no inventário desta planilha (mantido)"))
                rec["present_in_last_import"] = False
                missing_assets += 1
    else:
        missing_assets = 0

    # ----- executed (cumulative) -----
    next_exec: Dict[str, Record] = {k: dict(v) for k, v in current.executions.items()}
    new_exec = updated_exec = exec_status_changes = 0
    orphans: List[str] = []
    missing_exec = 0
    if parsed.executed:
        for d in parsed.executed.duplicates:
            duplicates.append({"sheet": "EXECUTADOS", **d})
            changes.append(Change(d["id"], "duplicate", "executados",
                                  detail=f"ID repetido nas linhas {d['rows']} (estratégia: {rules.dedupe_strategy})"))
        exec_rows = dedupe_rows(parsed.executed, rules.dedupe_strategy)
        for aid, row in exec_rows.items():
            data = _strip_meta(row)
            data["secondary_rows"] = row.get("secondary_rows") or []
            existing = next_exec.get(aid)
            if aid not in next_assets:
                orphans.append(aid)
                changes.append(Change(aid, "orphan", "cruzamento", detail="Executado sem cadastro no inventário"))
            if existing is None:
                next_exec[aid] = {**data, "first_import_id": new_import_id, "last_import_id": new_import_id,
                                  "present_in_last_import": True, "updated_at": now_iso}
                new_exec += 1
                changes.append(Change(aid, "new_execution", "executados"))
            else:
                changed = False
                for f in TRACKED_FIELDS:
                    old, new = existing.get(f), data.get(f)
                    if norm_key(old) != norm_key(new):
                        changed = True
                        ctype = "status_change" if f == "status" else "field_change"
                        if f == "status":
                            exec_status_changes += 1
                        changes.append(Change(aid, ctype, "executados", f, old, new))
                if changed:
                    updated_exec += 1
                merged = {**existing, **data, "last_import_id": new_import_id, "present_in_last_import": True,
                          "first_import_id": existing.get("first_import_id") or new_import_id}
                if changed:
                    merged["updated_at"] = now_iso
                next_exec[aid] = merged
        for aid, rec in next_exec.items():
            if aid not in exec_rows:
                if rec.get("present_in_last_import", True):
                    changes.append(Change(aid, "missing_execution", "executados",
                                          detail="Executado anteriormente, ausente na aba EXECUTADOS desta planilha (mantido)"))
                rec["present_in_last_import"] = False
                missing_exec += 1
        if missing_exec:
            warnings.append(f"{missing_exec} equipamento(s) executado(s) anteriormente não constam na aba EXECUTADOS "
                            "desta planilha. Como a aba é acumulativa, isso pode indicar um arquivo desatualizado.")

    # ----- cross-sheet conflicts (executed records) -----
    conflicts = 0
    for aid, e in next_exec.items():
        a = next_assets.get(aid)
        if not a:
            continue
        for f in CONFLICT_FIELDS:
            av, ev = a.get(f), e.get(f)
            if av not in (None, "") and ev not in (None, "") and not field_equal(f, av, ev, rules):
                conflicts += 1
                changes.append(Change(aid, "conflict", "cruzamento", f, av, ev,
                                      detail=f"Divergência entre abas (precedência: {rules.precedence})"))

    next_ds = Dataset(assets=next_assets, executions=next_exec, rules=rules, last_import_id=new_import_id)
    from .indicators import compute_indicators  # local import to avoid cycle
    ind = compute_indicators(next_ds)
    cards = ind["cards"]

    unique_inv = len(inv_ids) if parsed.inventory else len(current.assets)
    unique_exec = len(exec_rows) if parsed.executed else len(current.executions)

    summary = {
        "file_name": parsed.file_name, "file_hash": parsed.file_hash, "size_bytes": parsed.size_bytes,
        "sheets": parsed.sheet_titles,
        "inventory_sheet": {"title": parsed.inventory.title, "header_row": parsed.inventory.header_row,
                             "rows": len(parsed.inventory.rows), "unique_ids": unique_inv,
                             "columns": parsed.inventory.columns, "unmapped": parsed.inventory.unmapped} if parsed.inventory else None,
        "executed_sheet": {"title": parsed.executed.title, "header_row": parsed.executed.header_row,
                            "rows": len(parsed.executed.rows), "unique_ids": unique_exec,
                            "columns": parsed.executed.columns, "unmapped": parsed.executed.unmapped} if parsed.executed else None,
        "total_assets": cards["total_assets"],
        "total_executed": cards["total_executed"],
        "pct_executed": cards["pct_executed"],
        "new_assets": new_assets,
        "new_executed": new_exec,
        "updated_assets": updated_assets,
        "updated_executions": updated_exec,
        "status_changes": status_changes + exec_status_changes,
        "duplicates": duplicates,
        "duplicates_count": len(duplicates),
        "orphans": orphans,
        "orphans_count": len(orphans),
        "missing_assets": missing_assets,
        "missing_executions": missing_exec,
        "conflicts": conflicts,
        "executed_concluded": cards["executed_concluded"],
        "executed_not_concluded": cards["executed_not_concluded"],
        "concluded_inventory": cards["concluded_inventory"],
        "pending": cards["pending"],
        "blocked": cards["blocked"],
        "in_progress": cards["in_progress"],
        "not_started": cards["not_started"],
        "has_changes": bool(new_assets or new_exec or updated_assets or updated_exec),
        "identical_to_import_id": identical,
        "_provisional_import_id": new_import_id,
    }
    if identical:
        warnings.insert(0, f"Este arquivo é idêntico (mesmo hash) ao da importação #{identical}. "
                           "Ele não gera novas execuções.")
    elif not summary["has_changes"] and (current.assets or current.executions):
        warnings.insert(0, "Nenhuma alteração detectada em relação à última importação confirmada.")

    return ImportPlan(assets=next_assets, executions=next_exec, changes=changes, summary=summary,
                      warnings=warnings, identical_to_import_id=identical)


def compare_datasets(a: Dataset, b: Dataset) -> Dict[str, Any]:
    """Compare two historical states (A = older, B = newer)."""
    new_assets = sorted(set(b.assets) - set(a.assets), key=_natural)
    removed_assets = sorted(set(a.assets) - set(b.assets), key=_natural)
    first_executed = sorted(set(b.executions) - set(a.executions), key=_natural)
    status_changes, divergences, dropped_from_file = [], [], []
    for aid in set(a.assets) & set(b.assets):
        ma, mb = a.merged(aid), b.merged(aid)
        if norm_key(ma.get("status")) != norm_key(mb.get("status")):
            status_changes.append({"asset_id": aid, "old": ma.get("status"), "new": mb.get("status")})
        for f in TRACKED_FIELDS:
            if f == "status":
                continue
            if norm_key(ma.get(f)) != norm_key(mb.get(f)):
                divergences.append({"asset_id": aid, "field": f, "old": ma.get(f), "new": mb.get(f)})
        if ma.get("present_in_last_import", True) and not mb.get("present_in_last_import", True):
            dropped_from_file.append(aid)
    from .indicators import compute_indicators
    return {
        "a": compute_indicators(a)["cards"], "b": compute_indicators(b)["cards"],
        "new_assets": new_assets, "removed_assets": removed_assets, "first_executed": first_executed,
        "status_changes": status_changes, "dropped_from_file": dropped_from_file, "divergences": divergences,
        "counts": {"new_assets": len(new_assets), "first_executed": len(first_executed),
                   "status_changes": len(status_changes), "dropped_from_file": len(dropped_from_file),
                   "divergences": len(divergences)},
    }


def _natural(value: str):
    head, _, tail = value.rpartition("-")
    return (head, int(tail)) if tail.isdigit() else (value, 0)

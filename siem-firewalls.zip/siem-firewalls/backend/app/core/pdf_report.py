"""Executive PDF — single A4 landscape page, generated locally with ReportLab.
Receives the *same* indicators dict used by the Executados dashboard."""
from __future__ import annotations

import io
from datetime import datetime
from typing import Any, Dict, List, Optional

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.pdfgen import canvas

# Palette aligned with the dashboard
BLUE = colors.HexColor("#2563EB")
PURPLE = colors.HexColor("#7C3AED")
GREEN = colors.HexColor("#16A34A")
AMBER = colors.HexColor("#D97706")
RED = colors.HexColor("#DC2626")
GRAY = colors.HexColor("#6B7280")
GRAY_LIGHT = colors.HexColor("#E5E7EB")
GRAY_BG = colors.HexColor("#F3F4F6")
TEXT = colors.HexColor("#111827")
WHITE = colors.white


def _fmt_int(n: int) -> str:
    return f"{n:,}".replace(",", ".")


def _fmt_pct(p: float) -> str:
    return f"{p:.2f}".replace(".", ",") + "%"


def _fit(text: str, max_chars: int) -> str:
    text = str(text)
    return text if len(text) <= max_chars else text[: max_chars - 1] + "…"


def build_executive_pdf(indicators: Dict[str, Any], *, generated_at: Optional[datetime] = None,
                        last_import: Optional[Dict[str, Any]] = None, filters_text: str = "Nenhum") -> bytes:
    generated_at = generated_at or datetime.now()
    cards = indicators["cards"]
    dist = indicators["distributions"]

    buf = io.BytesIO()
    W, H = landscape(A4)
    c = canvas.Canvas(buf, pagesize=(W, H))
    c.setTitle("SIEM Firewalls — Relatório Executivo")
    c.setAuthor("SIEM Firewalls")
    margin = 36

    # ---- header ----
    y = H - margin
    c.setFillColor(TEXT)
    c.setFont("Helvetica-Bold", 18)
    c.drawString(margin, y - 14, "SIEM Firewalls")
    c.setFont("Helvetica", 11)
    c.setFillColor(GRAY)
    c.drawString(margin, y - 30, "Relatório Executivo — Acompanhamento de Execuções")
    c.setFont("Helvetica", 8.5)
    ref = "—"
    if last_import:
        ref = f"#{last_import.get('id')} · {last_import.get('file_name', '')} · {last_import.get('created_at', '')}"
    right_lines = [
        f"Data de geração: {generated_at.strftime('%d/%m/%Y %H:%M')}",
        f"Última importação: {_fit(ref, 90)}",
        f"Filtros aplicados: {_fit(filters_text, 90)}",
    ]
    for i, line in enumerate(right_lines):
        c.drawRightString(W - margin, y - 10 - i * 11, line)
    c.setStrokeColor(GRAY_LIGHT)
    c.setLineWidth(0.8)
    c.line(margin, y - 40, W - margin, y - 40)

    # ---- six KPI cards (2 x 3) ----
    cards_def = [
        ("Total de Ativos", _fmt_int(cards["total_assets"]), BLUE, "universo do inventário" + (" (filtrado)" if indicators.get("universe_filtered") else "")),
        ("Total Executado Acumulado", _fmt_int(cards["total_executed"]), PURPLE, "únicos em EXECUTADOS e no inventário"),
        ("Percentual Executado", _fmt_pct(cards["pct_executed"]), GREEN, "executados ÷ ativos"),
        ("Novos Executados — Última Carga", _fmt_int(cards["new_executed_last_import"]), AMBER, "primeira aparição na última importação"),
        ("Executados e Concluídos", _fmt_int(cards["executed_concluded"]), GREEN, "status = Concluído"),
        ("Executados Não Concluídos", _fmt_int(cards["executed_not_concluded"]), AMBER, "executados com status ≠ Concluído"),
    ]
    top = y - 52
    card_w = (W - 2 * margin - 2 * 10) / 3
    card_h = 62
    for i, (title, value, color, hint) in enumerate(cards_def):
        row, col = divmod(i, 3)
        x = margin + col * (card_w + 10)
        cy = top - row * (card_h + 8) - card_h
        c.setFillColor(WHITE)
        c.setStrokeColor(GRAY_LIGHT)
        c.roundRect(x, cy, card_w, card_h, 6, stroke=1, fill=1)
        c.setFillColor(color)
        c.roundRect(x, cy, 4, card_h, 2, stroke=0, fill=1)
        c.setFillColor(GRAY)
        c.setFont("Helvetica", 8.5)
        c.drawString(x + 14, cy + card_h - 16, title)
        c.setFillColor(TEXT)
        c.setFont("Helvetica-Bold", 20)
        c.drawString(x + 14, cy + 20, value)
        c.setFillColor(GRAY)
        c.setFont("Helvetica", 7.5)
        c.drawString(x + 14, cy + 8, hint)

    # ---- progress bar ----
    py = top - 2 * (card_h + 8) - 14
    c.setFillColor(TEXT)
    c.setFont("Helvetica-Bold", 9)
    c.drawString(margin, py, "Progresso geral da execução")
    c.setFont("Helvetica", 9)
    c.drawRightString(W - margin, py, f"{_fmt_int(cards['total_executed'])} de {_fmt_int(cards['total_assets'])} · {_fmt_pct(cards['pct_executed'])}")
    bar_y = py - 14
    bar_h = 10
    bar_w = W - 2 * margin
    c.setFillColor(GRAY_BG)
    c.roundRect(margin, bar_y, bar_w, bar_h, 5, stroke=0, fill=1)
    frac = min(1.0, cards["pct_executed"] / 100.0)
    if frac > 0:
        c.setFillColor(GREEN)
        c.roundRect(margin, bar_y, max(6, bar_w * frac), bar_h, 5, stroke=0, fill=1)

    # ---- three compact distributions ----
    sec_top = bar_y - 22
    sec_bottom = margin + 22
    sec_h = sec_top - sec_bottom
    col_w = (W - 2 * margin - 2 * 14) / 3
    sections = [("Executados por UF", dist["estado"]), ("Executados por Região", dist["regiao"]),
                ("Executados por Onda", dist["onda"])]
    total_exec = cards["total_executed"]
    for i, (title, rows) in enumerate(sections):
        x = margin + i * (col_w + 14)
        c.setFillColor(TEXT)
        c.setFont("Helvetica-Bold", 9.5)
        c.drawString(x, sec_top - 10, title)
        c.setFillColor(GRAY)
        c.setFont("Helvetica", 7.5)
        c.drawRightString(x + col_w, sec_top - 10, f"Total: {_fmt_int(total_exec)}")
        c.setStrokeColor(GRAY_LIGHT)
        c.line(x, sec_top - 15, x + col_w, sec_top - 15)
        _draw_bars(c, x, sec_top - 22, col_w, sec_h - 30, rows, total_exec)

    # ---- footer ----
    c.setFillColor(GRAY)
    c.setFont("Helvetica", 7.5)
    c.drawString(margin, margin - 6, "Fonte: SIEM Firewalls — Base EXECUTADOS.")
    c.drawRightString(W - margin, margin - 6, "Página 1 de 1")
    c.showPage()
    c.save()
    return buf.getvalue()


def _draw_bars(c: canvas.Canvas, x: float, top: float, width: float, height: float,
               rows: List[Dict[str, Any]], total_exec: int) -> None:
    """Horizontal bars: label | bar | count (pct of executed). Rows with 0 executed are
    shown but compacted; list is capped to fit the area."""
    rows = [r for r in rows if r["executed"] > 0] or rows[:1]
    # adaptive row height: fill the available area without exaggerated blank space
    row_h = max(15.0, min(30.0, height / (len(rows) + 0.5)))
    max_rows = max(1, int(height // row_h))
    shown = rows[:max_rows]
    hidden = rows[max_rows:]
    if hidden:
        shown = rows[:max_rows - 1]
        hidden = rows[max_rows - 1:]
    label_w = 78
    value_w = 64
    bar_w = width - label_w - value_w - 8
    max_val = max([r["executed"] for r in shown] + [1])
    y = top
    bar_h = 8 if row_h < 20 else 11
    for r in shown:
        yy = y - row_h + (row_h - bar_h) / 2
        c.setFillColor(TEXT)
        c.setFont("Helvetica", 8.5)
        c.drawString(x, yy + 2, _fit(r["label"], 16))
        c.setFillColor(GRAY_BG)
        c.roundRect(x + label_w, yy, bar_w, bar_h, 3, stroke=0, fill=1)
        w = bar_w * (r["executed"] / max_val) if max_val else 0
        if w > 0:
            c.setFillColor(PURPLE)
            c.roundRect(x + label_w, yy, max(3, w), bar_h, 3, stroke=0, fill=1)
        pct = (r["executed"] * 100.0 / total_exec) if total_exec else 0
        c.setFillColor(GRAY)
        c.setFont("Helvetica", 8)
        c.drawRightString(x + width, yy + 2, f"{_fmt_int(r['executed'])} ({pct:.1f}%)".replace(".", ","))
        y -= row_h
    if hidden:
        other = sum(r["executed"] for r in hidden)
        yy = y - row_h + 3
        c.setFillColor(GRAY)
        c.setFont("Helvetica-Oblique", 7.5)
        c.drawString(x, yy + 2, f"+{len(hidden)} outros")
        pct = (other * 100.0 / total_exec) if total_exec else 0
        c.drawRightString(x + width, yy + 2, f"{_fmt_int(other)} ({pct:.1f}%)".replace(".", ","))

"""Technical Excel export (openpyxl) — Resumo + Executados sheets, optional
per-group sheets. All text cells are protected against formula injection."""
from __future__ import annotations

import io
from datetime import datetime
from typing import Any, Dict, Iterable, List, Optional

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from .fields import FIELD_ORDER, TEXT_FIELDS, label
from .normalizer import ST_ANDAMENTO, ST_BLOQUEADO, ST_CONCLUIDO, ST_NAO_INICIADO, ST_PENDENTE

HEADER_FILL = PatternFill("solid", fgColor="1E3A8A")   # dark blue
HEADER_FONT = Font(color="FFFFFF", bold=True)
THIN = Side(style="thin", color="D1D5DB")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
STATUS_FILLS = {
    ST_CONCLUIDO: PatternFill("solid", fgColor="DCFCE7"),
    ST_ANDAMENTO: PatternFill("solid", fgColor="FEF3C7"),
    ST_PENDENTE: PatternFill("solid", fgColor="FFEDD5"),
    ST_BLOQUEADO: PatternFill("solid", fgColor="FEE2E2"),
    ST_NAO_INICIADO: PatternFill("solid", fgColor="F3F4F6"),
}

DEFAULT_COLUMNS = ["id", "name", "zabbix", "model", "ip", "onda", "regiao", "estado", "cidade", "criticidade",
                   "status", "coletor", "porta", "descoberta", "coleta_config", "logs_siem", "mudanca"]
ALL_COLUMNS = ["id", "name", "hostname", "zabbix", "model", "ip", "onda", "regiao", "estado", "cidade", "tipo",
               "criticidade", "status", "coletor", "porta", "descoberta", "coleta_config", "logs_siem", "mudanca",
               "data_prevista", "data_real", "responsavel", "validar_evidencia", "observacoes", "executed",
               "has_conflict", "pendencies"]
EXTRA_LABELS = {"executed": "Executado", "has_conflict": "Conflito entre abas", "pendencies": "Pendências técnicas"}


def safe_text(value: Any) -> Any:
    """Prevent formula injection: prefix dangerous leading characters."""
    if value is None:
        return None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return value
    s = str(value)
    if s and s[0] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + s
    return s


def _col_label(key: str) -> str:
    return EXTRA_LABELS.get(key, label(key))


def _cell_value(rec: Dict[str, Any], key: str) -> Any:
    if key == "executed":
        return "Sim" if rec.get("executed") else "Não"
    if key == "has_conflict":
        return "Sim" if rec.get("has_conflict") else "Não"
    if key == "pendencies":
        from .dataset import PENDENCY_LABELS
        return "; ".join(PENDENCY_LABELS.get(p, p) for p in rec.get("pendencies") or []) or None
    if key == "status":
        return rec.get("status")
    return rec.get(key)


def _write_table(ws, records: Iterable[Dict[str, Any]], columns: List[str], start_row: int = 1) -> None:
    headers = [_col_label(k) for k in columns]
    for c, h in enumerate(headers, start=1):
        cell = ws.cell(row=start_row, column=c, value=h)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(vertical="center")
        cell.border = BORDER
    widths = [len(h) for h in headers]
    r = start_row
    for rec in records:
        r += 1
        for c, key in enumerate(columns, start=1):
            value = _cell_value(rec, key)
            cell = ws.cell(row=r, column=c)
            if key in TEXT_FIELDS or key in ("mudanca",):
                cell.number_format = "@"
                cell.value = safe_text(value) if value is not None else None
            else:
                cell.value = safe_text(value)
            cell.border = BORDER
            if key == "status":
                fill = STATUS_FILLS.get(rec.get("status_canonical"))
                if fill:
                    cell.fill = fill
            if value is not None:
                widths[c - 1] = max(widths[c - 1], min(60, len(str(value))))
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = max(8, min(60, w + 2))
    ws.freeze_panes = ws.cell(row=start_row + 1, column=1)
    if r >= start_row:
        ws.auto_filter.ref = f"A{start_row}:{get_column_letter(len(columns))}{max(r, start_row + 1)}"


def _write_summary(ws, indicators: Dict[str, Any], generated_at: datetime, filters_text: str,
                   last_import: Optional[Dict[str, Any]]) -> None:
    cards = indicators["cards"]
    ws["A1"] = "SIEM Firewalls — Relatório Técnico de Executados"
    ws["A1"].font = Font(bold=True, size=14)
    rows = [
        ("Data de geração", generated_at.strftime("%d/%m/%Y %H:%M")),
        ("Última importação", f"#{last_import['id']} · {last_import.get('file_name', '')} · {last_import.get('created_at', '')}" if last_import else "—"),
        ("Filtros aplicados", filters_text),
        ("Universo filtrado", "Sim" if indicators.get("universe_filtered") else "Não"),
        ("", ""),
        ("Total de ativos", cards["total_assets"]),
        ("Total executado acumulado", cards["total_executed"]),
        ("Percentual executado (%)", cards["pct_executed"]),
        ("Novos executados — última carga", cards["new_executed_last_import"]),
        ("Executados e concluídos", cards["executed_concluded"]),
        ("Executados não concluídos", cards["executed_not_concluded"]),
    ]
    r = 3
    for k, v in rows:
        ws.cell(row=r, column=1, value=safe_text(k)).font = Font(bold=True)
        ws.cell(row=r, column=2, value=safe_text(v))
        r += 1
    for title, key in (("Distribuição por UF", "estado"), ("Distribuição por Região", "regiao"), ("Distribuição por Onda", "onda")):
        r += 1
        ws.cell(row=r, column=1, value=title).font = Font(bold=True, size=11)
        r += 1
        for c, h in enumerate(["Valor", "Total previsto", "Executados", "Restante", "% executado"], start=1):
            cell = ws.cell(row=r, column=c, value=h)
            cell.fill = HEADER_FILL
            cell.font = HEADER_FONT
            cell.border = BORDER
        for d in indicators["distributions"][key]:
            r += 1
            for c, v in enumerate([d["label"], d["total"], d["executed"], d["remaining"], d["pct"]], start=1):
                cell = ws.cell(row=r, column=c, value=safe_text(v))
                cell.border = BORDER
    ws.column_dimensions["A"].width = 34
    for col in "BCDE":
        ws.column_dimensions[col].width = 18


def build_technical_excel(records: List[Dict[str, Any]], indicators: Dict[str, Any], *,
                          columns: Optional[List[str]] = None, generated_at: Optional[datetime] = None,
                          filters_text: str = "Nenhum", last_import: Optional[Dict[str, Any]] = None,
                          group_by: Optional[str] = None, sheet_title: str = "Executados") -> bytes:
    generated_at = generated_at or datetime.now()
    columns = [c for c in (columns or DEFAULT_COLUMNS) if c in ALL_COLUMNS] or DEFAULT_COLUMNS
    wb = Workbook()
    ws_sum = wb.active
    ws_sum.title = "Resumo"
    _write_summary(ws_sum, indicators, generated_at, filters_text, last_import)

    ws = wb.create_sheet(sheet_title[:31])
    _write_table(ws, records, columns)

    if group_by:
        from .dataset import dimension_value
        groups: Dict[str, List[Dict[str, Any]]] = {}
        for rec in records:
            groups.setdefault(dimension_value(rec, group_by), []).append(rec)
        used = {"Resumo", ws.title}
        for g, recs in sorted(groups.items(), key=lambda kv: (-len(kv[1]), kv[0])):
            title = _safe_sheet_title(f"{label(group_by)} - {g}", used)
            used.add(title)
            _write_table(wb.create_sheet(title), recs, columns)

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _safe_sheet_title(title: str, used: set) -> str:
    for ch in '[]:*?/\\':
        title = title.replace(ch, "-")
    title = title[:31] or "Grupo"
    base, n = title, 2
    while title in used:
        suffix = f" ({n})"
        title = base[: 31 - len(suffix)] + suffix
        n += 1
    return title

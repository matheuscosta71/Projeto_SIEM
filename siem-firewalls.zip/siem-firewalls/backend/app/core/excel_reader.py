"""Excel reading: sheet detection, header-row detection, column mapping and
row extraction. Produces plain Python structures (no DB dependency).
"""
from __future__ import annotations

import hashlib
import io
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import openpyxl

from .fields import (FIELDS, SHEET_EXECUTED, SHEET_INVENTORY, YES_NO_FIELDS,
                     canonical_for_header, sheet_kind, squash)
from .normalizer import normalize_yes_no, to_text

MAX_HEADER_SCAN_ROWS = 40
MIN_HEADER_MATCHES = 3
ALLOWED_EXTENSIONS = {".xlsx", ".xlsm"}


class ExcelReadError(Exception):
    """Raised for structural problems with the uploaded workbook."""


@dataclass
class SheetData:
    kind: str                       # 'inventario' | 'executados'
    title: str                      # original sheet title
    header_row: int                 # 1-based row index of the header
    columns: Dict[str, str]         # original header -> canonical key (mapped columns)
    unmapped: List[str]             # original headers kept as extra
    rows: List[Dict[str, Any]]      # records: canonical keys + 'extra' + '_row'
    duplicates: List[Dict[str, Any]] = field(default_factory=list)  # ids repeated in this sheet
    missing_id_rows: int = 0


@dataclass
class ParsedWorkbook:
    file_name: str
    file_hash: str
    size_bytes: int
    inventory: Optional[SheetData]
    executed: Optional[SheetData]
    sheet_titles: List[str]
    warnings: List[str] = field(default_factory=list)


def file_sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _detect_header_row(ws, mapping: Optional[Dict[str, str]]) -> Tuple[int, List[Optional[str]]]:
    best_row, best_score, best_headers = None, 0, None
    for idx, row in enumerate(ws.iter_rows(min_row=1, max_row=MAX_HEADER_SCAN_ROWS, values_only=True), start=1):
        headers = [to_text(c) for c in row]
        canon = [canonical_for_header(h, mapping) for h in headers]
        score = len({c for c in canon if c})
        has_id = "id" in canon
        if has_id and score >= MIN_HEADER_MATCHES:
            return idx, headers
        if score > best_score:
            best_row, best_score, best_headers = idx, score, headers
    if best_row is not None and best_score >= MIN_HEADER_MATCHES:
        return best_row, best_headers
    raise ExcelReadError(
        f"Não foi possível localizar a linha de cabeçalho na aba '{ws.title}' "
        f"(esperado ao menos {MIN_HEADER_MATCHES} colunas reconhecidas, incluindo 'ID')."
    )


def _read_sheet(ws, kind: str, mapping: Optional[Dict[str, str]]) -> SheetData:
    header_row, headers = _detect_header_row(ws, mapping)
    columns: Dict[str, str] = {}
    unmapped: List[str] = []
    col_index: List[Tuple[int, Optional[str], str]] = []  # (col idx, canonical, original header)
    seen_canon = set()
    for i, h in enumerate(headers):
        if h is None:
            continue
        canon = canonical_for_header(h, mapping)
        if canon and canon not in seen_canon:
            columns[h] = canon
            seen_canon.add(canon)
            col_index.append((i, canon, h))
        else:
            unmapped.append(h)
            col_index.append((i, None, h))
    if "id" not in seen_canon:
        raise ExcelReadError(f"A aba '{ws.title}' não possui coluna 'ID' reconhecida.")

    rows: List[Dict[str, Any]] = []
    missing_id = 0
    for r_idx, row in enumerate(ws.iter_rows(min_row=header_row + 1, values_only=True), start=header_row + 1):
        if row is None or all(c is None or (isinstance(c, str) and not c.strip()) for c in row):
            continue
        rec: Dict[str, Any] = {k: None for k in FIELDS}
        extra: Dict[str, Optional[str]] = {}
        for i, canon, original in col_index:
            value = to_text(row[i]) if i < len(row) else None
            if canon:
                if canon in YES_NO_FIELDS:
                    value = normalize_yes_no(value)
                rec[canon] = value
            else:
                if value is not None:
                    extra[original] = value
        rec["extra"] = extra
        rec["_row"] = r_idx
        if not rec["id"]:
            missing_id += 1
            continue
        rec["id"] = str(rec["id"]).strip()
        rows.append(rec)

    # duplicate ids inside the sheet
    by_id: Dict[str, List[Dict[str, Any]]] = {}
    for rec in rows:
        by_id.setdefault(squash(rec["id"]), []).append(rec)
    duplicates = [
        {"id": group[0]["id"], "rows": [g["_row"] for g in group], "count": len(group)}
        for group in by_id.values() if len(group) > 1
    ]
    return SheetData(kind=kind, title=ws.title, header_row=header_row, columns=columns,
                     unmapped=unmapped, rows=rows, duplicates=duplicates, missing_id_rows=missing_id)


def parse_workbook(data: bytes, file_name: str, column_mapping: Optional[Dict[str, Dict[str, str]]] = None,
                   max_size_bytes: int = 50 * 1024 * 1024) -> ParsedWorkbook:
    """Parse the workbook bytes. ``column_mapping`` is {'inventario': {header: canonical}, 'executados': {...}}."""
    if not data:
        raise ExcelReadError("Arquivo vazio.")
    if len(data) > max_size_bytes:
        raise ExcelReadError(f"Arquivo excede o tamanho máximo permitido ({max_size_bytes // (1024 * 1024)} MB).")
    lower = file_name.lower()
    if not any(lower.endswith(ext) for ext in ALLOWED_EXTENSIONS):
        raise ExcelReadError("Formato não suportado. Envie um arquivo .xlsx.")
    if not data.startswith(b"PK"):
        raise ExcelReadError("O arquivo não é um Excel válido (.xlsx).")
    try:
        wb = openpyxl.load_workbook(io.BytesIO(data), data_only=True, read_only=False)
    except Exception as exc:  # noqa: BLE001
        raise ExcelReadError("Não foi possível abrir o arquivo Excel. Verifique se não está corrompido.") from exc

    column_mapping = column_mapping or {}
    inventory = executed = None
    warnings: List[str] = []
    titles = [ws.title for ws in wb.worksheets]
    for ws in wb.worksheets:
        kind = sheet_kind(ws.title)
        if kind == SHEET_INVENTORY and inventory is None:
            inventory = _read_sheet(ws, kind, column_mapping.get(SHEET_INVENTORY))
        elif kind == SHEET_EXECUTED and executed is None:
            executed = _read_sheet(ws, kind, column_mapping.get(SHEET_EXECUTED))
    if inventory is None and executed is None:
        raise ExcelReadError(
            "Nenhuma das abas esperadas foi encontrada ('Inventário_Ativos' e 'EXECUTADOS'). "
            f"Abas presentes: {', '.join(titles)}"
        )
    if inventory is None:
        warnings.append("Aba 'Inventário_Ativos' ausente: o inventário atual será mantido.")
    if executed is None:
        warnings.append("Aba 'EXECUTADOS' ausente: os executados atuais serão mantidos.")
    for sd in (inventory, executed):
        if sd and sd.missing_id_rows:
            warnings.append(f"{sd.missing_id_rows} linha(s) sem ID ignorada(s) na aba '{sd.title}'.")
        if sd and sd.unmapped:
            warnings.append(f"Colunas adicionais preservadas na aba '{sd.title}': {', '.join(sd.unmapped)}.")
    return ParsedWorkbook(file_name=file_name, file_hash=file_sha256(data), size_bytes=len(data),
                          inventory=inventory, executed=executed, sheet_titles=titles, warnings=warnings)

"""Indicator calculation. Every KPI shown in dashboards, PDF and Excel comes
from ``compute_indicators`` so numbers never diverge between surfaces.
"""
from __future__ import annotations

from collections import Counter, OrderedDict
from typing import Any, Dict, List, Optional

from .dataset import (PENDENCY_LABELS, Dataset, Filters, apply_filters, dimension_value)
from .normalizer import (NOT_INFORMED, ST_ANDAMENTO, ST_BLOQUEADO, ST_CONCLUIDO, ST_NAO_INICIADO,
                         ST_PENDENTE, canonical_status)


def _pct(num: int, den: int) -> float:
    return round(num * 100.0 / den, 2) if den else 0.0


def _sort_key(label: str):
    # keep "Não informado" last; natural order for "Onda 10" vs "Onda 2"
    if label == NOT_INFORMED:
        return (1, 0, "")
    parts = label.split()
    if len(parts) == 2 and parts[1].isdigit():
        return (0, int(parts[1]), parts[0])
    return (0, 0, label)


def distribution(records: List[Dict[str, Any]], field_name: str, sort_by: str = "executed") -> List[Dict[str, Any]]:
    """Per-dimension totals: total (universe), executed, remaining, pct. Reconciles with totals
    by assigning empty values to 'Não informado'."""
    total: Counter = Counter()
    executed: Counter = Counter()
    concluded: Counter = Counter()
    for r in records:
        v = dimension_value(r, field_name)
        total[v] += 1
        if r.get("executed"):
            executed[v] += 1
            if r.get("status_canonical") == ST_CONCLUIDO:
                concluded[v] += 1
    rows = [
        {"label": k, "total": total[k], "executed": executed[k], "remaining": total[k] - executed[k],
         "executed_concluded": concluded[k], "pct": _pct(executed[k], total[k])}
        for k in total
    ]
    if sort_by == "label":
        rows.sort(key=lambda x: _sort_key(x["label"]))
    else:
        rows.sort(key=lambda x: (x["label"] == NOT_INFORMED, -x["executed"], -x["total"], x["label"]))
    return rows


def compute_indicators(ds: Dataset, filters: Optional[Filters] = None) -> Dict[str, Any]:
    all_records = ds.all_merged()
    universe = apply_filters(all_records, filters)
    executed = [r for r in universe if r.get("executed")]
    total = len(universe)
    n_exec = len(executed)
    exec_concluded = sum(1 for r in executed if r.get("status_canonical") == ST_CONCLUIDO)
    canon_counts = Counter(r.get("status_canonical") for r in universe)
    if ds.rules.not_started_requires_not_executed:
        not_started = sum(1 for r in universe if r.get("status_canonical") == ST_NAO_INICIADO and not r.get("executed"))
    else:
        not_started = canon_counts.get(ST_NAO_INICIADO, 0)
    new_exec = sum(1 for r in executed if r.get("is_new_executed"))
    orphans = ds.orphans()

    pend_counter: Counter = Counter()
    exec_with_pend = 0
    for r in executed:
        if r.get("pendencies"):
            exec_with_pend += 1
        for p in r["pendencies"]:
            pend_counter[p] += 1

    return {
        "universe_filtered": bool(filters and filters.affects_universe()),
        "filters_description": filters.describe() if filters else "Nenhum",
        "last_import_id": ds.last_import_id,
        "cards": {
            "total_assets": total,
            "total_executed": n_exec,
            "pct_executed": _pct(n_exec, total),
            "new_executed_last_import": new_exec,
            "executed_concluded": exec_concluded,
            "executed_not_concluded": n_exec - exec_concluded,
            "not_executed": total - n_exec,
            "concluded_inventory": canon_counts.get(ST_CONCLUIDO, 0),
            # status exactly as written in the Inventário_Ativos sheet (ignores precedence)
            "concluded_inventory_raw": sum(
                1 for r in universe if r.get("in_inventory")
                and canonical_status(r.get("inventory_status"), ds.rules.status_map) == ST_CONCLUIDO),
            "concluded_executed": exec_concluded,
            "in_progress": canon_counts.get(ST_ANDAMENTO, 0),
            "pending": canon_counts.get(ST_PENDENTE, 0),
            "blocked": canon_counts.get(ST_BLOQUEADO, 0),
            "not_started": not_started,
            "executed_with_pendencies": exec_with_pend,
            "conflicts": sum(1 for r in executed if r.get("has_conflict")),
            "orphans": len(orphans),
            "missing_from_last_file": sum(1 for r in universe if r.get("present_in_last_import") is False),
        },
        "distributions": {
            "estado": distribution(universe, "estado"),
            "regiao": distribution(universe, "regiao"),
            "onda": distribution(universe, "onda", sort_by="label"),
            "status": distribution(universe, "status"),
            "tipo": distribution(universe, "tipo"),
            "criticidade": distribution(universe, "criticidade"),
        },
        "pendencies": [
            {"key": k, "label": PENDENCY_LABELS.get(k, k), "count": pend_counter.get(k, 0)}
            for k in PENDENCY_LABELS
        ],
    }


def executed_summary_rows(ds: Dataset, filters: Optional[Filters]) -> List[Dict[str, Any]]:
    """Executed records (in inventory) after filters."""
    return [r for r in apply_filters(ds.all_merged(), filters) if r.get("executed")]


def inventory_rows(ds: Dataset, filters: Optional[Filters]) -> List[Dict[str, Any]]:
    return apply_filters(ds.all_merged(), filters)


SORTABLE = {"id", "name", "hostname", "zabbix", "model", "ip", "onda", "regiao", "estado", "cidade", "tipo",
            "criticidade", "status", "coletor", "porta", "descoberta", "coleta_config", "logs_siem", "mudanca",
            "status_label", "executed", "updated_at"}


def _id_sort_key(value: Any):
    s = str(value or "")
    head, _, tail = s.rpartition("-")
    return (head, int(tail)) if tail.isdigit() else (s, 0)


def sort_records(records: List[Dict[str, Any]], sort: Optional[str], order: str = "asc") -> List[Dict[str, Any]]:
    if not sort or sort not in SORTABLE:
        sort = "id"
    reverse = order == "desc"
    if sort == "id":
        return sorted(records, key=lambda r: _id_sort_key(r.get("id")), reverse=reverse)
    if sort == "porta":
        return sorted(records, key=lambda r: (r.get("porta") is None, int(r["porta"]) if str(r.get("porta") or "").isdigit() else 0), reverse=reverse)
    return sorted(records, key=lambda r: (r.get(sort) is None, str(r.get(sort) or "").lower()), reverse=reverse)


def paginate(records: List[Dict[str, Any]], page: int, page_size: int) -> Dict[str, Any]:
    page = max(1, page)
    page_size = max(1, min(page_size, 500))
    start = (page - 1) * page_size
    return {"items": records[start:start + page_size], "total": len(records), "page": page,
            "page_size": page_size, "pages": max(1, -(-len(records) // page_size))}

"""Application settings loaded from environment / .env (pydantic-settings)."""
from __future__ import annotations

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

BACKEND_DIR = Path(__file__).resolve().parent.parent
PROJECT_DIR = BACKEND_DIR.parent
APP_VERSION = "1.0.0"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=str(PROJECT_DIR / ".env"), env_file_encoding="utf-8", extra="ignore")

    APP_NAME: str = "SIEM Firewalls"
    HOST: str = "127.0.0.1"
    PORT: int = 8000
    DATABASE_URL: str = f"sqlite:///{(BACKEND_DIR / 'data' / 'siem_firewalls.db').as_posix()}"
    BACKUP_DIR: str = str(BACKEND_DIR / "data" / "backups")
    REPORTS_DIR: str = str(BACKEND_DIR / "data" / "reports")
    MAX_UPLOAD_MB: int = 50
    PREVIEW_TTL_MINUTES: int = 30
    FRONTEND_DIST: str = str(PROJECT_DIR / "frontend" / "dist")
    LOG_LEVEL: str = "INFO"
    OPEN_BROWSER: bool = True

    def model_post_init(self, context) -> None:  # noqa: D401, ANN001
        """Resolve relative SQLite/backup paths against the backend folder (independent of CWD)."""
        if self.DATABASE_URL.startswith("sqlite:///"):
            raw = self.DATABASE_URL.replace("sqlite:///", "", 1)
            if raw and raw != ":memory:" and not Path(raw).is_absolute():
                self.DATABASE_URL = "sqlite:///" + (BACKEND_DIR / raw).resolve().as_posix()
        for attr in ("BACKUP_DIR", "REPORTS_DIR", "FRONTEND_DIST"):
            value = getattr(self, attr)
            if value and not Path(value).is_absolute():
                setattr(self, attr, str((BACKEND_DIR / value).resolve()))

    @property
    def sqlite_path(self) -> Path | None:
        if self.DATABASE_URL.startswith("sqlite:///"):
            return Path(self.DATABASE_URL.replace("sqlite:///", "", 1))
        return None


settings = Settings()

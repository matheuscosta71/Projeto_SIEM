"""Start the local server (used by iniciar.bat)."""
import threading
import webbrowser

import uvicorn

from app.config import settings


def _open_browser() -> None:
    webbrowser.open(f"http://{settings.HOST}:{settings.PORT}")


if __name__ == "__main__":
    if settings.OPEN_BROWSER:
        threading.Timer(1.5, _open_browser).start()
    uvicorn.run("app.main:app", host=settings.HOST, port=settings.PORT, reload=False, log_level=settings.LOG_LEVEL.lower())

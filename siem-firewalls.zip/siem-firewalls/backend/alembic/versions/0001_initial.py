"""initial schema

Revision ID: 0001_initial
Revises:
Create Date: 2026-10-18
"""
from alembic import op
import sqlalchemy as sa

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None

RECORD_COLS = [
    ("name", sa.String(255)), ("hostname", sa.String(255)), ("zabbix", sa.String(255)), ("model", sa.String(255)),
    ("ip", sa.String(64)), ("onda", sa.String(64)), ("regiao", sa.String(64)), ("estado", sa.String(64)),
    ("cidade", sa.String(128)), ("tipo", sa.String(128)), ("criticidade", sa.String(64)), ("status", sa.String(128)),
    ("coletor", sa.String(255)), ("porta", sa.String(32)), ("descoberta", sa.String(64)),
    ("coleta_config", sa.String(64)), ("logs_siem", sa.String(64)), ("mudanca", sa.String(128)),
    ("data_prevista", sa.String(64)), ("data_real", sa.String(64)), ("responsavel", sa.String(128)),
    ("validar_evidencia", sa.String(255)), ("observacoes", sa.Text()),
]


def _record_columns():
    cols = [sa.Column(n, t, nullable=True) for n, t in RECORD_COLS]
    cols += [
        sa.Column("extra", sa.JSON(), nullable=True),
        sa.Column("first_import_id", sa.Integer(), nullable=True),
        sa.Column("last_import_id", sa.Integer(), nullable=True),
        sa.Column("present_in_last_import", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("updated_at", sa.String(32), nullable=True),
    ]
    return cols


def upgrade() -> None:
    op.create_table("assets", sa.Column("id", sa.String(64), primary_key=True), *_record_columns())
    op.create_index("ix_assets_estado", "assets", ["estado"])
    op.create_index("ix_assets_status", "assets", ["status"])
    op.create_index("ix_assets_onda", "assets", ["onda"])
    op.create_index("ix_assets_regiao", "assets", ["regiao"])
    op.create_table("executions", sa.Column("asset_id", sa.String(64), primary_key=True), *_record_columns(),
                    sa.Column("secondary_rows", sa.JSON(), nullable=True))
    op.create_table(
        "imports",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("file_name", sa.String(255), nullable=False),
        sa.Column("file_hash", sa.String(64), nullable=False),
        sa.Column("size_bytes", sa.Integer(), server_default="0"),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("reference_date", sa.String(32), nullable=True),
        sa.Column("status", sa.String(16), nullable=False, server_default="confirmed"),
        sa.Column("total_assets", sa.Integer(), server_default="0"),
        sa.Column("total_executed", sa.Integer(), server_default="0"),
        sa.Column("new_assets", sa.Integer(), server_default="0"),
        sa.Column("new_executed", sa.Integer(), server_default="0"),
        sa.Column("total_concluded", sa.Integer(), server_default="0"),
        sa.Column("total_pending", sa.Integer(), server_default="0"),
        sa.Column("total_blocked", sa.Integer(), server_default="0"),
        sa.Column("pct_executed", sa.Float(), server_default="0"),
        sa.Column("summary", sa.JSON(), nullable=True),
        sa.Column("warnings", sa.JSON(), nullable=True),
        sa.Column("rules", sa.JSON(), nullable=True),
    )
    op.create_index("ix_imports_file_hash", "imports", ["file_hash"])
    op.create_table(
        "import_snapshots",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("import_id", sa.Integer(), sa.ForeignKey("imports.id", ondelete="CASCADE"), nullable=False),
        sa.Column("kind", sa.String(16), nullable=False),
        sa.Column("record_count", sa.Integer(), server_default="0"),
        sa.Column("payload", sa.LargeBinary(), nullable=False),
        sa.UniqueConstraint("import_id", "kind", name="uq_snapshot_import_kind"),
    )
    op.create_index("ix_import_snapshots_import_id", "import_snapshots", ["import_id"])
    op.create_table(
        "asset_changes",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("import_id", sa.Integer(), sa.ForeignKey("imports.id", ondelete="CASCADE"), nullable=False),
        sa.Column("asset_id", sa.String(64), nullable=False),
        sa.Column("change_type", sa.String(32), nullable=False),
        sa.Column("source", sa.String(16), nullable=False),
        sa.Column("field", sa.String(64), nullable=True),
        sa.Column("old_value", sa.Text(), nullable=True),
        sa.Column("new_value", sa.Text(), nullable=True),
        sa.Column("detail", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_asset_changes_import_id", "asset_changes", ["import_id"])
    op.create_index("ix_asset_changes_asset_id", "asset_changes", ["asset_id"])
    op.create_index("ix_asset_changes_change_type", "asset_changes", ["change_type"])
    op.create_table(
        "report_history",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("report_type", sa.String(32), nullable=False),
        sa.Column("file_name", sa.String(255), nullable=False),
        sa.Column("filters", sa.JSON(), nullable=True),
        sa.Column("options", sa.JSON(), nullable=True),
        sa.Column("row_count", sa.Integer(), server_default="0"),
        sa.Column("import_id", sa.Integer(), nullable=True),
        sa.Column("size_bytes", sa.Integer(), server_default="0"),
    )
    op.create_table(
        "settings",
        sa.Column("key", sa.String(64), primary_key=True),
        sa.Column("value", sa.JSON(), nullable=True),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
    )


def downgrade() -> None:
    for t in ("settings", "report_history", "asset_changes", "import_snapshots", "imports", "executions", "assets"):
        op.drop_table(t)

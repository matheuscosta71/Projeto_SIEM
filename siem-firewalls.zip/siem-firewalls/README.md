# SIEM Firewalls

Plataforma local de acompanhamento do rollout de integração de firewalls ao SIEM. O Excel (`Inventário_Ativos` + `EXECUTADOS`) é a fonte de atualização; o banco SQLite é a fonte persistente e auditável para dashboards e relatórios.

- Backend: Python 3.10+ · FastAPI · SQLAlchemy 2 · Alembic · Pandas/OpenPyXL · ReportLab
- Frontend: React 18 · TypeScript · Vite · Tailwind CSS · componentes no padrão shadcn/ui · Lucide · Recharts · TanStack Table
- Execução: Windows, `http://127.0.0.1:8000`, sem serviços externos após a instalação

## Instalação e uso (Windows)

Pré-requisitos: Python 3.10+ (com "Add to PATH") e Node.js 18+ LTS.

1. `instalar.bat` — cria o ambiente virtual, instala dependências, compila o frontend e roda os testes.
2. `iniciar.bat` — sobe a aplicação em `http://127.0.0.1:8000` e abre o navegador.
3. Em **Importar Planilha**, arraste o `.xlsx`, revise a prévia e confirme.

`iniciar-dev.bat` sobe API (`:8000`, reload) e frontend com hot-reload (`:5173`, proxy para `/api`).
Documentação OpenAPI: `http://127.0.0.1:8000/api/docs`.

Configurações em `.env` (copiado de `.env.example`): `HOST`, `PORT`, `DATABASE_URL`, `BACKUP_DIR`, `MAX_UPLOAD_MB`, `PREVIEW_TTL_MINUTES`, `LOG_LEVEL`, `OPEN_BROWSER`.

## Estrutura

```
siem-firewalls/
├─ instalar.bat · iniciar.bat · iniciar-dev.bat · .env.example
├─ backend/
│  ├─ run.py                      # inicia o uvicorn (usado por iniciar.bat)
│  ├─ requirements.txt · alembic.ini · alembic/ (migração inicial 0001)
│  ├─ app/
│  │  ├─ core/                    # REGRAS DE NEGÓCIO — Python puro, sem banco/web
│  │  │  ├─ fields.py             # campos canônicos + aliases de cabeçalho (ex.: "prova" → IP)
│  │  │  ├─ excel_reader.py       # detecção de abas/cabeçalho em qualquer linha, mapeamento, duplicidades
│  │  │  ├─ normalizer.py         # Sim/Não/N/A, status canônico, equivalência de Tipo/fabricante
│  │  │  ├─ dataset.py            # cruzamento inventário × executados, precedência, conflitos, filtros
│  │  │  ├─ diff.py               # plano de importação (novos, alterações, ausentes, órfãos) e comparação de snapshots
│  │  │  ├─ indicators.py         # TODOS os KPIs e distribuições (única fonte para dashboard, PDF e Excel)
│  │  │  ├─ pdf_report.py         # PDF executivo (1 página A4 paisagem)
│  │  │  └─ excel_report.py       # Excel técnico (Resumo + Executados [+ abas por grupo])
│  │  ├─ services/                # persistência, importação transacional, snapshots, backup, relatórios
│  │  ├─ routers/                 # API REST (/api/...)
│  │  ├─ models.py · database.py · config.py · main.py
│  └─ tests/                      # test_core.py (regras) e test_api.py (fluxo completo via HTTP)
└─ frontend/ (Vite + React)  →  frontend/dist é servido pelo FastAPI em /
```

## Regras de negócio implementadas

| Conceito | Definição |
|---|---|
| Ativo | linha com ID na aba `Inventário_Ativos` (universo oficial) |
| Executado | ID presente na aba `EXECUTADOS` **e** no inventário (IDs únicos; órfãos são sinalizados, não contados) |
| Concluído | `Status Implementação` equivalente a "Concluído" (mapa de equivalência configurável) |
| Não iniciado | status vazio/"Não iniciado" **e** não executado (configurável) |
| Pendência técnica | executado não concluído, `Descoberta`/`Coleta Config.`/`Logs no SIEM` = Não, não informado ou valor inesperado, Coletor/Porta vazios. Vazio ≠ falha. Não altera o status formal. |

- `EXECUTADOS` é **acumulativa**: nada é somado entre importações; cada ID conta uma vez; "Novos executados — última carga" = IDs cuja primeira aparição em `EXECUTADOS` foi na última importação confirmada.
- Equipamentos ausentes em uma nova planilha **não são removidos**: ficam marcados `present_in_last_import = false` e aparecem como alteração "ausente no arquivo".
- Arquivo com o **mesmo hash** de uma importação confirmada é bloqueado (não gera execuções). Arquivo diferente mas sem alterações é aceito com aviso "nenhuma alteração detectada".
- Divergências entre abas (status, onda, região, estado, cidade, tipo, criticidade, modelo, hostname) são **sinalizadas** por campo; a precedência é configurável e os valores originais de cada aba são preservados.
- Valores originais sempre preservados; normalização gera apenas chaves derivadas para agrupar/filtrar. IDs, IPs, portas e mudanças são texto.
- Importação é transacional: qualquer erro faz rollback; nada parcial é confirmado. Cada importação grava um **snapshot completo** (gzip JSON) que permite recalcular qualquer indicador histórico com o mesmo código.

### Decisões tomadas a partir da análise do Excel real (17/08/2026)

Achados no arquivo `Controle_Projeto_SIEM_Firewalls_17082026.xlsx`:

- Inventário: cabeçalho na **linha 3** (linha 1 é título mesclado), 2.293 IDs únicos. `EXECUTADOS`: cabeçalho na linha 1, 152 linhas, **150 IDs únicos** (FW-424 e FW-397 repetidos), todos presentes no inventário.
- A coluna de IP em `EXECUTADOS` chama-se **`prova `** (com espaço) → mapeada para IP. O inventário tem `IP` preenchido em só 30 linhas.
- `Status Implementação` no inventário: vazio 2.070 · Concluído 216 · Em Andamento 7. **Não há valores "Bloqueado"/"Pendente"/"Não iniciado"** na base; os cards correspondentes mostram 0 até que a planilha traga esses valores (equivalências em Configurações).
- 18 executados estão com status vazio no inventário; 104 têm Onda diferente entre as abas; 46 têm hostname diferente. 84 "Concluído" do inventário não constam em `EXECUTADOS`.
- Grafias de Tipo divergentes (SubEstação / SUBESTAÇÃO / Substação…) e fabricante `fortinet/` × `fortigate/`.
- `Data Real` está 100% vazia: **nenhuma data de execução é inventada**; o histórico usa apenas datas de importação.

Decisões confirmadas com o solicitante (todas configuráveis em **Configurações → Regras**):

1. **Precedência**: para equipamentos executados, `EXECUTADOS` prevalece sobre o inventário em caso de divergência (conflito sinalizado, original preservado). Resultado com o arquivo real: 2.293 ativos · 150 executados · 6,54% · 150 executados e concluídos · 0 não concluídos.
2. **Duplicidade em EXECUTADOS**: conta 1; a linha principal é a "validada" (Validado e OK / Logs = Sim); as demais ficam como linhas secundárias e aparecem na lista de duplicidades. Alternativas: última / primeira linha.
3. **Não iniciado** = status vazio **e** não executado (2.052 no arquivo real).
4. **Card "Concluídos" da Visão Geral** usa o universo dos **executados** (rotulado), exibindo ao lado o total do inventário com status Concluído.

Outras decisões documentadas: a seção "Pendências técnicas" vive como aba dentro de **Executados** (sidebar mantida com as 7 seções pedidas); o filtro "Grupo / UF" é o campo `Estado`; a projeção de conclusão só aparece no Histórico com ≥ 3 importações distribuídas em ≥ 7 dias e tendência positiva.

## API (resumo)

| Método | Rota | Função |
|---|---|---|
| GET | `/api/indicators` | KPIs, distribuições, pendências e evolução (aceita filtros) |
| GET | `/api/filters/options` | valores disponíveis por dimensão |
| GET | `/api/assets` · `/api/assets/{id}` | inventário paginado/ordenado · detalhe + histórico |
| GET | `/api/executions` · `/api/executions/pendencies` | executados · pendências técnicas |
| POST | `/api/imports/preview` → `/api/imports/{token}/confirm` | prévia (sem gravar) → confirmação transacional |
| GET | `/api/imports` · `/api/imports/{id}` · `/api/imports/{id}/indicators` · `/api/imports/compare?a=&b=` | histórico, alterações, indicadores de um snapshot, comparação |
| POST | `/api/reports/pdf` · `/api/reports/excel` | geração local (mesmos serviços da dashboard) |
| GET | `/api/reports/history` · `/api/reports/columns` | histórico de relatórios · colunas exportáveis |
| GET/PUT | `/api/settings` · `/api/meta` | regras, mapeamento de colunas, preferências · informações do sistema |
| GET/POST | `/api/backups` · `/api/backups/export` · `/api/backups/restore` | backup local, download, restauração (com confirmação) |

Filtros multi-seleção via query string com `|` (ex.: `?estado=MA|PI&onda=Onda 3`). Campo `modelo` filtra "Fabricante / Modelo".

## Testes

```
cd backend
.venv\Scripts\python.exe -m pytest -q
```

- `tests/test_core.py` (20 testes) — importação inicial, incremental acumulativa, arquivo idêntico, novos executados, duplicidade de ID (3 estratégias), mudança de status, executado não concluído, ausência em nova importação, executado sem inventário, cabeçalhos em linhas diferentes, valores vazios, Excel inválido, filtros combinados, percentual, distribuições UF/região/onda, PDF (1 página), Excel (todas as linhas, texto, anti-injeção), snapshots/comparação, precedência, não iniciado, equivalência de Tipo, colunas extras.
- `tests/test_api.py` (12 testes) — fluxo HTTP completo com banco isolado: prévia+confirmação, bloqueio de arquivo idêntico, importação incremental com snapshots e comparação, detalhe/histórico do ativo, filtros via API, consistência dashboard × PDF × Excel, confirmação obrigatória em configurações críticas, backup/exportação/restauração, persistência após "reinicialização" (nova engine sobre o mesmo arquivo), upload inválido, OpenAPI.

### Como esta entrega foi verificada

O ambiente em que o código foi gerado não tinha acesso a PyPI/npm. Por isso:

- O núcleo de regras (`app/core/*`: leitura do Excel, normalização, cruzamento, indicadores, PDF e Excel) foi **executado e validado** contra o arquivo real: 2.293 / 150 / 6,54%, duplicidades FW-424/FW-397, 18 conflitos de status, distribuições reconciliando com o total. Também foi validado um ciclo incremental sintético (+10 executados, 1 mudança de status) e a detecção de arquivo idêntico; os 20 testes de `test_core.py` passaram.
- As camadas FastAPI/SQLAlchemy (`services/`, `routers/`, `models.py`) e o frontend React foram escritos para serem verificados na sua máquina: `instalar.bat` executa `pytest` (incluindo `test_api.py`) e `npm run build` (type-check com `tsc`). O frontend foi checado por consistência interna de tipos com stubs das bibliotecas. **Se algum teste falhar na instalação, trate a entrega como incompleta e reporte a saída.**

## Segurança

Servidor ligado apenas em `127.0.0.1`; nenhuma chamada externa (fonte Inter opcional em `frontend/public/fonts`); validação de extensão/assinatura/tamanho do upload; nomes de arquivo sanitizados; SQL apenas via ORM parametrizado; proteção contra formula injection no Excel exportado (`= + - @` recebem prefixo `'`); erros registrados sem dados sensíveis; backups locais; prévias de importação mantidas em memória com expiração (sem arquivos temporários); configurações críticas e restauração exigem confirmação explícita. A aplicação não se conecta aos firewalls nem executa comandos.

## Migração para PostgreSQL

Defina `DATABASE_URL=postgresql+psycopg://usuario:senha@host:5432/siem_firewalls`, instale `psycopg[binary]` e rode `alembic upgrade head` em `backend/`. Backup/restauração automáticos são específicos do SQLite (use `pg_dump` no PostgreSQL). Os indicadores são calculados em memória a partir do estado atual (≈2,3 mil registros — milissegundos); para dezenas de milhares de ativos o próximo passo é mover `apply_filters`/`distribution` para consultas SQL mantendo a mesma interface de `indicators.py`.

## Fluxo de uso

Iniciar → dashboard carrega os últimos dados persistidos → Importar Planilha → validação das abas → prévia das mudanças → confirmar → histórico registrado → dashboards atualizadas → consultar Executados → filtrar → exportar PDF/Excel → comparar importações no Histórico.

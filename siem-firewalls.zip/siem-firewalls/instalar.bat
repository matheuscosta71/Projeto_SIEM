@echo off
setlocal
chcp 65001 >nul
title SIEM Firewalls - Instalacao
cd /d "%~dp0"

echo ============================================================
echo  SIEM Firewalls - Instalacao
echo ============================================================
echo.

where python >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Python nao encontrado no PATH. Instale Python 3.10+ (https://www.python.org/downloads/)
  echo        e marque a opcao "Add python.exe to PATH".
  pause & exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Node.js/npm nao encontrado no PATH. Instale Node.js 18+ LTS (https://nodejs.org/).
  pause & exit /b 1
)

if not exist ".env" (
  copy ".env.example" ".env" >nul
  echo [OK] Arquivo .env criado a partir de .env.example
)

echo.
echo [1/4] Criando ambiente virtual Python (backend\.venv)...
if not exist "backend\.venv\Scripts\python.exe" (
  python -m venv backend\.venv
  if errorlevel 1 ( echo [ERRO] Falha ao criar o ambiente virtual. & pause & exit /b 1 )
)

echo [2/4] Instalando dependencias Python...
call backend\.venv\Scripts\python.exe -m pip install --upgrade pip >nul
call backend\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt
if errorlevel 1 ( echo [ERRO] Falha ao instalar dependencias Python. & pause & exit /b 1 )

echo [3/4] Instalando dependencias do frontend (npm install)...
pushd frontend
call npm install
if errorlevel 1 ( popd & echo [ERRO] Falha no npm install. & pause & exit /b 1 )

echo [4/4] Compilando o frontend (npm run build)...
call npm run build
if errorlevel 1 ( popd & echo [ERRO] Falha ao compilar o frontend. & pause & exit /b 1 )
popd

echo.
echo Executando testes automatizados do backend...
pushd backend
call .venv\Scripts\python.exe -m pytest -q
if errorlevel 1 (
  echo [ATENCAO] Ha testes com falha. Revise a saida acima antes de usar em producao.
) else (
  echo [OK] Todos os testes passaram.
)
popd

echo.
echo ============================================================
echo  Instalacao concluida. Execute iniciar.bat para abrir a aplicacao.
echo ============================================================
pause
endlocal

import { Boxes, CheckCheck, Database, FileUp, History, LayoutDashboard, Moon, Settings, ShieldCheck, Sun, Monitor, X } from "lucide-react";
import type { ReactNode } from "react";
import { NavLink, Outlet } from "react-router-dom";
import { api } from "@/lib/api";
import { useAsync, useStore } from "@/lib/store";
import { cn, fmtDate } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Visão Geral", icon: LayoutDashboard, end: true },
  { to: "/executados", label: "Executados", icon: CheckCheck },
  { to: "/inventario", label: "Inventário", icon: Boxes },
  { to: "/importar", label: "Importar Planilha", icon: FileUp },
  { to: "/relatorios", label: "Relatórios", icon: Database },
  { to: "/historico", label: "Histórico", icon: History },
  { to: "/configuracoes", label: "Configurações", icon: Settings },
];

export default function Layout() {
  const { theme, setTheme, dataVersion, toasts, dismissToast } = useStore();
  const meta = useAsync(() => api.meta(), [dataVersion]);
  const last = meta.data?.last_import;

  return (
    <div className="flex min-h-screen">
      <aside className="fixed inset-y-0 left-0 z-30 flex w-60 flex-col border-r bg-card">
        <div className="flex h-16 items-center gap-2.5 border-b px-5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary">
            <ShieldCheck className="h-5 w-5" />
          </div>
          <div className="leading-tight">
            <div className="text-sm font-semibold">SIEM Firewalls</div>
            <div className="text-[11px] text-muted-foreground">Rollout de integração</div>
          </div>
        </div>
        <nav className="flex-1 space-y-0.5 p-3">
          {NAV.map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              end={n.end}
              className={({ isActive }) =>
                cn(
                  "flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                  isActive ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-accent hover:text-foreground",
                )
              }
            >
              <n.icon className="h-4 w-4" />
              {n.label}
            </NavLink>
          ))}
        </nav>
        <div className="border-t p-4 text-[11px] text-muted-foreground">
          <div className="flex items-center justify-between">
            <span>Última importação</span>
            <span className="font-medium text-foreground">{last ? `#${last.id}` : "—"}</span>
          </div>
          <div className="mt-0.5 truncate" title={last?.file_name}>
            {last ? fmtDate(last.created_at) : "Nenhuma planilha importada"}
          </div>
          <div className="mt-3 flex items-center justify-between">
            <span>v{meta.data?.version ?? "…"}</span>
            <div className="inline-flex rounded-md border p-0.5">
              {(
                [
                  ["light", Sun],
                  ["dark", Moon],
                  ["system", Monitor],
                ] as const
              ).map(([t, Icon]) => (
                <button
                  key={t}
                  onClick={() => setTheme(t)}
                  title={t === "light" ? "Claro" : t === "dark" ? "Escuro" : "Sistema"}
                  className={cn("rounded p-1", theme === t ? "bg-muted text-foreground" : "hover:text-foreground")}
                >
                  <Icon className="h-3.5 w-3.5" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </aside>
      <main className="ml-60 flex-1">
        <div className="mx-auto max-w-[1400px] p-6 lg:p-8">
          <Outlet />
        </div>
      </main>
      {/* toasts */}
      <div className="fixed bottom-4 right-4 z-[60] flex w-80 flex-col gap-2">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={cn(
              "fade-in flex items-start gap-3 rounded-lg border bg-card p-3 text-sm shadow-lg",
              t.variant === "error" && "border-red-300 dark:border-red-500/40",
              t.variant === "success" && "border-emerald-300 dark:border-emerald-500/40",
            )}
          >
            <div className="flex-1">
              <div className="font-medium">{t.title}</div>
              {t.description && <div className="mt-0.5 text-xs text-muted-foreground">{t.description}</div>}
            </div>
            <button onClick={() => dismissToast(t.id)} className="text-muted-foreground hover:text-foreground">
              <X className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export function PageHeader({ title, description, actions }: { title: string; description?: string; actions?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="text-xl font-semibold tracking-tight">{title}</h1>
        {description && <p className="mt-1 text-sm text-muted-foreground">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

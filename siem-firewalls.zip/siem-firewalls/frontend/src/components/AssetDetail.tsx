/* Side panel with the complete record of an asset (identification, location, deployment, SIEM, history). */
import { AlertTriangle } from "lucide-react";
import type { ReactNode } from "react";
import { Badge, ErrorState, Sheet, Skeleton } from "@/components/ui/primitives";
import { api } from "@/lib/api";
import { useAsync } from "@/lib/store";
import { CHANGE_LABELS, FIELD_LABELS, cn, fmtDate, show, statusClasses, yesNoClasses } from "@/lib/utils";

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mb-5">
      <h3 className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{title}</h3>
      <dl className="grid grid-cols-2 gap-x-4 gap-y-2 rounded-lg border p-3 text-sm">{children}</dl>
    </section>
  );
}

function Row({ label, value, mono, className }: { label: string; value: ReactNode; mono?: boolean; className?: string }) {
  return (
    <div className={cn("min-w-0", className)}>
      <dt className="text-[11px] text-muted-foreground">{label}</dt>
      <dd className={cn("truncate text-xs", mono && "font-mono")} title={typeof value === "string" ? value : undefined}>
        {value ?? <span className="italic text-muted-foreground">—</span>}
      </dd>
    </div>
  );
}

export function AssetDetail({ assetId, onClose }: { assetId: string | null; onClose: () => void }) {
  const q = useAsync(() => (assetId ? api.asset(assetId) : Promise.resolve(null)), [assetId]);
  const r = q.data?.record;
  const h = q.data?.history;
  return (
    <Sheet open={!!assetId} onClose={onClose} title={r ? `${r.id} · ${r.hostname ?? r.name ?? ""}` : assetId ?? ""} description={r?.model}>
      {q.loading && (
        <div className="space-y-3">
          <Skeleton className="h-24 w-full" />
          <Skeleton className="h-24 w-full" />
        </div>
      )}
      {q.error && <ErrorState message={q.error} onRetry={q.reload} />}
      {r && (
        <>
          <div className="mb-4 flex flex-wrap gap-2">
            {r.executed ? (
              <Badge className="bg-violet-50 text-violet-700 ring-violet-200 dark:bg-violet-500/10 dark:text-violet-300 dark:ring-violet-500/30">Executado</Badge>
            ) : (
              <Badge className="bg-muted text-muted-foreground ring-border">Não executado</Badge>
            )}
            <Badge className={statusClasses(r.status_canonical)}>{r.status_label}</Badge>
            {r.is_new_executed && <Badge className="bg-amber-50 text-amber-700 ring-amber-200 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-500/30">Novo na última carga</Badge>}
            {r.present_in_last_import === false && <Badge className="bg-red-50 text-red-700 ring-red-200 dark:bg-red-500/10 dark:text-red-300 dark:ring-red-500/30">Ausente na última planilha</Badge>}
            {!r.in_inventory && <Badge className="bg-red-50 text-red-700 ring-red-200">Sem cadastro no inventário</Badge>}
          </div>

          {r.conflicts?.length > 0 && (
            <div className="mb-4 rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs dark:border-amber-500/30 dark:bg-amber-500/10">
              <div className="mb-1 flex items-center gap-1.5 font-medium text-amber-800 dark:text-amber-200">
                <AlertTriangle className="h-3.5 w-3.5" /> Divergências entre Inventário_Ativos e EXECUTADOS
              </div>
              <ul className="space-y-0.5 text-amber-900/90 dark:text-amber-100/90">
                {r.conflicts.map((c: any) => (
                  <li key={c.field}>
                    <strong>{FIELD_LABELS[c.field] ?? c.field}:</strong> inventário “{c.inventario}” · executados “{c.executados}”
                  </li>
                ))}
              </ul>
              <p className="mt-1 text-[11px] text-amber-800/80 dark:text-amber-200/80">Os valores exibidos seguem a regra de precedência configurada; o valor original de cada aba é preservado.</p>
            </div>
          )}

          <Section title="Identificação">
            <Row label="ID" value={r.id} mono />
            <Row label="Hostname" value={show(r.hostname)} />
            <Row label="Nome (inventário)" value={show(r.name)} />
            <Row label="Nome / Zabbix" value={show(r.zabbix)} />
            <Row label="Fabricante / Modelo" value={show(r.model)} />
            <Row label="IP" value={show(r.ip)} mono />
          </Section>
          <Section title="Localização">
            <Row label="Estado" value={show(r.estado)} />
            <Row label="Cidade" value={show(r.cidade)} />
            <Row label="Região" value={show(r.regiao)} />
            <Row label="Tipo de instalação" value={r.tipo ? `${r.tipo_normalizado}${r.tipo_normalizado !== r.tipo ? ` (original: ${r.tipo})` : ""}` : show(null)} />
          </Section>
          <Section title="Implantação">
            <Row label="Onda" value={show(r.onda)} />
            <Row label="Status" value={<Badge className={statusClasses(r.status_canonical)}>{r.status_label}</Badge>} />
            <Row label="Criticidade" value={show(r.criticidade)} />
            <Row label="Executado" value={r.executed ? "Sim" : "Não"} />
            {r.inventory_status !== undefined && <Row label="Status no inventário" value={show(r.inventory_status)} />}
            {r.executed && <Row label="Status em EXECUTADOS" value={show(r.executed_status)} />}
            <Row label="Data prevista" value={show(r.data_prevista)} />
            <Row label="Data real" value={show(r.data_real)} />
            <Row label="Responsável" value={show(r.responsavel)} />
            <Row label="Validar evidência" value={show(r.validar_evidencia)} />
          </Section>
          <Section title="Integração com SIEM">
            <Row label="Coletor" value={show(r.coletor)} className="col-span-2" />
            <Row label="Porta" value={show(r.porta)} mono />
            <Row label="Mudança" value={show(r.mudanca)} mono />
            <Row label="Descoberta" value={<span className={yesNoClasses(r.descoberta)}>{show(r.descoberta)}</span>} />
            <Row label="Coleta de configuração" value={<span className={yesNoClasses(r.coleta_config)}>{show(r.coleta_config)}</span>} />
            <Row label="Logs no SIEM?" value={<span className={yesNoClasses(r.logs_siem)}>{show(r.logs_siem)}</span>} />
            {r.observacoes && <Row label="Observações" value={r.observacoes} className="col-span-2 whitespace-normal [&_dd]:whitespace-normal" />}
          </Section>
          {r.extra && Object.keys(r.extra).length > 0 && (
            <Section title="Colunas adicionais da planilha">
              {Object.entries(r.extra).map(([k, v]) => (
                <Row key={k} label={k} value={String(v)} />
              ))}
            </Section>
          )}
          <Section title="Histórico">
            <Row label="Primeira importação identificada" value={h?.first_import ? `#${h.first_import.id} · ${fmtDate(h.first_import.created_at)}` : "—"} className="col-span-2" />
            <Row label="Primeira importação como executado" value={h?.first_executed_import ? `#${h.first_executed_import.id} · ${fmtDate(h.first_executed_import.created_at)}` : r.executed ? "—" : "Não executado"} className="col-span-2" />
            <Row label="Última atualização de dados" value={fmtDate(h?.updated_at)} className="col-span-2" />
          </Section>
          <p className="mb-2 text-[11px] text-muted-foreground">
            As datas acima referem-se às importações da planilha, não à data real de execução no equipamento (a coluna “Data Real” da planilha é exibida separadamente).
          </p>
          <h3 className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Alterações registradas</h3>
          {h?.changes?.length ? (
            <ul className="divide-y rounded-lg border text-xs">
              {h.changes.map((c: any, i: number) => (
                <li key={i} className="flex items-start gap-3 p-2.5">
                  <span className="w-10 shrink-0 font-mono text-muted-foreground">#{c.import_id}</span>
                  <div className="min-w-0 flex-1">
                    <div className="font-medium">
                      {CHANGE_LABELS[c.change_type] ?? c.change_type}
                      {c.field && <span className="font-normal text-muted-foreground"> · {FIELD_LABELS[c.field] ?? c.field}</span>}
                      <span className="ml-1 text-[10px] uppercase text-muted-foreground">{c.source}</span>
                    </div>
                    {(c.old_value || c.new_value) && (
                      <div className="mt-0.5 truncate text-muted-foreground">
                        {c.old_value ? `“${c.old_value}”` : "vazio"} → {c.new_value ? `“${c.new_value}”` : "vazio"}
                      </div>
                    )}
                    {c.detail && <div className="mt-0.5 text-muted-foreground">{c.detail}</div>}
                  </div>
                  <span className="shrink-0 text-muted-foreground">{fmtDate(c.created_at, false)}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-xs text-muted-foreground">Nenhuma alteração registrada.</p>
          )}
        </>
      )}
    </Sheet>
  );
}

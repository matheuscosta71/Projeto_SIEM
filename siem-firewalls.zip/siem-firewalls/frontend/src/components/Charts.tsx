/* Recharts wrappers with consistent styling. */
import { Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { DistRow, EvolutionPoint } from "@/lib/api";
import { COLORS, fmtDate, fmtInt, fmtPct } from "@/lib/utils";

const tooltipStyle = {
  contentStyle: { borderRadius: 10, border: "1px solid hsl(var(--border))", background: "hsl(var(--card))", color: "hsl(var(--foreground))", fontSize: 12 },
  labelStyle: { color: "hsl(var(--muted-foreground))" },
};
const axis = { fontSize: 11, fill: "hsl(var(--muted-foreground))" };

export function ProgressByGroupChart({ rows }: { rows: DistRow[] }) {
  const data = rows.filter((r) => r.total > 0).map((r) => ({ name: r.label, Executado: r.executed, Restante: r.remaining, total: r.total, pct: r.pct }));
  const height = Math.max(180, data.length * 34 + 40);
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} layout="vertical" margin={{ left: 8, right: 24, top: 4, bottom: 4 }} barSize={16}>
        <CartesianGrid horizontal={false} strokeDasharray="3 3" stroke="hsl(var(--border))" />
        <XAxis type="number" tick={axis} tickLine={false} axisLine={false} />
        <YAxis type="category" dataKey="name" width={84} tick={axis} tickLine={false} axisLine={false} />
        <Tooltip
          {...tooltipStyle}
          formatter={(v: any, name: any) => [fmtInt(Number(v)), name]}
          labelFormatter={(l: any, p: any) => {
            const d = p?.[0]?.payload;
            return d ? `${l} — ${fmtInt(d.total)} previstos · ${fmtPct(d.pct)} executado` : l;
          }}
        />
        <Legend wrapperStyle={{ fontSize: 11 }} />
        <Bar dataKey="Executado" stackId="a" fill={COLORS.purple} radius={[3, 0, 0, 3]} />
        <Bar dataKey="Restante" stackId="a" fill="hsl(var(--muted))" radius={[0, 3, 3, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function ExecutedBarChart({ rows, color = COLORS.purple }: { rows: DistRow[]; color?: string }) {
  const data = rows.filter((r) => r.executed > 0 || r.total > 0).map((r) => ({ name: r.label, Executados: r.executed, total: r.total }));
  return (
    <ResponsiveContainer width="100%" height={220}>
      <BarChart data={data} margin={{ left: -16, right: 8, top: 8, bottom: 4 }} barSize={28}>
        <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="hsl(var(--border))" />
        <XAxis dataKey="name" tick={axis} tickLine={false} axisLine={false} interval={0} />
        <YAxis tick={axis} tickLine={false} axisLine={false} allowDecimals={false} />
        <Tooltip {...tooltipStyle} formatter={(v: any) => [fmtInt(Number(v)), "Executados"]} labelFormatter={(l: any, p: any) => (p?.[0]?.payload ? `${l} — ${fmtInt(p[0].payload.total)} previstos` : l)} />
        <Bar dataKey="Executados" fill={color} radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function EvolutionChart({ points, showPct = true }: { points: EvolutionPoint[]; showPct?: boolean }) {
  const data = points.map((p) => ({
    name: `#${p.import_id}`,
    date: fmtDate(p.date, false),
    Executados: p.total_executed,
    "% executado": p.pct_executed,
    Ativos: p.total_assets,
    novos: p.new_executed,
  }));
  return (
    <ResponsiveContainer width="100%" height={240}>
      <LineChart data={data} margin={{ left: -8, right: 16, top: 8, bottom: 4 }}>
        <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="hsl(var(--border))" />
        <XAxis dataKey="date" tick={axis} tickLine={false} axisLine={false} />
        <YAxis yAxisId="left" tick={axis} tickLine={false} axisLine={false} allowDecimals={false} />
        {showPct && <YAxis yAxisId="right" orientation="right" tick={axis} tickLine={false} axisLine={false} unit="%" />}
        <Tooltip
          {...tooltipStyle}
          formatter={(v: any, name: any) => [name === "% executado" ? fmtPct(Number(v)) : fmtInt(Number(v)), name]}
          labelFormatter={(l: any, p: any) => (p?.[0]?.payload ? `${p[0].payload.name} · ${l} · novos: ${p[0].payload.novos}` : l)}
        />
        <Legend wrapperStyle={{ fontSize: 11 }} />
        <Line yAxisId="left" type="monotone" dataKey="Executados" stroke={COLORS.purple} strokeWidth={2.5} dot={{ r: 3 }} activeDot={{ r: 5 }} />
        {showPct && <Line yAxisId="right" type="monotone" dataKey="% executado" stroke={COLORS.green} strokeWidth={2} strokeDasharray="4 3" dot={{ r: 2.5 }} />}
      </LineChart>
    </ResponsiveContainer>
  );
}

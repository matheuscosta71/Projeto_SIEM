/* Compact horizontal-bar distribution list (reconciles with the filtered total). */
import { Card, CardContent, CardDescription, CardHeader, CardTitle, Skeleton } from "@/components/ui/primitives";
import type { DistRow } from "@/lib/api";
import { useStore } from "@/lib/store";
import { cn, fmtInt, fmtPct } from "@/lib/utils";

export function DistributionList({
  title,
  rows,
  total,
  field,
  loading,
  mode = "executed",
  max = 12,
  color = "bg-violet-500",
}: {
  title: string;
  rows: DistRow[] | undefined;
  total: number;
  field?: string;
  loading?: boolean;
  mode?: "executed" | "total";
  max?: number;
  color?: string;
}) {
  const { setFilterValues, filters } = useStore();
  const data = (rows ?? []).filter((r) => (mode === "executed" ? r.executed > 0 : r.total > 0));
  const shown = data.slice(0, max);
  const rest = data.slice(max);
  const restSum = rest.reduce((a, r) => a + (mode === "executed" ? r.executed : r.total), 0);
  const maxVal = Math.max(1, ...shown.map((r) => (mode === "executed" ? r.executed : r.total)));
  const sumShown = data.reduce((a, r) => a + (mode === "executed" ? r.executed : r.total), 0);
  return (
    <Card>
      <CardHeader className="flex-row items-start justify-between space-y-0">
        <div>
          <CardTitle>{title}</CardTitle>
          <CardDescription>{mode === "executed" ? "Equipamentos executados" : "Equipamentos do inventário"}</CardDescription>
        </div>
        <span className="text-xs tabular-nums text-muted-foreground">Total {fmtInt(sumShown)}</span>
      </CardHeader>
      <CardContent className="space-y-2">
        {loading && !rows ? (
          Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-5 w-full" />)
        ) : data.length === 0 ? (
          <p className="py-4 text-center text-xs text-muted-foreground">Sem dados para exibir.</p>
        ) : (
          <>
            {shown.map((r) => {
              const v = mode === "executed" ? r.executed : r.total;
              const pct = total ? (v * 100) / total : 0;
              const selected = field ? (filters.values[field] ?? []).includes(r.label) : false;
              return (
                <button
                  key={r.label}
                  type="button"
                  disabled={!field}
                  onClick={() => field && setFilterValues(field, selected ? [] : [r.label])}
                  title={field ? (selected ? "Remover filtro" : `Filtrar por ${r.label}`) : undefined}
                  className={cn("group flex w-full items-center gap-3 rounded-md px-1 py-0.5 text-left", field && "hover:bg-accent/60", selected && "bg-accent")}
                >
                  <span className="w-28 truncate text-xs" title={r.label}>
                    {r.label}
                  </span>
                  <span className="relative h-2 flex-1 overflow-hidden rounded-full bg-muted">
                    <span className={cn("absolute inset-y-0 left-0 rounded-full", color)} style={{ width: `${(v / maxVal) * 100}%` }} />
                  </span>
                  <span className="w-24 text-right text-xs tabular-nums text-muted-foreground">
                    {fmtInt(v)} <span className="opacity-70">({fmtPct(pct, 1)})</span>
                  </span>
                </button>
              );
            })}
            {rest.length > 0 && (
              <div className="flex items-center gap-3 px-1 text-xs text-muted-foreground">
                <span className="w-28 italic">+{rest.length} outros</span>
                <span className="flex-1" />
                <span className="w-24 text-right tabular-nums">{fmtInt(restSum)}</span>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}

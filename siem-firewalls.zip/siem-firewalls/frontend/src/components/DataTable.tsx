/* Server-driven data table built on TanStack Table (manual sorting/pagination, column visibility). */
import {
  flexRender,
  getCoreRowModel,
  useReactTable,
  type ColumnDef,
  type SortingState,
  type VisibilityState,
} from "@tanstack/react-table";
import { ArrowDown, ArrowUp, ArrowUpDown, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, Columns3 } from "lucide-react";
import { useMemo, useState, type ReactNode } from "react";
import { Badge, Button, Checkbox, Popover, Select, Skeleton } from "@/components/ui/primitives";
import type { Rec } from "@/lib/api";
import { cn, show, statusClasses, yesNoClasses } from "@/lib/utils";

export interface ColumnSpec {
  key: string;
  label: string;
  width?: string;
  render?: (row: Rec) => ReactNode;
  sortable?: boolean;
  defaultHidden?: boolean;
}

export interface TableState {
  page: number;
  pageSize: number;
  sort: string | null;
  order: "asc" | "desc";
}

export const defaultTableState = (pageSize = 25): TableState => ({ page: 1, pageSize, sort: "id", order: "asc" });

export function renderCell(key: string, row: Rec): ReactNode {
  const v = row[key];
  if (key === "status") {
    return <Badge className={statusClasses(row.status_canonical)}>{row.status_label ?? show(v)}</Badge>;
  }
  if (key === "descoberta" || key === "coleta_config" || key === "logs_siem") {
    return <span className={cn("text-xs font-medium", yesNoClasses(v))}>{show(v)}</span>;
  }
  if (key === "executed") {
    return v ? <Badge className="bg-violet-50 text-violet-700 ring-violet-200 dark:bg-violet-500/10 dark:text-violet-300 dark:ring-violet-500/30">Executado</Badge> : <span className="text-xs text-muted-foreground">Não executado</span>;
  }
  if (key === "id") return <span className="font-mono text-xs font-medium">{show(v)}</span>;
  if (key === "ip" || key === "porta") return <span className="font-mono text-xs">{show(v)}</span>;
  if (v === null || v === undefined || v === "") return <span className="text-xs italic text-muted-foreground">—</span>;
  return <span className="text-xs">{String(v)}</span>;
}

export function DataTable({
  columns,
  rows,
  total,
  state,
  onStateChange,
  loading,
  onRowClick,
  storageKey,
  toolbar,
}: {
  columns: ColumnSpec[];
  rows: Rec[];
  total: number;
  state: TableState;
  onStateChange: (s: TableState) => void;
  loading?: boolean;
  onRowClick?: (row: Rec) => void;
  storageKey?: string;
  toolbar?: ReactNode;
}) {
  const [visibility, setVisibility] = useState<VisibilityState>(() => {
    const init: VisibilityState = {};
    columns.forEach((c) => (init[c.key] = !c.defaultHidden));
    if (storageKey) {
      try {
        const saved = localStorage.getItem(`siem-cols-${storageKey}`);
        if (saved) Object.assign(init, JSON.parse(saved));
      } catch {
        /* ignore */
      }
    }
    return init;
  });
  const setVis = (v: VisibilityState) => {
    setVisibility(v);
    if (storageKey) {
      try {
        localStorage.setItem(`siem-cols-${storageKey}`, JSON.stringify(v));
      } catch {
        /* ignore */
      }
    }
  };

  const colDefs = useMemo<ColumnDef<Rec>[]>(
    () =>
      columns.map((c) => ({
        id: c.key,
        accessorKey: c.key,
        header: c.label,
        enableSorting: c.sortable !== false,
        cell: ({ row }) => (c.render ? c.render(row.original) : renderCell(c.key, row.original)),
        meta: { width: c.width },
      })),
    [columns],
  );
  const sorting: SortingState = state.sort ? [{ id: state.sort, desc: state.order === "desc" }] : [];
  const table = useReactTable({
    data: rows,
    columns: colDefs,
    state: { columnVisibility: visibility, sorting },
    onColumnVisibilityChange: (updater) => setVis(typeof updater === "function" ? updater(visibility) : updater),
    manualSorting: true,
    manualPagination: true,
    getCoreRowModel: getCoreRowModel(),
    pageCount: Math.max(1, Math.ceil(total / state.pageSize)),
  });

  const toggleSort = (id: string) => {
    if (state.sort !== id) onStateChange({ ...state, sort: id, order: "asc", page: 1 });
    else onStateChange({ ...state, order: state.order === "asc" ? "desc" : "asc", page: 1 });
  };
  const pages = Math.max(1, Math.ceil(total / state.pageSize));
  const from = total === 0 ? 0 : (state.page - 1) * state.pageSize + 1;
  const to = Math.min(total, state.page * state.pageSize);

  return (
    <div className="card-base overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b px-4 py-2.5">
        <div className="text-xs text-muted-foreground">
          {loading ? "Carregando…" : total === 0 ? "Nenhum registro" : `${from.toLocaleString("pt-BR")}–${to.toLocaleString("pt-BR")} de ${total.toLocaleString("pt-BR")}`}
        </div>
        <div className="flex items-center gap-2">
          {toolbar}
          <Popover
            align="right"
            className="w-64"
            trigger={() => (
              <Button variant="outline" size="sm">
                <Columns3 /> Colunas
              </Button>
            )}
          >
            <div className="max-h-72 overflow-y-auto">
              {table.getAllLeafColumns().map((col) => (
                <label key={col.id} className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 text-xs hover:bg-accent">
                  <Checkbox checked={col.getIsVisible()} onChange={col.getToggleVisibilityHandler()} />
                  {String(col.columnDef.header)}
                </label>
              ))}
            </div>
          </Popover>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="bg-muted/50 text-[11px] uppercase tracking-wide text-muted-foreground">
            {table.getHeaderGroups().map((hg) => (
              <tr key={hg.id}>
                {hg.headers.map((h) => {
                  const canSort = h.column.getCanSort();
                  const active = state.sort === h.column.id;
                  return (
                    <th key={h.id} className="whitespace-nowrap px-3 py-2.5 font-medium" style={{ width: (h.column.columnDef.meta as any)?.width }}>
                      {canSort ? (
                        <button type="button" onClick={() => toggleSort(h.column.id)} className={cn("inline-flex items-center gap-1 hover:text-foreground", active && "text-foreground")}>
                          {flexRender(h.column.columnDef.header, h.getContext())}
                          {active ? state.order === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" /> : <ArrowUpDown className="h-3 w-3 opacity-40" />}
                        </button>
                      ) : (
                        flexRender(h.column.columnDef.header, h.getContext())
                      )}
                    </th>
                  );
                })}
              </tr>
            ))}
          </thead>
          <tbody className="divide-y">
            {loading && rows.length === 0
              ? Array.from({ length: 8 }).map((_, i) => (
                  <tr key={i}>
                    {table.getVisibleLeafColumns().map((c) => (
                      <td key={c.id} className="px-3 py-2.5">
                        <Skeleton className="h-4 w-full" />
                      </td>
                    ))}
                  </tr>
                ))
              : table.getRowModel().rows.map((r) => (
                  <tr
                    key={r.id}
                    onClick={() => onRowClick?.(r.original)}
                    className={cn("transition-colors hover:bg-accent/60", onRowClick && "cursor-pointer", loading && "opacity-60")}
                  >
                    {r.getVisibleCells().map((cell) => (
                      <td key={cell.id} className="max-w-[280px] truncate px-3 py-2">
                        {flexRender(cell.column.columnDef.cell, cell.getContext())}
                      </td>
                    ))}
                  </tr>
                ))}
            {!loading && rows.length === 0 && (
              <tr>
                <td colSpan={table.getVisibleLeafColumns().length} className="px-3 py-10 text-center text-xs text-muted-foreground">
                  Nenhum registro corresponde aos filtros.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <div className="flex flex-wrap items-center justify-between gap-2 border-t px-4 py-2.5 text-xs">
        <div className="flex items-center gap-2 text-muted-foreground">
          Linhas por página
          <Select value={state.pageSize} onChange={(e) => onStateChange({ ...state, pageSize: Number(e.target.value), page: 1 })} className="h-7 text-xs">
            {[10, 25, 50, 100, 250].map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </Select>
        </div>
        <div className="flex items-center gap-1">
          <span className="mr-2 text-muted-foreground">
            Página {state.page} de {pages}
          </span>
          <Button variant="outline" size="icon" className="h-7 w-7" disabled={state.page <= 1} onClick={() => onStateChange({ ...state, page: 1 })}>
            <ChevronsLeft />
          </Button>
          <Button variant="outline" size="icon" className="h-7 w-7" disabled={state.page <= 1} onClick={() => onStateChange({ ...state, page: state.page - 1 })}>
            <ChevronLeft />
          </Button>
          <Button variant="outline" size="icon" className="h-7 w-7" disabled={state.page >= pages} onClick={() => onStateChange({ ...state, page: state.page + 1 })}>
            <ChevronRight />
          </Button>
          <Button variant="outline" size="icon" className="h-7 w-7" disabled={state.page >= pages} onClick={() => onStateChange({ ...state, page: pages })}>
            <ChevronsRight />
          </Button>
        </div>
      </div>
    </div>
  );
}

import type { LucideIcon } from "lucide-react";
import type { ReactNode } from "react";
import { Card, Skeleton } from "@/components/ui/primitives";
import { cn } from "@/lib/utils";

export type Tone = "blue" | "purple" | "green" | "amber" | "red" | "gray";

const TONES: Record<Tone, { bar: string; icon: string }> = {
  blue: { bar: "bg-blue-500", icon: "bg-blue-500/10 text-blue-600 dark:text-blue-400" },
  purple: { bar: "bg-violet-500", icon: "bg-violet-500/10 text-violet-600 dark:text-violet-400" },
  green: { bar: "bg-emerald-500", icon: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" },
  amber: { bar: "bg-amber-500", icon: "bg-amber-500/10 text-amber-600 dark:text-amber-400" },
  red: { bar: "bg-red-500", icon: "bg-red-500/10 text-red-600 dark:text-red-400" },
  gray: { bar: "bg-gray-400", icon: "bg-gray-500/10 text-gray-600 dark:text-gray-300" },
};

export function KpiCard({
  title,
  value,
  hint,
  tone = "blue",
  icon: Icon,
  loading,
  badge,
  onClick,
}: {
  title: string;
  value: ReactNode;
  hint?: ReactNode;
  tone?: Tone;
  icon?: LucideIcon;
  loading?: boolean;
  badge?: ReactNode;
  onClick?: () => void;
}) {
  const t = TONES[tone];
  return (
    <Card className={cn("relative overflow-hidden p-5", onClick && "cursor-pointer transition-shadow hover:shadow-md")} onClick={onClick}>
      <div className={cn("absolute inset-y-0 left-0 w-1", t.bar)} />
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-xs font-medium text-muted-foreground">{title}</p>
          {loading ? <Skeleton className="mt-2 h-8 w-24" /> : <p className="mt-1.5 text-2xl font-semibold tabular-nums tracking-tight">{value}</p>}
          {hint && <p className="mt-1 text-[11px] text-muted-foreground">{hint}</p>}
        </div>
        {Icon && (
          <div className={cn("flex h-9 w-9 shrink-0 items-center justify-center rounded-lg", t.icon)}>
            <Icon className="h-4.5 w-4.5" />
          </div>
        )}
      </div>
      {badge && <div className="mt-2">{badge}</div>}
    </Card>
  );
}

/* Reusable global filter bar: multi-select popovers per dimension + quick clear. */
import { Check, ChevronDown, FilterX, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { Badge, Button, Input, Popover } from "@/components/ui/primitives";
import { api } from "@/lib/api";
import { useAsync, useStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const DEFAULT_FIELDS = ["estado", "regiao", "cidade", "onda", "tipo", "criticidade", "model", "status", "coletor"];
const TECH_FIELDS = ["descoberta", "coleta_config", "logs_siem"];

export function FilterBar({ fields, showTechnical = false, showSearch = false, searchPlaceholder = "Buscar por ID, hostname ou IP…" }: { fields?: string[]; showTechnical?: boolean; showSearch?: boolean; searchPlaceholder?: string }) {
  const { filters, setFilterValues, clearFilters, activeFilterCount, setFilters, dataVersion } = useStore();
  const opts = useAsync(() => api.filterOptions(), [dataVersion]);
  const list = useMemo(() => [...(fields ?? DEFAULT_FIELDS), ...(showTechnical ? TECH_FIELDS : [])], [fields, showTechnical]);
  const labels = opts.data?.labels ?? {};

  return (
    <div className="mb-5 flex flex-wrap items-center gap-2">
      {showSearch && (
        <div className="relative">
          <Search className="pointer-events-none absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            value={filters.q ?? ""}
            onChange={(e) => setFilters((f) => ({ ...f, q: e.target.value || undefined }))}
            placeholder={searchPlaceholder}
            className="w-72 pl-8"
          />
        </div>
      )}
      {list.map((field) => (
        <MultiSelect
          key={field}
          label={labels[field] ?? field}
          options={opts.data?.options?.[field] ?? []}
          selected={filters.values[field] ?? []}
          onChange={(vals) => setFilterValues(field, vals)}
        />
      ))}
      {activeFilterCount > 0 && (
        <Button variant="ghost" size="sm" onClick={clearFilters} className="text-muted-foreground">
          <FilterX /> Limpar ({activeFilterCount})
        </Button>
      )}
    </div>
  );
}

export function MultiSelect({ label, options, selected, onChange }: { label: string; options: string[]; selected: string[]; onChange: (v: string[]) => void }) {
  const [query, setQuery] = useState("");
  const filtered = useMemo(() => options.filter((o) => o.toLowerCase().includes(query.toLowerCase())), [options, query]);
  const toggle = (v: string) => (selected.includes(v) ? onChange(selected.filter((x) => x !== v)) : onChange([...selected, v]));
  const active = selected.length > 0;
  return (
    <Popover
      className="w-72"
      trigger={(open) => (
        <button
          type="button"
          className={cn(
            "inline-flex h-8 items-center gap-1.5 rounded-lg border bg-card px-2.5 text-xs font-medium shadow-sm transition-colors hover:bg-accent",
            active && "border-primary/40 bg-primary/5 text-primary",
            open && "ring-2 ring-ring",
          )}
        >
          {label}
          {active && <Badge className="bg-primary text-primary-foreground ring-0 px-1.5">{selected.length}</Badge>}
          <ChevronDown className="h-3.5 w-3.5 opacity-60" />
        </button>
      )}
    >
      {options.length > 8 && <Input autoFocus value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Filtrar opções…" className="mb-2 h-8 text-xs" />}
      <div className="max-h-64 overflow-y-auto">
        {filtered.length === 0 && <p className="p-2 text-xs text-muted-foreground">Sem opções</p>}
        {filtered.map((o) => {
          const on = selected.includes(o);
          return (
            <button
              key={o}
              type="button"
              onClick={() => toggle(o)}
              className={cn("flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-xs hover:bg-accent", on && "font-medium")}
            >
              <span className={cn("flex h-4 w-4 items-center justify-center rounded border", on ? "border-primary bg-primary text-primary-foreground" : "border-input")}>
                {on && <Check className="h-3 w-3" />}
              </span>
              <span className="truncate" title={o}>
                {o}
              </span>
            </button>
          );
        })}
      </div>
      {active && (
        <div className="mt-2 border-t pt-2">
          <Button variant="ghost" size="sm" className="w-full" onClick={() => onChange([])}>
            Limpar seleção
          </Button>
        </div>
      )}
    </Popover>
  );
}

export function UniverseNotice({ filtered, description }: { filtered: boolean; description: string }) {
  if (!filtered) return null;
  return (
    <div className="mb-4 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-200">
      Indicadores calculados sobre o <strong>universo filtrado</strong> — {description}. O denominador (total de ativos) reflete os filtros.
    </div>
  );
}

import { AlertTriangle, CheckCircle2, FileSpreadsheet, FileUp, Info, Loader2, RotateCcw, X } from "lucide-react";
import { useCallback, useRef, useState, type DragEvent } from "react";
import { useNavigate } from "react-router-dom";
import { PageHeader } from "@/components/layout/Layout";
import { Badge, Button, Card, CardContent, CardDescription, CardHeader, CardTitle, Dialog, Input } from "@/components/ui/primitives";
import { api, type Rec } from "@/lib/api";
import { useStore } from "@/lib/store";
import { CHANGE_LABELS, FIELD_LABELS, cn, fmtBytes, fmtInt, fmtPct } from "@/lib/utils";

type Step = "idle" | "uploading" | "preview" | "confirming" | "done";

export default function ImportPage() {
  const { bumpData, toast } = useStore();
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);
  const [drag, setDrag] = useState(false);
  const [step, setStep] = useState<Step>("idle");
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<Rec | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<Rec | null>(null);
  const [refDate, setRefDate] = useState("");
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [changeTab, setChangeTab] = useState<string>("new_execution");

  const reset = () => {
    if (preview?.token) api.discardImport(preview.token).catch(() => undefined);
    setStep("idle");
    setFile(null);
    setPreview(null);
    setError(null);
    setResult(null);
    setRefDate("");
  };

  const handleFile = useCallback(async (f: File) => {
    setError(null);
    setFile(f);
    setStep("uploading");
    try {
      const p = await api.previewImport(f);
      setPreview(p);
      setStep("preview");
      const types = Object.keys(p.changes_preview ?? {});
      setChangeTab(types.includes("new_execution") ? "new_execution" : types[0] ?? "");
    } catch (e: any) {
      setError(e.message);
      setStep("idle");
    }
  }, []);

  const onDrop = (e: DragEvent) => {
    e.preventDefault();
    setDrag(false);
    const f = e.dataTransfer.files?.[0];
    if (f) handleFile(f);
  };

  const confirm = async () => {
    if (!preview) return;
    setConfirmOpen(false);
    setStep("confirming");
    try {
      const r = await api.confirmImport(preview.token, refDate || undefined);
      setResult(r);
      setStep("done");
      bumpData();
      toast({ title: `Importação #${r.id} confirmada`, description: `${fmtInt(r.total_executed)} executados · ${fmtPct(r.pct_executed)}`, variant: "success" });
    } catch (e: any) {
      setError(e.message);
      setStep("preview");
    }
  };

  const s = preview?.summary;

  return (
    <div className="fade-in">
      <PageHeader title="Importar Planilha" description="Atualize o inventário e os executados a partir do Excel. Nada é gravado antes da sua confirmação." />

      {step === "idle" || step === "uploading" ? (
        <Card>
          <CardContent className="p-6">
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDrag(true);
              }}
              onDragLeave={() => setDrag(false)}
              onDrop={onDrop}
              className={cn(
                "flex flex-col items-center justify-center rounded-xl border-2 border-dashed p-12 text-center transition-colors",
                drag ? "border-primary bg-primary/5" : "border-border",
              )}
            >
              {step === "uploading" ? (
                <>
                  <Loader2 className="mb-3 h-8 w-8 animate-spin text-primary" />
                  <p className="text-sm font-medium">Analisando {file?.name}…</p>
                  <p className="mt-1 text-xs text-muted-foreground">Validando abas, cabeçalhos, IDs e comparando com a última importação.</p>
                </>
              ) : (
                <>
                  <FileSpreadsheet className="mb-3 h-10 w-10 text-muted-foreground" />
                  <p className="text-sm font-medium">Arraste a planilha .xlsx aqui</p>
                  <p className="mt-1 text-xs text-muted-foreground">Abas esperadas: Inventário_Ativos e EXECUTADOS. Cabeçalhos podem estar em qualquer linha.</p>
                  <Button className="mt-4" onClick={() => inputRef.current?.click()}>
                    <FileUp /> Selecionar arquivo
                  </Button>
                  <input ref={inputRef} type="file" accept=".xlsx,.xlsm" className="hidden" onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])} />
                </>
              )}
            </div>
            {error && (
              <div className="mt-4 flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-300">
                <X className="mt-0.5 h-4 w-4 shrink-0" /> {error}
              </div>
            )}
            <ol className="mt-6 grid gap-2 text-xs text-muted-foreground sm:grid-cols-3">
              <li className="rounded-lg border p-3"><strong className="text-foreground">1. Validação</strong><br />Estrutura, abas, cabeçalhos, IDs únicos e tipos (IP/ID como texto).</li>
              <li className="rounded-lg border p-3"><strong className="text-foreground">2. Prévia</strong><br />Novos ativos, novos executados, alterações de status, duplicidades e inconsistências.</li>
              <li className="rounded-lg border p-3"><strong className="text-foreground">3. Confirmação</strong><br />Gravação transacional, snapshot completo e atualização das dashboards.</li>
            </ol>
          </CardContent>
        </Card>
      ) : null}

      {(step === "preview" || step === "confirming") && preview && s && (
        <div className="space-y-4">
          <Card>
            <CardHeader className="flex-row items-start justify-between space-y-0">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <FileSpreadsheet className="h-4 w-4 text-primary" /> {s.file_name}
                </CardTitle>
                <CardDescription>
                  {fmtBytes(s.size_bytes)} · hash {String(s.file_hash).slice(0, 12)}… · abas: {s.sheets?.join(", ")}
                </CardDescription>
              </div>
              <Button variant="ghost" size="sm" onClick={reset} disabled={step === "confirming"}>
                <RotateCcw /> Trocar arquivo
              </Button>
            </CardHeader>
            <CardContent>
              {(preview.warnings ?? []).map((w: string, i: number) => (
                <div key={i} className={cn("mb-2 flex items-start gap-2 rounded-lg border p-2.5 text-xs", preview.identical_to_import_id && i === 0 ? "border-red-200 bg-red-50 text-red-800 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-200" : "border-amber-200 bg-amber-50 text-amber-800 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-200")}>
                  <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {w}
                </div>
              ))}
              {error && (
                <div className="mb-2 flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 p-2.5 text-xs text-red-800 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-200">
                  <X className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {error}
                </div>
              )}
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <Stat label="Total de ativos (após importação)" value={fmtInt(s.total_assets)} sub={s.inventory_sheet ? `${fmtInt(s.inventory_sheet.rows)} linhas · ${fmtInt(s.inventory_sheet.unique_ids)} IDs únicos · cabeçalho na linha ${s.inventory_sheet.header_row}` : "Aba ausente — inventário mantido"} />
                <Stat label="Total executado acumulado" value={fmtInt(s.total_executed)} sub={s.executed_sheet ? `${fmtInt(s.executed_sheet.rows)} linhas · ${fmtInt(s.executed_sheet.unique_ids)} IDs únicos · ${fmtPct(s.pct_executed)}` : "Aba ausente — executados mantidos"} tone="purple" />
                <Stat label="Novos ativos" value={fmtInt(s.new_assets)} tone="blue" />
                <Stat label="Novos executados" value={fmtInt(s.new_executed)} tone="green" />
                <Stat label="Equipamentos atualizados" value={fmtInt((s.updated_assets ?? 0) + (s.updated_executions ?? 0))} sub={`inventário ${fmtInt(s.updated_assets)} · executados ${fmtInt(s.updated_executions)}`} />
                <Stat label="Alterações de status" value={fmtInt(s.status_changes)} tone="amber" />
                <Stat label="Duplicidades" value={fmtInt(s.duplicates_count)} tone={s.duplicates_count ? "amber" : undefined} sub={s.duplicates?.map((d: any) => `${d.id} (${d.sheet}, linhas ${d.rows.join("/")})`).join("; ")} />
                <Stat label="Inconsistências" value={fmtInt((s.orphans_count ?? 0) + (s.conflicts ?? 0) + (s.missing_assets ?? 0) + (s.missing_executions ?? 0))} tone={s.orphans_count || s.conflicts ? "amber" : undefined} sub={`sem inventário ${fmtInt(s.orphans_count)} · divergências entre abas ${fmtInt(s.conflicts)} · ausentes no arquivo ${fmtInt(s.missing_assets)}/${fmtInt(s.missing_executions)}`} />
              </div>
              <div className="mt-4 grid gap-3 text-xs sm:grid-cols-2">
                {s.inventory_sheet && <ColumnMap title={`Colunas reconhecidas — ${s.inventory_sheet.title}`} columns={s.inventory_sheet.columns} unmapped={s.inventory_sheet.unmapped} />}
                {s.executed_sheet && <ColumnMap title={`Colunas reconhecidas — ${s.executed_sheet.title}`} columns={s.executed_sheet.columns} unmapped={s.executed_sheet.unmapped} />}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Resumo das alterações</CardTitle>
              <CardDescription>Prévia (até 200 itens por tipo). O histórico completo fica disponível após a confirmação.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-3 flex flex-wrap gap-1.5">
                {Object.entries(preview.changes_preview ?? {}).map(([type, items]: [string, any]) => (
                  <button key={type} onClick={() => setChangeTab(type)} className={cn("rounded-md border px-2.5 py-1 text-xs", changeTab === type ? "border-primary bg-primary/10 text-primary" : "hover:bg-accent")}>
                    {CHANGE_LABELS[type] ?? type} <span className="ml-1 tabular-nums opacity-70">{items.length}{items.length >= 200 ? "+" : ""}</span>
                  </button>
                ))}
                {Object.keys(preview.changes_preview ?? {}).length === 0 && <span className="text-xs text-muted-foreground">Nenhuma alteração detectada.</span>}
              </div>
              {changeTab && preview.changes_preview?.[changeTab] && (
                <div className="max-h-72 overflow-auto rounded-lg border">
                  <table className="w-full text-xs">
                    <thead className="sticky top-0 bg-muted/80 text-[11px] uppercase text-muted-foreground">
                      <tr>
                        <th className="px-3 py-2 text-left">ID</th>
                        <th className="px-3 py-2 text-left">Origem</th>
                        <th className="px-3 py-2 text-left">Campo</th>
                        <th className="px-3 py-2 text-left">Antes</th>
                        <th className="px-3 py-2 text-left">Depois</th>
                        <th className="px-3 py-2 text-left">Detalhe</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {preview.changes_preview[changeTab].map((c: any, i: number) => (
                        <tr key={i}>
                          <td className="px-3 py-1.5 font-mono">{c.asset_id}</td>
                          <td className="px-3 py-1.5 text-muted-foreground">{c.source}</td>
                          <td className="px-3 py-1.5">{c.field ? FIELD_LABELS[c.field] ?? c.field : "—"}</td>
                          <td className="max-w-[200px] truncate px-3 py-1.5 text-muted-foreground" title={c.old_value ?? ""}>{c.old_value ?? "—"}</td>
                          <td className="max-w-[200px] truncate px-3 py-1.5" title={c.new_value ?? ""}>{c.new_value ?? "—"}</td>
                          <td className="max-w-[260px] truncate px-3 py-1.5 text-muted-foreground" title={c.detail ?? ""}>{c.detail ?? ""}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Prévia dos registros</CardTitle>
              <CardDescription>Primeiras linhas lidas de cada aba, já normalizadas.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 lg:grid-cols-2">
              <SampleTable title="Inventário_Ativos" rows={preview.sample_rows?.inventario ?? []} keys={["id", "name", "model", "estado", "cidade", "tipo", "status"]} />
              <SampleTable title="EXECUTADOS" rows={preview.sample_rows?.executados ?? []} keys={["id", "hostname", "ip", "onda", "estado", "status", "logs_siem"]} />
            </CardContent>
          </Card>

          <Card className="p-5">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div className="flex items-end gap-3">
                <label className="text-xs">
                  <span className="mb-1 block text-muted-foreground">Data de referência da planilha (opcional)</span>
                  <Input type="date" value={refDate} onChange={(e) => setRefDate(e.target.value)} className="w-44" />
                </label>
                <p className="max-w-md text-[11px] text-muted-foreground">
                  A data/hora da importação é registrada automaticamente. Informe a data de referência apenas se a planilha representar uma posição específica (ela não é usada como data de execução dos equipamentos).
                </p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={reset} disabled={step === "confirming"}>
                  Cancelar
                </Button>
                <Button onClick={() => setConfirmOpen(true)} disabled={!preview.can_confirm || step === "confirming"}>
                  {step === "confirming" ? <Loader2 className="animate-spin" /> : <CheckCircle2 />} Confirmar importação
                </Button>
              </div>
            </div>
            {!preview.can_confirm && <p className="mt-2 text-xs text-red-600">Arquivo idêntico a uma importação anterior — confirmação bloqueada.</p>}
          </Card>
        </div>
      )}

      {step === "done" && result && (
        <Card>
          <CardContent className="flex flex-col items-center p-10 text-center">
            <CheckCircle2 className="mb-3 h-10 w-10 text-emerald-500" />
            <p className="text-base font-semibold">Importação #{result.id} confirmada</p>
            <p className="mt-1 text-sm text-muted-foreground">
              {fmtInt(result.total_assets)} ativos · {fmtInt(result.total_executed)} executados ({fmtPct(result.pct_executed)}) · {fmtInt(result.new_executed)} novos executados
            </p>
            <div className="mt-6 flex gap-2">
              <Button variant="outline" onClick={reset}>
                Importar outra planilha
              </Button>
              <Button onClick={() => navigate("/executados")}>Ver executados</Button>
              <Button variant="secondary" onClick={() => navigate("/historico")}>Ver histórico</Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Dialog
        open={confirmOpen}
        onClose={() => setConfirmOpen(false)}
        title="Confirmar importação?"
        description="Os dados serão gravados de forma transacional e um snapshot completo será registrado. Nenhum equipamento é removido; ausências são apenas sinalizadas."
        footer={
          <>
            <Button variant="outline" onClick={() => setConfirmOpen(false)}>
              Voltar
            </Button>
            <Button onClick={confirm}>Confirmar</Button>
          </>
        }
      >
        {s && (
          <ul className="space-y-1 text-sm">
            <li>Novos ativos: <strong>{fmtInt(s.new_assets)}</strong></li>
            <li>Novos executados: <strong>{fmtInt(s.new_executed)}</strong></li>
            <li>Alterações de status: <strong>{fmtInt(s.status_changes)}</strong></li>
            <li>Total executado após importação: <strong>{fmtInt(s.total_executed)} ({fmtPct(s.pct_executed)})</strong></li>
          </ul>
        )}
      </Dialog>
    </div>
  );
}

function Stat({ label, value, sub, tone }: { label: string; value: string; sub?: string; tone?: "blue" | "purple" | "green" | "amber" }) {
  const color = tone === "purple" ? "text-violet-600 dark:text-violet-400" : tone === "green" ? "text-emerald-600 dark:text-emerald-400" : tone === "amber" ? "text-amber-600 dark:text-amber-400" : tone === "blue" ? "text-blue-600 dark:text-blue-400" : "";
  return (
    <div className="rounded-lg border p-3">
      <p className="text-[11px] text-muted-foreground">{label}</p>
      <p className={cn("mt-0.5 text-xl font-semibold tabular-nums", color)}>{value}</p>
      {sub && <p className="mt-0.5 truncate text-[11px] text-muted-foreground" title={sub}>{sub}</p>}
    </div>
  );
}

function ColumnMap({ title, columns, unmapped }: { title: string; columns: Record<string, string>; unmapped: string[] }) {
  return (
    <div className="rounded-lg border p-3">
      <p className="mb-2 flex items-center gap-1.5 font-medium">
        <Info className="h-3.5 w-3.5 text-muted-foreground" /> {title}
      </p>
      <div className="flex flex-wrap gap-1">
        {Object.entries(columns).map(([orig, canon]) => (
          <Badge key={orig} className="bg-muted text-foreground ring-border" title={`Planilha: “${orig}” → ${FIELD_LABELS[canon] ?? canon}`}>
            {orig.trim() !== (FIELD_LABELS[canon] ?? canon) ? `${orig.trim()} → ${FIELD_LABELS[canon] ?? canon}` : orig.trim()}
          </Badge>
        ))}
        {unmapped.map((u) => (
          <Badge key={u} className="bg-amber-50 text-amber-700 ring-amber-200 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-500/30" title="Coluna adicional preservada em “extra”">
            {u} (extra)
          </Badge>
        ))}
      </div>
    </div>
  );
}

function SampleTable({ title, rows, keys }: { title: string; rows: Rec[]; keys: string[] }) {
  return (
    <div>
      <p className="mb-1.5 text-xs font-medium">{title}</p>
      {rows.length === 0 ? (
        <p className="text-xs text-muted-foreground">Aba ausente.</p>
      ) : (
        <div className="overflow-x-auto rounded-lg border">
          <table className="w-full text-xs">
            <thead className="bg-muted/60 text-[11px] uppercase text-muted-foreground">
              <tr>
                <th className="px-2 py-1.5 text-left">Linha</th>
                {keys.map((k) => (
                  <th key={k} className="whitespace-nowrap px-2 py-1.5 text-left">{FIELD_LABELS[k] ?? k}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y">
              {rows.map((r, i) => (
                <tr key={i}>
                  <td className="px-2 py-1 text-muted-foreground">{r._row}</td>
                  {keys.map((k) => (
                    <td key={k} className="max-w-[160px] truncate px-2 py-1" title={r[k] ?? ""}>{r[k] ?? <span className="italic text-muted-foreground">—</span>}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

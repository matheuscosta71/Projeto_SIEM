import { ArrowLeftRight, FileSpreadsheet, GitCompare } from "lucide-react";
import { useEffect, useState } from "react";
import { EvolutionChart } from "@/components/Charts";
import { PageHeader } from "@/components/layout/Layout";
import { Badge, Button, Card, CardContent, CardDescription, CardHeader, CardTitle, EmptyState, ErrorState, Select, Sheet, Skeleton } from "@/components/ui/primitives";
import { api, type ImportInfo, type Rec } from "@/lib/api";
import { useAsync, useStore } from "@/lib/store";
import { CHANGE_LABELS, FIELD_LABELS, cn, fmtBytes, fmtDate, fmtInt, fmtPct } from "@/lib/utils";

export default function History() {
  const { dataVersion } = useStore();
  const imports = useAsync(() => api.imports(), [dataVersion]);
  const list = (imports.data ?? []).filter((i) => i.status === "confirmed");
  const [a, setA] = useState<number | null>(null);
  const [b, setB] = useState<number | null>(null);
  const [detail, setDetail] = useState<number | null>(null);

  useEffect(() => {
    if (list.length >= 2 && (a === null || b === null)) {
      setA(list[list.length - 2].id);
      setB(list[list.length - 1].id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [imports.data]);

  const cmp = useAsync(() => (a && b && a !== b ? api.compare(a, b) : Promise.resolve(null)), [a, b, dataVersion]);
  const projection = computeProjection(list);

  return (
    <div className="fade-in">
      <PageHeader title="Histórico" description="Linha do tempo das importações, evolução do rollout e comparação entre snapshots." />
      {imports.error && <ErrorState message={imports.error} onRetry={imports.reload} />}
      {imports.data && list.length === 0 && <EmptyState title="Nenhuma importação confirmada" description="O histórico é construído a cada planilha confirmada." />}

      {list.length > 0 && (
        <>
          <Card>
            <CardHeader>
              <CardTitle>Evolução do rollout</CardTitle>
              <CardDescription>Total executado acumulado e percentual por importação.{projection && ` Projeção (tendência linear das últimas importações): conclusão em ~${projection.date}, se o ritmo médio de ${projection.rate} execuções/dia se mantiver.`}</CardDescription>
            </CardHeader>
            <CardContent>
              {list.length < 2 ? <p className="py-8 text-center text-xs text-muted-foreground">A evolução é exibida a partir da segunda importação confirmada.</p> : <EvolutionChart points={list.map((i) => ({ import_id: i.id, date: i.created_at, reference_date: i.reference_date, file_name: i.file_name, total_assets: i.total_assets, total_executed: i.total_executed, new_executed: i.new_executed, pct_executed: i.pct_executed, total_concluded: i.total_concluded }))} />}
            </CardContent>
          </Card>

          <Card className="mt-4">
            <CardHeader>
              <CardTitle>Linha do tempo das importações</CardTitle>
              <CardDescription>Clique em uma importação para ver as alterações registradas.</CardDescription>
            </CardHeader>
            <CardContent className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead className="text-[11px] uppercase text-muted-foreground">
                  <tr>
                    <th className="py-2 text-left">#</th>
                    <th className="py-2 text-left">Data e hora</th>
                    <th className="py-2 text-left">Arquivo</th>
                    <th className="py-2 text-right">Ativos</th>
                    <th className="py-2 text-right">Executados</th>
                    <th className="py-2 text-right">Novos exec.</th>
                    <th className="py-2 text-right">Exec. concluídos</th>
                    <th className="py-2 text-right">Pendentes</th>
                    <th className="py-2 text-right">Bloqueados</th>
                    <th className="py-2 text-right">% exec.</th>
                    <th className="py-2 text-left">Hash</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {[...list].reverse().map((i) => (
                    <tr key={i.id} onClick={() => setDetail(i.id)} className="cursor-pointer hover:bg-accent/60">
                      <td className="py-2 font-mono font-medium">#{i.id}</td>
                      <td className="py-2">
                        {fmtDate(i.created_at)}
                        {i.reference_date && <span className="ml-1 text-muted-foreground">(ref. {fmtDate(i.reference_date, false)})</span>}
                      </td>
                      <td className="max-w-[240px] truncate py-2" title={i.file_name}>
                        <span className="inline-flex items-center gap-1.5">
                          <FileSpreadsheet className="h-3.5 w-3.5 text-muted-foreground" /> {i.file_name}
                        </span>
                        <span className="ml-1 text-muted-foreground">({fmtBytes(i.size_bytes)})</span>
                      </td>
                      <td className="py-2 text-right tabular-nums">{fmtInt(i.total_assets)}</td>
                      <td className="py-2 text-right tabular-nums font-medium text-violet-600 dark:text-violet-400">{fmtInt(i.total_executed)}</td>
                      <td className="py-2 text-right tabular-nums">{i.new_executed > 0 ? <Badge className="bg-amber-50 text-amber-700 ring-amber-200 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-500/30">+{fmtInt(i.new_executed)}</Badge> : "0"}</td>
                      <td className="py-2 text-right tabular-nums">{fmtInt(i.total_concluded)}</td>
                      <td className="py-2 text-right tabular-nums">{fmtInt(i.total_pending)}</td>
                      <td className="py-2 text-right tabular-nums">{fmtInt(i.total_blocked)}</td>
                      <td className="py-2 text-right tabular-nums font-medium">{fmtPct(i.pct_executed)}</td>
                      <td className="py-2 font-mono text-muted-foreground" title={i.file_hash}>{i.file_hash.slice(0, 10)}…</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </CardContent>
          </Card>

          <Card className="mt-4">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GitCompare className="h-4 w-4 text-primary" /> Comparar importações
              </CardTitle>
              <CardDescription>Compara os snapshots completos de duas importações.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4 flex flex-wrap items-center gap-2 text-xs">
                <Select value={a ?? ""} onChange={(e) => setA(Number(e.target.value))} className="h-8 text-xs">
                  {list.map((i) => (
                    <option key={i.id} value={i.id}>
                      #{i.id} · {fmtDate(i.created_at)} · {i.total_executed} exec.
                    </option>
                  ))}
                </Select>
                <ArrowLeftRight className="h-4 w-4 text-muted-foreground" />
                <Select value={b ?? ""} onChange={(e) => setB(Number(e.target.value))} className="h-8 text-xs">
                  {list.map((i) => (
                    <option key={i.id} value={i.id}>
                      #{i.id} · {fmtDate(i.created_at)} · {i.total_executed} exec.
                    </option>
                  ))}
                </Select>
                {list.length < 2 && <span className="text-muted-foreground">São necessárias ao menos duas importações.</span>}
              </div>
              {cmp.error && <ErrorState message={cmp.error} onRetry={cmp.reload} />}
              {cmp.loading && a && b && a !== b && <Skeleton className="h-32 w-full" />}
              {cmp.data && <Comparison data={cmp.data} />}
            </CardContent>
          </Card>
        </>
      )}
      <ImportDetailSheet importId={detail} onClose={() => setDetail(null)} />
    </div>
  );
}

function Comparison({ data }: { data: Rec }) {
  const cards = [
    ["Total de ativos", data.a.total_assets, data.b.total_assets],
    ["Total executado", data.a.total_executed, data.b.total_executed],
    ["% executado", `${data.a.pct_executed}%`, `${data.b.pct_executed}%`],
    ["Executados concluídos", data.a.executed_concluded, data.b.executed_concluded],
    ["Não iniciados", data.a.not_started, data.b.not_started],
    ["Bloqueados", data.a.blocked, data.b.blocked],
  ];
  const lists: [string, string[] | Rec[], (x: any) => string][] = [
    ["Equipamentos novos", data.new_assets, (x) => x],
    ["Executados pela primeira vez", data.first_executed, (x) => x],
    ["Alterações de status", data.status_changes, (x) => `${x.asset_id}: ${x.old ?? "vazio"} → ${x.new ?? "vazio"}`],
    ["Deixaram de constar no arquivo", data.dropped_from_file, (x) => x],
    ["Divergências de informação", data.divergences, (x) => `${x.asset_id} · ${FIELD_LABELS[x.field] ?? x.field}: ${x.old ?? "vazio"} → ${x.new ?? "vazio"}`],
  ];
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
        {cards.map(([label, va, vb]) => (
          <div key={String(label)} className="rounded-lg border p-2.5 text-xs">
            <p className="text-[10px] text-muted-foreground">{label}</p>
            <p className="mt-0.5 tabular-nums">
              <span className="text-muted-foreground">{va}</span> <span className="mx-1 text-muted-foreground">→</span> <strong>{vb}</strong>
            </p>
          </div>
        ))}
      </div>
      <div className="grid gap-3 lg:grid-cols-2">
        {lists.map(([title, items, fmt]) => (
          <div key={title} className="rounded-lg border">
            <div className="flex items-center justify-between border-b px-3 py-2 text-xs font-medium">
              {title} <span className="tabular-nums text-muted-foreground">{items.length}</span>
            </div>
            <div className="max-h-48 overflow-y-auto p-2 text-xs">
              {items.length === 0 ? <p className="text-muted-foreground">Nenhum.</p> : (items as any[]).slice(0, 300).map((x, i) => <div key={i} className="truncate py-0.5 font-mono">{fmt(x)}</div>)}
              {items.length > 300 && <p className="pt-1 text-muted-foreground">… e mais {items.length - 300}</p>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ImportDetailSheet({ importId, onClose }: { importId: number | null; onClose: () => void }) {
  const [type, setType] = useState<string>("");
  const q = useAsync(() => (importId ? api.importDetail(importId, { change_type: type, page_size: 300 }) : Promise.resolve(null)), [importId, type]);
  const imp: ImportInfo | undefined = q.data?.import;
  const counts: Record<string, number> = q.data?.change_counts ?? {};
  return (
    <Sheet open={!!importId} onClose={onClose} title={imp ? `Importação #${imp.id}` : "Importação"} description={imp ? `${imp.file_name} · ${fmtDate(imp.created_at)}` : undefined}>
      {q.error && <ErrorState message={q.error} onRetry={q.reload} />}
      {imp && (
        <>
          <div className="mb-4 grid grid-cols-2 gap-2 text-xs sm:grid-cols-3">
            {[
              ["Ativos", imp.total_assets],
              ["Executados", imp.total_executed],
              ["% executado", fmtPct(imp.pct_executed)],
              ["Novos ativos", imp.new_assets],
              ["Novos executados", imp.new_executed],
              ["Exec. concluídos", imp.total_concluded],
            ].map(([l, v]) => (
              <div key={String(l)} className="rounded-lg border p-2">
                <p className="text-[10px] text-muted-foreground">{l}</p>
                <p className="font-semibold tabular-nums">{typeof v === "number" ? fmtInt(v) : v}</p>
              </div>
            ))}
          </div>
          {imp.warnings?.length > 0 && (
            <ul className="mb-4 space-y-1 text-xs">
              {imp.warnings.map((w, i) => (
                <li key={i} className="rounded-md border border-amber-200 bg-amber-50 px-2 py-1 text-amber-800 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-200">{w}</li>
              ))}
            </ul>
          )}
          <p className="mb-2 text-[11px] text-muted-foreground">Regras aplicadas: precedência “{imp.rules?.precedence}”, duplicidade “{imp.rules?.dedupe_strategy}”. Hash {imp.file_hash}</p>
          <div className="mb-2 flex flex-wrap gap-1.5">
            <button onClick={() => setType("")} className={cn("rounded-md border px-2 py-1 text-xs", type === "" ? "border-primary bg-primary/10 text-primary" : "hover:bg-accent")}>
              Todas ({Object.values(counts).reduce((x, y) => x + y, 0)})
            </button>
            {Object.entries(counts).map(([t, n]) => (
              <button key={t} onClick={() => setType(t)} className={cn("rounded-md border px-2 py-1 text-xs", type === t ? "border-primary bg-primary/10 text-primary" : "hover:bg-accent")}>
                {CHANGE_LABELS[t] ?? t} ({n})
              </button>
            ))}
          </div>
          <ul className="divide-y rounded-lg border text-xs">
            {(q.data?.changes?.items ?? []).map((c: any, i: number) => (
              <li key={i} className="flex items-start gap-3 p-2">
                <span className="w-16 shrink-0 font-mono font-medium">{c.asset_id}</span>
                <div className="min-w-0 flex-1">
                  <div>
                    {CHANGE_LABELS[c.change_type] ?? c.change_type}
                    {c.field && <span className="text-muted-foreground"> · {FIELD_LABELS[c.field] ?? c.field}</span>}
                  </div>
                  {(c.old_value || c.new_value) && <div className="truncate text-muted-foreground">{c.old_value ?? "vazio"} → {c.new_value ?? "vazio"}</div>}
                  {c.detail && <div className="truncate text-muted-foreground">{c.detail}</div>}
                </div>
              </li>
            ))}
            {q.data && q.data.changes.items.length === 0 && <li className="p-3 text-muted-foreground">Nenhuma alteração deste tipo.</li>}
          </ul>
          {q.data && q.data.changes.total > q.data.changes.items.length && <p className="mt-2 text-[11px] text-muted-foreground">Exibindo {q.data.changes.items.length} de {q.data.changes.total}.</p>}
          <div className="mt-4">
            <Button variant="outline" size="sm" onClick={onClose}>Fechar</Button>
          </div>
        </>
      )}
    </Sheet>
  );
}

/** Optional projection: only when there are ≥3 imports spanning ≥7 days with positive growth. */
function computeProjection(list: ImportInfo[]): { date: string; rate: string } | null {
  if (list.length < 3) return null;
  const pts = list.map((i) => ({ t: new Date(i.created_at.replace(" ", "T")).getTime(), y: i.total_executed, total: i.total_assets }));
  const spanDays = (pts[pts.length - 1].t - pts[0].t) / 86400000;
  if (spanDays < 7) return null;
  const n = pts.length;
  const mx = pts.reduce((s, p) => s + p.t, 0) / n;
  const my = pts.reduce((s, p) => s + p.y, 0) / n;
  const slope = pts.reduce((s, p) => s + (p.t - mx) * (p.y - my), 0) / pts.reduce((s, p) => s + (p.t - mx) ** 2, 0);
  if (!isFinite(slope) || slope <= 0) return null;
  const last = pts[n - 1];
  const remaining = last.total - last.y;
  if (remaining <= 0) return null;
  const eta = new Date(last.t + (remaining / slope));
  if (isNaN(eta.getTime()) || eta.getTime() - last.t > 20 * 365 * 86400000) return null;
  return { date: eta.toLocaleDateString("pt-BR", { month: "short", year: "numeric" }), rate: (slope * 86400000).toFixed(1) };
}

import { Ban, Boxes, CheckCheck, CheckCircle2, CircleDashed, Clock, Download, Hourglass, XCircle } from "lucide-react";
import { useMemo, useState } from "react";
import { AssetDetail } from "@/components/AssetDetail";
import { DataTable, defaultTableState, type ColumnSpec, type TableState } from "@/components/DataTable";
import { FilterBar, UniverseNotice } from "@/components/FilterBar";
import { KpiCard } from "@/components/KpiCard";
import { PageHeader } from "@/components/layout/Layout";
import { Button, ErrorState, Select } from "@/components/ui/primitives";
import { api, downloadReport, filterBody } from "@/lib/api";
import { useAsync, useStore } from "@/lib/store";
import { fmtInt } from "@/lib/utils";

const COLUMNS: ColumnSpec[] = [
  { key: "id", label: "ID", width: "90px" },
  { key: "name", label: "Nome do Ativo" },
  { key: "model", label: "Fabricante / Modelo" },
  { key: "ip", label: "IP", width: "120px" },
  { key: "executed", label: "Executado", width: "110px" },
  { key: "status", label: "Status Implementação", width: "150px" },
  { key: "onda", label: "Onda", width: "90px" },
  { key: "regiao", label: "Região", width: "110px" },
  { key: "estado", label: "Estado", width: "70px" },
  { key: "cidade", label: "Cidade" },
  { key: "tipo", label: "Tipo", render: (r) => <span className="text-xs">{r.tipo_normalizado ?? <span className="italic text-muted-foreground">—</span>}</span> },
  { key: "criticidade", label: "Criticidade", width: "100px" },
  { key: "coletor", label: "Coletor", defaultHidden: true },
  { key: "porta", label: "Porta", defaultHidden: true },
  { key: "descoberta", label: "Descoberta", defaultHidden: true },
  { key: "coleta_config", label: "Coleta Config.", defaultHidden: true },
  { key: "logs_siem", label: "Logs no SIEM?", defaultHidden: true },
  { key: "mudanca", label: "Mudança", defaultHidden: true },
];

export default function Inventory() {
  const { filters, dataVersion, setFilters, toast } = useStore();
  const [table, setTable] = useState<TableState>(defaultTableState());
  const [selected, setSelected] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false);
  const ind = useAsync(() => api.indicators(filters), [filters, dataVersion]);
  const c = ind.data?.cards;
  const extra = useMemo(() => ({ page: table.page, page_size: table.pageSize, sort: table.sort, order: table.order }), [table]);
  const rows = useAsync(() => api.assets(filters, extra), [filters, extra, dataVersion]);

  const exportExcel = async () => {
    setExporting(true);
    try {
      const name = await downloadReport("excel", { filters: filterBody(filters), scope: "inventario", columns: ["id", "name", "model", "ip", "executed", "status", "onda", "regiao", "estado", "cidade", "tipo", "criticidade", "coletor", "porta", "descoberta", "coleta_config", "logs_siem", "mudanca", "has_conflict"], sort: table.sort, order: table.order });
      toast({ title: "Relatório gerado", description: name, variant: "success" });
    } catch (e: any) {
      toast({ title: "Falha ao exportar", description: e.message, variant: "error" });
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="fade-in">
      <PageHeader
        title="Inventário"
        description="Universo oficial de firewalls (Inventário_Ativos), com indicação de executados e status de implantação."
        actions={
          <Button variant="outline" size="sm" onClick={exportExcel} disabled={exporting}>
            <Download /> {exporting ? "Gerando…" : "Exportar Excel"}
          </Button>
        }
      />
      <FilterBar showSearch />
      {ind.error && <ErrorState message={ind.error} onRetry={ind.reload} />}
      <UniverseNotice filtered={!!ind.data?.universe_filtered} description={ind.data?.filters_description ?? ""} />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCard title="Total de ativos" value={fmtInt(c?.total_assets)} tone="blue" icon={Boxes} loading={ind.loading && !c} />
        <KpiCard title="Total executado" value={fmtInt(c?.total_executed)} tone="purple" icon={CheckCheck} loading={ind.loading && !c} onClick={() => setFilters((f) => ({ ...f, executed: f.executed === true ? null : true }))} hint={filters.executed === true ? "Filtro ativo — clique para remover" : "Clique para filtrar"} />
        <KpiCard title="Total não executado" value={fmtInt(c?.not_executed)} tone="gray" icon={XCircle} loading={ind.loading && !c} onClick={() => setFilters((f) => ({ ...f, executed: f.executed === false ? null : false }))} hint={filters.executed === false ? "Filtro ativo — clique para remover" : "Clique para filtrar"} />
        <KpiCard title="Concluídos" value={fmtInt(c?.concluded_inventory)} tone="green" icon={CheckCircle2} loading={ind.loading && !c} hint="Status = Concluído (universo do inventário)" />
        <KpiCard title="Em andamento" value={fmtInt(c?.in_progress)} tone="amber" icon={Clock} loading={ind.loading && !c} />
        <KpiCard title="Pendentes" value={fmtInt(c?.pending)} tone="amber" icon={Hourglass} loading={ind.loading && !c} />
        <KpiCard title="Bloqueados" value={fmtInt(c?.blocked)} tone="red" icon={Ban} loading={ind.loading && !c} />
        <KpiCard title="Não iniciados" value={fmtInt(c?.not_started)} tone="gray" icon={CircleDashed} loading={ind.loading && !c} hint="Status vazio e não executado" />
      </div>

      <div className="mt-6 mb-3 flex items-center gap-2 text-xs">
        <span className="text-muted-foreground">Execução</span>
        <Select value={filters.executed === true ? "sim" : filters.executed === false ? "nao" : ""} onChange={(e) => setFilters((f) => ({ ...f, executed: e.target.value === "sim" ? true : e.target.value === "nao" ? false : null }))} className="h-8 text-xs">
          <option value="">Todos</option>
          <option value="sim">Somente executados</option>
          <option value="nao">Somente não executados</option>
        </Select>
        <span className="ml-3 text-muted-foreground">Divergências entre abas</span>
        <Select value={filters.has_conflict === true ? "sim" : ""} onChange={(e) => setFilters((f) => ({ ...f, has_conflict: e.target.value === "sim" ? true : null }))} className="h-8 text-xs">
          <option value="">Todos</option>
          <option value="sim">Somente com divergência</option>
        </Select>
      </div>
      {rows.error && <ErrorState message={rows.error} onRetry={rows.reload} />}
      <DataTable columns={COLUMNS} rows={rows.data?.items ?? []} total={rows.data?.total ?? 0} state={table} onStateChange={setTable} loading={rows.loading} onRowClick={(r) => setSelected(r.id)} storageKey="inventario" />
      <AssetDetail assetId={selected} onClose={() => setSelected(null)} />
    </div>
  );
}

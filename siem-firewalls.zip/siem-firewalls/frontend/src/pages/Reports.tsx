import { Download, FileSpreadsheet, FileText, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { FilterBar, UniverseNotice } from "@/components/FilterBar";
import { PageHeader } from "@/components/layout/Layout";
import { Badge, Button, Card, CardContent, CardDescription, CardHeader, CardTitle, Checkbox, ErrorState, Select } from "@/components/ui/primitives";
import { api, downloadReport, filterBody } from "@/lib/api";
import { useAsync, useStore } from "@/lib/store";
import { fmtBytes, fmtDate, fmtInt, fmtPct } from "@/lib/utils";

export default function Reports() {
  const { filters, dataVersion, toast, activeFilterCount } = useStore();
  const ind = useAsync(() => api.indicators({ ...filters, executed: null, pendency: null, has_conflict: null }), [filters, dataVersion]);
  const cols = useAsync(() => api.reportColumns(), []);
  const history = useAsync(() => api.reportHistory(), [dataVersion]);
  const [scope, setScope] = useState<"executados" | "inventario" | "pendencias">("executados");
  const [useFilters, setUseFilters] = useState(true);
  const [groupBy, setGroupBy] = useState<"" | "estado" | "regiao" | "onda" | "status">("");
  const [selectedCols, setSelectedCols] = useState<string[]>([]);
  const [busy, setBusy] = useState<string | null>(null);

  useEffect(() => {
    if (cols.data && selectedCols.length === 0) setSelectedCols(cols.data.default);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cols.data]);

  const effective = useFilters ? { ...filters, executed: null, pendency: null, has_conflict: null } : { values: {} };
  const c = ind.data?.cards;

  const run = async (kind: "pdf" | "excel") => {
    setBusy(kind);
    try {
      const name = await downloadReport(kind, kind === "pdf" ? { filters: filterBody(effective) } : { filters: filterBody(effective), scope, columns: selectedCols, group_by: groupBy || null });
      toast({ title: "Relatório gerado", description: name, variant: "success" });
      history.reload();
    } catch (e: any) {
      toast({ title: "Falha ao gerar relatório", description: e.message, variant: "error" });
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="fade-in">
      <PageHeader title="Relatórios" description="Geração local de PDF executivo e Excel técnico, usando exatamente os mesmos indicadores das dashboards." />
      <FilterBar showTechnical />
      {ind.error && <ErrorState message={ind.error} onRetry={ind.reload} />}
      <UniverseNotice filtered={!!ind.data?.universe_filtered} description={ind.data?.filters_description ?? ""} />

      <label className="mb-4 inline-flex items-center gap-2 text-xs">
        <Checkbox checked={useFilters} onChange={(e) => setUseFilters(e.target.checked)} />
        Aplicar os filtros atuais aos relatórios {activeFilterCount > 0 ? `(${activeFilterCount} ativo${activeFilterCount > 1 ? "s" : ""})` : "(nenhum filtro ativo)"}
      </label>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-4 w-4 text-primary" /> PDF executivo
            </CardTitle>
            <CardDescription>Uma página A4 paisagem: seis indicadores, barra de progresso e distribuições por UF, região e onda.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-4 grid grid-cols-3 gap-2 text-xs">
              <Mini label="Total de ativos" value={fmtInt(c?.total_assets)} />
              <Mini label="Executados" value={fmtInt(c?.total_executed)} />
              <Mini label="% executado" value={fmtPct(c?.pct_executed)} />
              <Mini label="Novos (última carga)" value={fmtInt(c?.new_executed_last_import)} />
              <Mini label="Exec. concluídos" value={fmtInt(c?.executed_concluded)} />
              <Mini label="Exec. não concluídos" value={fmtInt(c?.executed_not_concluded)} />
            </div>
            <Button onClick={() => run("pdf")} disabled={busy !== null || !ind.data}>
              {busy === "pdf" ? <Loader2 className="animate-spin" /> : <Download />} Gerar PDF
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileSpreadsheet className="h-4 w-4 text-emerald-600" /> Excel técnico
            </CardTitle>
            <CardDescription>Aba Resumo + aba com todos os registros correspondentes (não limitado à paginação). Cabeçalho azul-escuro, filtros, congelamento e IP/ID como texto.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 text-xs">
            <div className="flex flex-wrap items-center gap-3">
              <label className="flex items-center gap-2">
                Escopo
                <Select value={scope} onChange={(e) => setScope(e.target.value as any)} className="h-8 text-xs">
                  <option value="executados">Executados</option>
                  <option value="pendencias">Executados com pendências</option>
                  <option value="inventario">Inventário completo</option>
                </Select>
              </label>
              <label className="flex items-center gap-2">
                Abas por
                <Select value={groupBy} onChange={(e) => setGroupBy(e.target.value as any)} className="h-8 text-xs">
                  <option value="">Sem agrupamento</option>
                  <option value="estado">UF</option>
                  <option value="regiao">Região</option>
                  <option value="onda">Onda</option>
                  <option value="status">Status</option>
                </Select>
              </label>
            </div>
            <div>
              <div className="mb-1.5 flex items-center justify-between">
                <span className="font-medium">Colunas ({selectedCols.length})</span>
                <div className="flex gap-2">
                  <button className="text-primary hover:underline" onClick={() => cols.data && setSelectedCols(cols.data.default)}>padrão</button>
                  <button className="text-primary hover:underline" onClick={() => cols.data && setSelectedCols(cols.data.all.map((x) => x.key))}>todas</button>
                </div>
              </div>
              <div className="grid max-h-44 grid-cols-2 gap-1 overflow-y-auto rounded-lg border p-2 sm:grid-cols-3">
                {(cols.data?.all ?? []).map((col) => (
                  <label key={col.key} className="flex items-center gap-2 rounded px-1 py-0.5 hover:bg-accent">
                    <Checkbox checked={selectedCols.includes(col.key)} onChange={(e) => setSelectedCols((s) => (e.target.checked ? [...s, col.key] : s.filter((k) => k !== col.key)))} />
                    <span className="truncate">{col.label}</span>
                  </label>
                ))}
              </div>
            </div>
            <Button onClick={() => run("excel")} disabled={busy !== null || selectedCols.length === 0}>
              {busy === "excel" ? <Loader2 className="animate-spin" /> : <Download />} Gerar Excel
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card className="mt-4">
        <CardHeader>
          <CardTitle>Histórico de relatórios</CardTitle>
          <CardDescription>Relatórios gerados nesta instalação (metadados; os arquivos são baixados pelo navegador).</CardDescription>
        </CardHeader>
        <CardContent>
          {history.error && <ErrorState message={history.error} onRetry={history.reload} />}
          {(history.data?.length ?? 0) === 0 ? (
            <p className="py-4 text-center text-xs text-muted-foreground">Nenhum relatório gerado ainda.</p>
          ) : (
            <table className="w-full text-xs">
              <thead className="text-[11px] uppercase text-muted-foreground">
                <tr>
                  <th className="py-1.5 text-left">Data</th>
                  <th className="py-1.5 text-left">Tipo</th>
                  <th className="py-1.5 text-left">Arquivo</th>
                  <th className="py-1.5 text-right">Registros</th>
                  <th className="py-1.5 text-right">Tamanho</th>
                  <th className="py-1.5 text-left">Importação</th>
                  <th className="py-1.5 text-left">Filtros</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {history.data!.map((h: any) => (
                  <tr key={h.id}>
                    <td className="py-1.5">{fmtDate(h.created_at)}</td>
                    <td className="py-1.5">
                      <Badge className={h.report_type === "pdf_executivo" ? "bg-blue-50 text-blue-700 ring-blue-200 dark:bg-blue-500/10 dark:text-blue-300 dark:ring-blue-500/30" : "bg-emerald-50 text-emerald-700 ring-emerald-200 dark:bg-emerald-500/10 dark:text-emerald-300 dark:ring-emerald-500/30"}>{h.report_type === "pdf_executivo" ? "PDF" : "Excel"}</Badge>
                    </td>
                    <td className="max-w-[260px] truncate py-1.5 font-mono" title={h.file_name}>{h.file_name}</td>
                    <td className="py-1.5 text-right tabular-nums">{fmtInt(h.row_count)}</td>
                    <td className="py-1.5 text-right tabular-nums">{fmtBytes(h.size_bytes)}</td>
                    <td className="py-1.5">{h.import_id ? `#${h.import_id}` : "—"}</td>
                    <td className="max-w-[260px] truncate py-1.5 text-muted-foreground" title={JSON.stringify(h.filters)}>
                      {Object.keys(h.filters?.values ?? {}).length || h.filters?.q ? Object.entries(h.filters.values ?? {}).map(([k, v]: any) => `${k}: ${v.join(", ")}`).join("; ") : "Nenhum"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function Mini({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border p-2">
      <p className="text-[10px] text-muted-foreground">{label}</p>
      <p className="text-sm font-semibold tabular-nums">{value}</p>
    </div>
  );
}

import { AlertTriangle, Boxes, CheckCheck, CheckCircle2, CircleAlert, Download, FileText, Percent, Sparkles } from "lucide-react";
import { useMemo, useState } from "react";
import { AssetDetail } from "@/components/AssetDetail";
import { DataTable, defaultTableState, type ColumnSpec, type TableState } from "@/components/DataTable";
import { DistributionList } from "@/components/Distribution";
import { FilterBar, UniverseNotice } from "@/components/FilterBar";
import { KpiCard } from "@/components/KpiCard";
import { PageHeader } from "@/components/layout/Layout";
import { Badge, Button, Card, ErrorState, Progress, Select, Tabs } from "@/components/ui/primitives";
import { api, downloadReport, filterBody } from "@/lib/api";
import { useAsync, useStore } from "@/lib/store";
import { FIELD_LABELS, cn, fmtInt, fmtPct } from "@/lib/utils";

export const EXEC_COLUMNS: ColumnSpec[] = [
  { key: "id", label: "ID", width: "90px" },
  { key: "name", label: "Nome do Ativo" },
  { key: "zabbix", label: "Nome / Zabbix" },
  { key: "model", label: "Fabricante / Modelo" },
  { key: "ip", label: "IP", width: "120px" },
  { key: "onda", label: "Onda", width: "90px" },
  { key: "regiao", label: "Região", width: "110px" },
  { key: "estado", label: "Estado", width: "70px" },
  { key: "cidade", label: "Cidade" },
  { key: "criticidade", label: "Criticidade", width: "100px" },
  { key: "status", label: "Status Implementação", width: "150px" },
  { key: "coletor", label: "Coletor", defaultHidden: true },
  { key: "porta", label: "Porta", width: "80px" },
  { key: "descoberta", label: "Descoberta", width: "100px" },
  { key: "coleta_config", label: "Coleta Config.", width: "110px" },
  { key: "logs_siem", label: "Logs no SIEM?", width: "110px" },
  { key: "mudanca", label: "Mudança", width: "120px" },
  { key: "hostname", label: "Hostname (EXECUTADOS)", defaultHidden: true },
  { key: "tipo", label: "Tipo", defaultHidden: true },
  { key: "validar_evidencia", label: "Validar Evidência", defaultHidden: true },
  { key: "responsavel", label: "Responsável", defaultHidden: true },
  { key: "data_prevista", label: "Data Prevista", defaultHidden: true },
];

type Tab = "executados" | "pendencias";

export default function Executed() {
  const { filters, dataVersion, toast, setFilters } = useStore();
  const [tab, setTab] = useState<Tab>("executados");
  const [table, setTable] = useState<TableState>(defaultTableState());
  const [selected, setSelected] = useState<string | null>(null);
  const [exporting, setExporting] = useState<"pdf" | "excel" | null>(null);

  // "executed"/"pendency" switches belong to other views; this page always works on the executed universe
  const baseFilters = useMemo(() => ({ ...filters, executed: null, pendency: null, has_conflict: null }), [filters]);
  const rowFilters = useMemo(() => ({ ...baseFilters, pendency: tab === "pendencias" ? filters.pendency ?? null : null }), [baseFilters, tab, filters.pendency]);
  const ind = useAsync(() => api.indicators(baseFilters), [baseFilters, dataVersion]);
  const c = ind.data?.cards;
  const total = c?.total_executed ?? 0;

  const extra = useMemo(() => ({ page: table.page, page_size: table.pageSize, sort: table.sort, order: table.order }), [table]);
  const rows = useAsync(() => (tab === "executados" ? api.executions(rowFilters, extra) : api.pendencies(rowFilters, extra)), [rowFilters, extra, dataVersion, tab]);

  const exportFile = async (kind: "pdf" | "excel") => {
    setExporting(kind);
    try {
      const name = await downloadReport(kind, kind === "pdf" ? { filters: filterBody(baseFilters) } : { filters: filterBody(rowFilters), scope: tab, sort: table.sort, order: table.order });
      toast({ title: "Relatório gerado", description: name, variant: "success" });
    } catch (e: any) {
      toast({ title: "Falha ao exportar", description: e.message, variant: "error" });
    } finally {
      setExporting(null);
    }
  };

  const pendencyColumns: ColumnSpec[] = useMemo(
    () => [
      ...EXEC_COLUMNS.filter((x) => ["id", "name", "ip", "estado", "onda", "status", "descoberta", "coleta_config", "logs_siem", "coletor", "porta"].includes(x.key)).map((x) => ({ ...x, defaultHidden: false })),
      {
        key: "pendencies",
        label: "Pendências",
        sortable: false,
        render: (r) => (
          <div className="flex flex-wrap gap-1">
            {(r.pendencies as string[]).map((p) => (
              <Badge key={p} className="bg-amber-50 text-amber-700 ring-amber-200 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-500/30">
                {pendLabel(p, ind.data?.pendencies)}
              </Badge>
            ))}
          </div>
        ),
      },
    ],
    [ind.data?.pendencies],
  );

  return (
    <div className="fade-in">
      <PageHeader
        title="Executados"
        description="Acompanhamento exclusivo dos equipamentos presentes na aba EXECUTADOS (base acumulativa)."
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => exportFile("excel")} disabled={!!exporting}>
              <Download /> {exporting === "excel" ? "Gerando…" : "Excel técnico"}
            </Button>
            <Button size="sm" onClick={() => exportFile("pdf")} disabled={!!exporting}>
              <FileText /> {exporting === "pdf" ? "Gerando…" : "PDF executivo"}
            </Button>
          </>
        }
      />
      <FilterBar showSearch showTechnical />
      {ind.error && <ErrorState message={ind.error} onRetry={ind.reload} />}
      <UniverseNotice filtered={!!ind.data?.universe_filtered} description={ind.data?.filters_description ?? ""} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        <KpiCard title="Total de Ativos" value={fmtInt(c?.total_assets)} hint="Universo do inventário" tone="blue" icon={Boxes} loading={ind.loading && !c} />
        <KpiCard title="Total Executado Acumulado" value={fmtInt(c?.total_executed)} hint="Únicos em EXECUTADOS identificados no inventário" tone="purple" icon={CheckCheck} loading={ind.loading && !c} />
        <KpiCard title="Percentual Executado" value={fmtPct(c?.pct_executed)} hint="Executados ÷ total de ativos" tone="green" icon={Percent} loading={ind.loading && !c} />
        <KpiCard title="Novos Executados — Última Carga" value={fmtInt(c?.new_executed_last_import)} hint={ind.data?.last_import_id ? `Primeira aparição na importação #${ind.data.last_import_id}` : "Sem importações"} tone="amber" icon={Sparkles} loading={ind.loading && !c} />
        <KpiCard title="Executados e Concluídos" value={fmtInt(c?.executed_concluded)} hint="Status Implementação = Concluído" tone="green" icon={CheckCircle2} loading={ind.loading && !c} />
        <KpiCard
          title="Executados Não Concluídos"
          value={fmtInt(c?.executed_not_concluded)}
          hint={`Com pendências técnicas: ${fmtInt(c?.executed_with_pendencies)} · Divergências entre abas: ${fmtInt(c?.conflicts)}`}
          tone="amber"
          icon={CircleAlert}
          loading={ind.loading && !c}
        />
      </div>

      <Card className="mt-4 p-4">
        <div className="mb-2 flex items-center justify-between text-xs">
          <span className="font-medium">Progresso da execução</span>
          <span className="tabular-nums text-muted-foreground">{fmtPct(c?.pct_executed)}</span>
        </div>
        <Progress value={c?.pct_executed ?? 0} />
      </Card>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <DistributionList title="Executados por Grupo / UF" rows={ind.data?.distributions.estado} total={total} field="estado" loading={ind.loading} />
        <DistributionList title="Executados por Região" rows={ind.data?.distributions.regiao} total={total} field="regiao" loading={ind.loading} />
        <DistributionList title="Executados por Onda" rows={ind.data?.distributions.onda} total={total} field="onda" loading={ind.loading} />
      </div>

      {(c?.orphans ?? 0) > 0 && (
        <div className="mt-4 flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 p-3 text-xs text-red-800 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-200">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
          <div>
            <strong>{c?.orphans}</strong> equipamento(s) constam em EXECUTADOS mas não existem no inventário. Eles não entram no total executado e estão listados ao final da tabela.
          </div>
        </div>
      )}

      <div className="mt-6 mb-3 flex flex-wrap items-center justify-between gap-2">
        <Tabs
          value={tab}
          onChange={(t) => {
            setTab(t);
            setTable((s) => ({ ...s, page: 1 }));
          }}
          items={[
            { value: "executados", label: `Tabela de executados` },
            { value: "pendencias", label: `Pendências técnicas (${fmtInt(c?.executed_with_pendencies)})` },
          ]}
        />
        {tab === "pendencias" && (
          <div className="flex items-center gap-2 text-xs">
            <span className="text-muted-foreground">Tipo de pendência</span>
            <Select value={filters.pendency ?? ""} onChange={(e) => setFilters((f) => ({ ...f, pendency: e.target.value || null }))} className="h-8 text-xs">
              <option value="">Todas</option>
              {(ind.data?.pendencies ?? []).map((p) => (
                <option key={p.key} value={p.key}>
                  {p.label} ({p.count})
                </option>
              ))}
            </Select>
          </div>
        )}
      </div>

      {tab === "pendencias" && (
        <div className="mb-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {(ind.data?.pendencies ?? [])
            .filter((p) => p.count > 0)
            .map((p) => (
              <button
                key={p.key}
                onClick={() => setFilters((f) => ({ ...f, pendency: f.pendency === p.key ? null : p.key }))}
                className={cn("card-base flex items-center justify-between px-3 py-2 text-left text-xs hover:bg-accent", filters.pendency === p.key && "ring-2 ring-ring")}
              >
                <span>{p.label}</span>
                <span className="font-semibold tabular-nums">{fmtInt(p.count)}</span>
              </button>
            ))}
          <p className="col-span-full text-[11px] text-muted-foreground">
            Campos vazios são classificados como “não informado”, nunca como falha. Uma pendência técnica não altera o status formal de implantação.
          </p>
        </div>
      )}

      {rows.error && <ErrorState message={rows.error} onRetry={rows.reload} />}
      <DataTable
        columns={tab === "executados" ? EXEC_COLUMNS : pendencyColumns}
        rows={rows.data?.items ?? []}
        total={rows.data?.total ?? 0}
        state={table}
        onStateChange={setTable}
        loading={rows.loading}
        onRowClick={(r) => setSelected(r.id)}
        storageKey={tab}
      />
      {tab === "executados" && (rows.data?.orphans?.length ?? 0) > 0 && (
        <Card className="mt-4 p-4">
          <h3 className="mb-2 text-sm font-semibold">Executados sem cadastro no inventário</h3>
          <ul className="divide-y text-xs">
            {rows.data!.orphans.map((o: any) => (
              <li key={o.id} className="flex items-center gap-4 py-1.5">
                <span className="font-mono font-medium">{o.id}</span>
                <span>{o.hostname}</span>
                <span className="text-muted-foreground">{o.ip}</span>
                <span className="text-muted-foreground">{o.estado}</span>
              </li>
            ))}
          </ul>
        </Card>
      )}
      <AssetDetail assetId={selected} onClose={() => setSelected(null)} />
    </div>
  );
}

function pendLabel(key: string, list?: { key: string; label: string }[]): string {
  return list?.find((p) => p.key === key)?.label ?? FIELD_LABELS[key] ?? key;
}

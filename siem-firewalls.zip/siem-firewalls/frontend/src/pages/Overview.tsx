import { Activity, Ban, Boxes, CheckCheck, CheckCircle2, CircleDashed, FileUp, Percent } from "lucide-react";
import { useMemo } from "react";
import { Link } from "react-router-dom";
import { EvolutionChart, ExecutedBarChart, ProgressByGroupChart } from "@/components/Charts";
import { FilterBar, UniverseNotice } from "@/components/FilterBar";
import { KpiCard } from "@/components/KpiCard";
import { PageHeader } from "@/components/layout/Layout";
import { buttonVariants, Card, CardContent, CardDescription, CardHeader, CardTitle, EmptyState, ErrorState, Progress, Skeleton } from "@/components/ui/primitives";
import { api } from "@/lib/api";
import { useAsync, useStore } from "@/lib/store";
import { fmtInt, fmtPct } from "@/lib/utils";

export default function Overview() {
  const { filters, dataVersion } = useStore();
  const baseFilters = useMemo(() => ({ ...filters, executed: null, pendency: null, has_conflict: null }), [filters]);
  const q = useAsync(() => api.indicators(baseFilters), [baseFilters, dataVersion]);
  const c = q.data?.cards;
  const noData = !q.loading && !q.error && c && c.total_assets === 0 && !q.data?.universe_filtered;

  return (
    <div className="fade-in">
      <PageHeader title="Visão Geral" description="Panorama consolidado do rollout de integração dos firewalls ao SIEM." />
      {noData ? (
        <EmptyState
          icon={<FileUp className="h-8 w-8" />}
          title="Nenhuma planilha importada ainda"
          description="Importe o arquivo Excel com as abas Inventário_Ativos e EXECUTADOS para carregar os indicadores."
          action={
            <Link to="/importar" className={buttonVariants()}>
              <FileUp className="h-4 w-4" /> Importar planilha
            </Link>
          }
        />
      ) : (
        <>
          <FilterBar />
          {q.error && <ErrorState message={q.error} onRetry={q.reload} />}
          <UniverseNotice filtered={!!q.data?.universe_filtered} description={q.data?.filters_description ?? ""} />

          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
            <KpiCard title="Total de Ativos" value={fmtInt(c?.total_assets)} hint="Firewalls únicos no inventário" tone="blue" icon={Boxes} loading={q.loading && !c} />
            <KpiCard title="Total Executado Acumulado" value={fmtInt(c?.total_executed)} hint="Únicos em EXECUTADOS e no inventário" tone="purple" icon={CheckCheck} loading={q.loading && !c} />
            <KpiCard title="Percentual Executado" value={fmtPct(c?.pct_executed)} hint="Executados ÷ total de ativos" tone="green" icon={Percent} loading={q.loading && !c} />
            <KpiCard
              title="Concluídos"
              value={fmtInt(c?.concluded_executed)}
              hint={`Universo: executados · Inventário completo com status Concluído: ${fmtInt(c?.concluded_inventory_raw)}`}
              tone="green"
              icon={CheckCircle2}
              loading={q.loading && !c}
            />
            <KpiCard title="Não Iniciados" value={fmtInt(c?.not_started)} hint="Status vazio/“Não iniciado” e não executado" tone="gray" icon={CircleDashed} loading={q.loading && !c} />
            <KpiCard title="Bloqueados" value={fmtInt(c?.blocked)} hint={`Em andamento: ${fmtInt(c?.in_progress)} · Pendentes: ${fmtInt(c?.pending)}`} tone="red" icon={Ban} loading={q.loading && !c} />
          </div>

          <Card className="mt-4 p-5">
            <div className="mb-2 flex items-center justify-between text-sm">
              <span className="font-medium">Progresso geral da execução</span>
              <span className="tabular-nums text-muted-foreground">
                {fmtInt(c?.total_executed)} de {fmtInt(c?.total_assets)} · <strong className="text-foreground">{fmtPct(c?.pct_executed)}</strong>
              </span>
            </div>
            <Progress value={c?.pct_executed ?? 0} className="h-3" />
          </Card>

          <div className="mt-4 grid gap-4 xl:grid-cols-5">
            <Card className="xl:col-span-3">
              <CardHeader>
                <CardTitle>Progresso por Grupo / UF</CardTitle>
                <CardDescription>Total previsto, executado e restante por estado</CardDescription>
              </CardHeader>
              <CardContent>{q.data ? <ProgressByGroupChart rows={q.data.distributions.estado} /> : <Skeleton className="h-56 w-full" />}</CardContent>
            </Card>
            <div className="grid gap-4 xl:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Execuções por Região</CardTitle>
                  <CardDescription>Total executado em cada região</CardDescription>
                </CardHeader>
                <CardContent>{q.data ? <ExecutedBarChart rows={q.data.distributions.regiao} /> : <Skeleton className="h-48 w-full" />}</CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Execuções por Onda</CardTitle>
                  <CardDescription>Equipamentos executados em cada onda</CardDescription>
                </CardHeader>
                <CardContent>{q.data ? <ExecutedBarChart rows={q.data.distributions.onda} /> : <Skeleton className="h-48 w-full" />}</CardContent>
              </Card>
            </div>
          </div>

          <Card className="mt-4">
            <CardHeader className="flex-row items-start justify-between space-y-0">
              <div>
                <CardTitle>Evolução do Rollout</CardTitle>
                <CardDescription>Executados acumulados por importação (universo completo, independente de filtros)</CardDescription>
              </div>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {!q.data ? (
                <Skeleton className="h-56 w-full" />
              ) : (q.data.evolution?.length ?? 0) < 2 ? (
                <p className="py-8 text-center text-xs text-muted-foreground">
                  A evolução é exibida a partir da segunda importação confirmada ({q.data.evolution?.length ?? 0} até agora).
                </p>
              ) : (
                <EvolutionChart points={q.data.evolution!} />
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}

import { Database, Download, HardDrive, Plus, RotateCcw, Save, Trash2, Upload } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { PageHeader } from "@/components/layout/Layout";
import { Badge, Button, Card, CardContent, CardDescription, CardHeader, CardTitle, Dialog, ErrorState, Input, Select } from "@/components/ui/primitives";
import { api, type Rec } from "@/lib/api";
import { useAsync, useStore } from "@/lib/store";
import { FIELD_LABELS, fmtBytes, fmtDate, fmtInt } from "@/lib/utils";

const STATUS_CANON = [
  ["concluido", "Concluído"],
  ["em_andamento", "Em Andamento"],
  ["pendente", "Pendente"],
  ["bloqueado", "Bloqueado"],
  ["nao_iniciado", "Não iniciado"],
];

export default function Settings() {
  const { dataVersion, bumpData, toast, theme, setTheme } = useStore();
  const meta = useAsync(() => api.meta(), [dataVersion]);
  const settings = useAsync(() => api.settings(), [dataVersion]);
  const backups = useAsync(() => api.backups(), [dataVersion]);

  const [rules, setRules] = useState<Rec | null>(null);
  const [mapping, setMapping] = useState<Rec | null>(null);
  const [prefs, setPrefs] = useState<Rec | null>(null);
  const [backupPath, setBackupPath] = useState("");
  const [confirm, setConfirm] = useState<{ title: string; description: string; action: () => Promise<void> } | null>(null);
  const [busy, setBusy] = useState(false);
  const restoreRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (settings.data) {
      setRules(JSON.parse(JSON.stringify(settings.data.rules)));
      setMapping(JSON.parse(JSON.stringify(settings.data.column_mapping)));
      setPrefs({ ...settings.data.preferences });
      setBackupPath(settings.data.backup?.path ?? "");
    }
  }, [settings.data]);

  const save = async (body: Rec, msg: string) => {
    setBusy(true);
    try {
      await api.updateSettings({ ...body, confirm: true });
      toast({ title: msg, variant: "success" });
      bumpData();
    } catch (e: any) {
      toast({ title: "Falha ao salvar", description: e.message, variant: "error" });
    } finally {
      setBusy(false);
      setConfirm(null);
    }
  };

  const runBackup = async () => {
    setBusy(true);
    try {
      const r = await api.createBackup();
      toast({ title: "Backup criado", description: r.file_name, variant: "success" });
      backups.reload();
    } catch (e: any) {
      toast({ title: "Falha no backup", description: e.message, variant: "error" });
    } finally {
      setBusy(false);
    }
  };

  const restore = (file: File | null, path: string | null) =>
    setConfirm({
      title: "Restaurar backup?",
      description: "O banco atual será substituído pelo backup selecionado. Um backup de segurança do estado atual é criado automaticamente antes da restauração.",
      action: async () => {
        setBusy(true);
        try {
          const r = await api.restoreBackup(file, path);
          toast({ title: "Backup restaurado", description: `${fmtInt(r.restored.assets)} ativos · ${fmtInt(r.restored.executions)} executados · ${fmtInt(r.restored.imports)} importações`, variant: "success" });
          bumpData();
        } catch (e: any) {
          toast({ title: "Falha ao restaurar", description: e.message, variant: "error" });
        } finally {
          setBusy(false);
          setConfirm(null);
        }
      },
    });

  const db = meta.data?.database;

  return (
    <div className="fade-in">
      <PageHeader title="Configurações" description="Preferências, banco de dados, backup, mapeamento de colunas e regras de negócio configuráveis." />
      {settings.error && <ErrorState message={settings.error} onRetry={settings.reload} />}

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-4 w-4 text-primary" /> Banco de dados
            </CardTitle>
            <CardDescription>Informações da instalação local.</CardDescription>
          </CardHeader>
          <CardContent className="text-xs">
            <dl className="grid grid-cols-[140px_1fr] gap-y-1.5">
              <dt className="text-muted-foreground">Versão</dt>
              <dd>{meta.data?.version ?? "—"}</dd>
              <dt className="text-muted-foreground">Engine</dt>
              <dd>{db?.engine} <span className="text-muted-foreground">({db?.url})</span></dd>
              <dt className="text-muted-foreground">Arquivo</dt>
              <dd className="truncate font-mono" title={db?.path}>{db?.path ?? "—"}</dd>
              <dt className="text-muted-foreground">Tamanho</dt>
              <dd>{fmtBytes(db?.size_bytes)}</dd>
              <dt className="text-muted-foreground">Registros</dt>
              <dd>{db ? `${fmtInt(db.counts.assets)} ativos · ${fmtInt(db.counts.executions)} executados · ${fmtInt(db.counts.imports)} importações · ${fmtInt(db.counts.snapshots)} snapshots · ${fmtInt(db.counts.changes)} alterações` : "—"}</dd>
              <dt className="text-muted-foreground">Última importação</dt>
              <dd>{meta.data?.last_import ? `#${meta.data.last_import.id} · ${meta.data.last_import.file_name} · ${fmtDate(meta.data.last_import.created_at)}` : "Nenhuma"}</dd>
              <dt className="text-muted-foreground">Endereço</dt>
              <dd className="font-mono">http://{meta.data?.host}:{meta.data?.port} <span className="text-muted-foreground">(somente local)</span></dd>
            </dl>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <HardDrive className="h-4 w-4 text-primary" /> Backup e restauração
            </CardTitle>
            <CardDescription>Cópias locais do SQLite. A restauração exige confirmação.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 text-xs">
            <div className="flex items-end gap-2">
              <label className="flex-1">
                <span className="mb-1 block text-muted-foreground">Pasta de backup (vazio = padrão)</span>
                <Input value={backupPath} onChange={(e) => setBackupPath(e.target.value)} placeholder={backups.data?.dir ?? "backend/data/backups"} className="font-mono text-xs" />
              </label>
              <Button variant="outline" size="sm" disabled={busy} onClick={() => setConfirm({ title: "Alterar pasta de backup?", description: `Novos backups serão gravados em: ${backupPath || "pasta padrão"}.`, action: () => save({ backup: { path: backupPath || null } }, "Pasta de backup atualizada") })}>
                <Save /> Salvar
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button size="sm" onClick={runBackup} disabled={busy}>
                <Plus /> Criar backup agora
              </Button>
              <a href="/api/backups/export" className="inline-flex h-8 items-center gap-2 rounded-md border bg-card px-3 text-xs font-medium hover:bg-accent">
                <Download className="h-4 w-4" /> Exportar (download .db)
              </a>
              <Button size="sm" variant="outline" onClick={() => restoreRef.current?.click()} disabled={busy}>
                <Upload /> Restaurar de arquivo…
              </Button>
              <input ref={restoreRef} type="file" accept=".db" className="hidden" onChange={(e) => e.target.files?.[0] && restore(e.target.files[0], null)} />
            </div>
            <div>
              <p className="mb-1 font-medium">Backups existentes {backups.data && <span className="font-normal text-muted-foreground">({backups.data.dir})</span>}</p>
              {backups.error && <ErrorState message={backups.error} onRetry={backups.reload} />}
              {backups.data?.items.length === 0 && <p className="text-muted-foreground">Nenhum backup ainda.</p>}
              <ul className="max-h-40 divide-y overflow-y-auto rounded-lg border">
                {backups.data?.items.map((b: any) => (
                  <li key={b.path} className="flex items-center justify-between gap-2 px-2.5 py-1.5">
                    <span className="truncate font-mono" title={b.path}>{b.file_name}</span>
                    <span className="shrink-0 text-muted-foreground">{fmtBytes(b.size_bytes)} · {fmtDate(b.created_at)}</span>
                    <Button variant="ghost" size="sm" onClick={() => restore(null, b.path)} disabled={busy}>
                      <RotateCcw /> Restaurar
                    </Button>
                  </li>
                ))}
              </ul>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Regras de negócio</CardTitle>
            <CardDescription>Alterações críticas: exigem confirmação e passam a valer para as próximas leituras e importações.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 text-xs">
            {rules && (
              <>
                <label className="block">
                  <span className="mb-1 block text-muted-foreground">Precedência em caso de divergência entre abas (equipamentos executados)</span>
                  <Select value={rules.precedence} onChange={(e) => setRules({ ...rules, precedence: e.target.value })} className="w-full text-xs">
                    <option value="executados">EXECUTADOS prevalece (aba mais atual)</option>
                    <option value="inventario">Inventário_Ativos prevalece</option>
                  </Select>
                </label>
                <label className="block">
                  <span className="mb-1 block text-muted-foreground">IDs repetidos na aba EXECUTADOS</span>
                  <Select value={rules.dedupe_strategy} onChange={(e) => setRules({ ...rules, dedupe_strategy: e.target.value })} className="w-full text-xs">
                    <option value="validada">Preferir linha validada (Validado e OK / Logs = Sim)</option>
                    <option value="ultima">Última linha do arquivo</option>
                    <option value="primeira">Primeira linha do arquivo</option>
                  </Select>
                </label>
                <label className="flex items-center gap-2">
                  <input type="checkbox" checked={!!rules.not_started_requires_not_executed} onChange={(e) => setRules({ ...rules, not_started_requires_not_executed: e.target.checked })} />
                  “Não iniciado” exige status vazio <strong>e</strong> ausência em EXECUTADOS
                </label>
                <div>
                  <p className="mb-1 text-muted-foreground">Equivalência de status (valor da planilha → categoria)</p>
                  <MapEditor value={rules.status_map ?? {}} onChange={(m) => setRules({ ...rules, status_map: m })} valueOptions={STATUS_CANON} placeholderKey="ex.: Finalizado" defaults={settings.data?.defaults?.status_map} />
                </div>
                <div>
                  <p className="mb-1 text-muted-foreground">Equivalência de Tipo (valor da planilha → rótulo exibido)</p>
                  <MapEditor value={rules.tipo_map ?? {}} onChange={(m) => setRules({ ...rules, tipo_map: m })} placeholderKey="ex.: SUB-ESTAÇÃO" placeholderValue="ex.: SubEstação" defaults={settings.data?.defaults?.tipo_map} />
                </div>
                <Button size="sm" disabled={busy} onClick={() => setConfirm({ title: "Aplicar regras de negócio?", description: "Os indicadores serão recalculados com as novas regras. Os valores originais das planilhas não são alterados.", action: () => save({ rules }, "Regras atualizadas") })}>
                  <Save /> Salvar regras
                </Button>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Mapeamento manual de colunas</CardTitle>
            <CardDescription>Use quando um cabeçalho da planilha não for reconhecido automaticamente. Informe o texto exato do cabeçalho e o campo correspondente.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 text-xs">
            {mapping && (
              <>
                {(["inventario", "executados"] as const).map((sheet) => (
                  <div key={sheet}>
                    <p className="mb-1 font-medium">{sheet === "inventario" ? "Inventário_Ativos" : "EXECUTADOS"}</p>
                    <MapEditor value={mapping[sheet] ?? {}} onChange={(m) => setMapping({ ...mapping, [sheet]: m })} valueOptions={Object.entries(FIELD_LABELS)} placeholderKey="Cabeçalho na planilha" />
                  </div>
                ))}
                <Button size="sm" disabled={busy} onClick={() => setConfirm({ title: "Salvar mapeamento de colunas?", description: "O mapeamento será usado nas próximas importações.", action: () => save({ column_mapping: mapping }, "Mapeamento atualizado") })}>
                  <Save /> Salvar mapeamento
                </Button>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Preferências</CardTitle>
            <CardDescription>Aparência e formatos.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 text-xs">
            <label className="block">
              <span className="mb-1 block text-muted-foreground">Tema</span>
              <Select value={theme} onChange={(e) => setTheme(e.target.value as any)} className="w-full text-xs">
                <option value="system">Seguir o sistema</option>
                <option value="light">Claro</option>
                <option value="dark">Escuro</option>
              </Select>
            </label>
            {prefs && (
              <>
                <label className="block">
                  <span className="mb-1 block text-muted-foreground">Formato de datas</span>
                  <Select value={prefs.date_format} onChange={(e) => setPrefs({ ...prefs, date_format: e.target.value })} className="w-full text-xs">
                    <option value="DD/MM/YYYY">DD/MM/AAAA (pt-BR)</option>
                    <option value="YYYY-MM-DD">AAAA-MM-DD (ISO)</option>
                  </Select>
                </label>
                <Button size="sm" variant="outline" disabled={busy} onClick={() => save({ preferences: prefs }, "Preferências salvas")}>
                  <Save /> Salvar preferências
                </Button>
              </>
            )}
            <p className="text-[11px] text-muted-foreground">Versão da aplicação: <Badge className="bg-muted text-foreground ring-border">{meta.data?.version ?? "…"}</Badge></p>
          </CardContent>
        </Card>
      </div>

      <Dialog
        open={!!confirm}
        onClose={() => setConfirm(null)}
        title={confirm?.title ?? ""}
        description={confirm?.description}
        footer={
          <>
            <Button variant="outline" onClick={() => setConfirm(null)} disabled={busy}>
              Cancelar
            </Button>
            <Button onClick={() => confirm?.action()} disabled={busy}>
              Confirmar
            </Button>
          </>
        }
      />
    </div>
  );
}

function MapEditor({ value, onChange, valueOptions, placeholderKey, placeholderValue, defaults }: { value: Record<string, string>; onChange: (m: Record<string, string>) => void; valueOptions?: string[][]; placeholderKey?: string; placeholderValue?: string; defaults?: Record<string, string> }) {
  const [k, setK] = useState("");
  const [v, setV] = useState(valueOptions?.[0]?.[0] ?? "");
  const entries = Object.entries(value);
  return (
    <div className="rounded-lg border p-2">
      {entries.length === 0 && <p className="mb-1 text-muted-foreground">Nenhuma equivalência personalizada{defaults ? ` (${Object.keys(defaults).length} padrões internos ativos)` : ""}.</p>}
      <ul className="mb-2 space-y-1">
        {entries.map(([key, val]) => (
          <li key={key} className="flex items-center gap-2">
            <span className="flex-1 truncate font-mono">{key}</span>
            <span className="text-muted-foreground">→</span>
            <span className="flex-1 truncate">{valueOptions?.find((o) => o[0] === val)?.[1] ?? val}</span>
            <button className="text-muted-foreground hover:text-red-600" onClick={() => { const m = { ...value }; delete m[key]; onChange(m); }} aria-label="Remover">
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </li>
        ))}
      </ul>
      <div className="flex items-center gap-2">
        <Input value={k} onChange={(e) => setK(e.target.value)} placeholder={placeholderKey} className="h-8 flex-1 text-xs" />
        {valueOptions ? (
          <Select value={v} onChange={(e) => setV(e.target.value)} className="h-8 flex-1 text-xs">
            {valueOptions.map(([ok, ol]) => (
              <option key={ok} value={ok}>{ol}</option>
            ))}
          </Select>
        ) : (
          <Input value={v} onChange={(e) => setV(e.target.value)} placeholder={placeholderValue} className="h-8 flex-1 text-xs" />
        )}
        <Button size="sm" variant="outline" disabled={!k.trim() || !v} onClick={() => { onChange({ ...value, [k.trim()]: v }); setK(""); }}>
          <Plus /> Adicionar
        </Button>
      </div>
    </div>
  );
}

import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import Layout from "@/components/layout/Layout";
import { StoreProvider } from "@/lib/store";
import Executed from "@/pages/Executed";
import History from "@/pages/History";
import ImportPage from "@/pages/ImportPage";
import Inventory from "@/pages/Inventory";
import Overview from "@/pages/Overview";
import Reports from "@/pages/Reports";
import Settings from "@/pages/Settings";

export default function App() {
  return (
    <StoreProvider>
      <BrowserRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route index element={<Overview />} />
            <Route path="/executados" element={<Executed />} />
            <Route path="/inventario" element={<Inventory />} />
            <Route path="/importar" element={<ImportPage />} />
            <Route path="/relatorios" element={<Reports />} />
            <Route path="/historico" element={<History />} />
            <Route path="/configuracoes" element={<Settings />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </StoreProvider>
  );
}

import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const fmtInt = (n: number | null | undefined) => (n === null || n === undefined ? "—" : n.toLocaleString("pt-BR"));
export const fmtPct = (n: number | null | undefined, digits = 2) =>
  n === null || n === undefined ? "—" : `${n.toLocaleString("pt-BR", { minimumFractionDigits: digits, maximumFractionDigits: digits })}%`;

export function fmtDate(value: string | null | undefined, withTime = true): string {
  if (!value) return "—";
  const d = new Date(value.replace(" ", "T"));
  if (isNaN(d.getTime())) return value;
  return withTime ? d.toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" }) : d.toLocaleDateString("pt-BR");
}

export const fmtBytes = (b: number | null | undefined) => {
  if (!b && b !== 0) return "—";
  if (b < 1024) return `${b} B`;
  if (b < 1024 * 1024) return `${(b / 1024).toFixed(1)} KB`;
  return `${(b / 1024 / 1024).toFixed(2)} MB`;
};

export const NOT_INFORMED = "Não informado";
export const show = (v: any) => (v === null || v === undefined || v === "" ? NOT_INFORMED : String(v));

/** Status canonical -> tailwind classes (badge). */
export function statusClasses(canon: string | undefined): string {
  switch (canon) {
    case "concluido":
      return "bg-emerald-50 text-emerald-700 ring-emerald-200 dark:bg-emerald-500/10 dark:text-emerald-300 dark:ring-emerald-500/30";
    case "em_andamento":
      return "bg-amber-50 text-amber-700 ring-amber-200 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-500/30";
    case "pendente":
      return "bg-orange-50 text-orange-700 ring-orange-200 dark:bg-orange-500/10 dark:text-orange-300 dark:ring-orange-500/30";
    case "bloqueado":
      return "bg-red-50 text-red-700 ring-red-200 dark:bg-red-500/10 dark:text-red-300 dark:ring-red-500/30";
    default:
      return "bg-muted text-muted-foreground ring-border";
  }
}

export function yesNoClasses(v: string | null | undefined): string {
  if (v === "Sim") return "text-emerald-600 dark:text-emerald-400";
  if (v === "Não") return "text-red-600 dark:text-red-400";
  if (v === "N/A") return "text-muted-foreground";
  return "text-muted-foreground italic";
}

export const FIELD_LABELS: Record<string, string> = {
  id: "ID",
  name: "Nome do Ativo",
  hostname: "Nome do Ativo / Hostname",
  zabbix: "Nome do Ativo / Zabbix",
  model: "Fabricante / Modelo",
  ip: "IP",
  onda: "Onda",
  regiao: "Região",
  estado: "Estado",
  cidade: "Cidade",
  tipo: "Tipo",
  criticidade: "Criticidade",
  status: "Status Implementação",
  coletor: "Coletor",
  porta: "Porta",
  descoberta: "Descoberta",
  coleta_config: "Coleta Config.",
  logs_siem: "Logs no SIEM?",
  mudanca: "Mudança",
  data_prevista: "Data Prevista",
  data_real: "Data Real",
  responsavel: "Responsável",
  validar_evidencia: "Validar Evidência",
  observacoes: "Observações",
};

export const CHANGE_LABELS: Record<string, string> = {
  new_asset: "Novo ativo",
  new_execution: "Executado pela primeira vez",
  status_change: "Alteração de status",
  field_change: "Alteração de campo",
  missing_asset: "Ausente no inventário do arquivo",
  missing_execution: "Ausente em EXECUTADOS do arquivo",
  conflict: "Divergência entre abas",
  duplicate: "ID duplicado",
  orphan: "Executado sem inventário",
};

export const COLORS = {
  blue: "#2563EB",
  purple: "#7C3AED",
  green: "#16A34A",
  amber: "#D97706",
  red: "#DC2626",
  gray: "#9CA3AF",
};

/* Global application state: filters, theme, toasts, data-version (refresh after import). */
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { emptyFilters, type FilterState } from "./api";

type Theme = "light" | "dark" | "system";

interface Toast {
  id: number;
  title: string;
  description?: string;
  variant?: "default" | "success" | "error";
}

interface Store {
  filters: FilterState;
  setFilters: (f: FilterState | ((prev: FilterState) => FilterState)) => void;
  setFilterValues: (field: string, values: string[]) => void;
  clearFilters: () => void;
  activeFilterCount: number;
  theme: Theme;
  setTheme: (t: Theme) => void;
  dataVersion: number;
  bumpData: () => void;
  toasts: Toast[];
  toast: (t: Omit<Toast, "id">) => void;
  dismissToast: (id: number) => void;
}

const Ctx = createContext<Store | null>(null);

function readTheme(): Theme {
  try {
    const t = localStorage.getItem("siem-theme");
    if (t === "light" || t === "dark" || t === "system") return t;
  } catch {
    /* ignore */
  }
  return "system";
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [filters, setFiltersState] = useState<FilterState>(emptyFilters());
  const [theme, setThemeState] = useState<Theme>(readTheme);
  const [dataVersion, setDataVersion] = useState(0);
  const [toasts, setToasts] = useState<Toast[]>([]);

  useEffect(() => {
    const root = document.documentElement;
    const apply = () => {
      const dark = theme === "dark" || (theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
      root.classList.toggle("dark", dark);
    };
    apply();
    try {
      localStorage.setItem("siem-theme", theme);
    } catch {
      /* ignore */
    }
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, [theme]);

  const setFilters = useCallback((f: FilterState | ((prev: FilterState) => FilterState)) => {
    setFiltersState((prev) => (typeof f === "function" ? f(prev) : f));
  }, []);
  const setFilterValues = useCallback((field: string, values: string[]) => {
    setFiltersState((prev) => {
      const next = { ...prev, values: { ...prev.values } };
      if (values.length) next.values[field] = values;
      else delete next.values[field];
      return next;
    });
  }, []);
  const clearFilters = useCallback(() => setFiltersState(emptyFilters()), []);
  const activeFilterCount = useMemo(
    () => Object.values(filters.values).filter((v) => v.length).length + (filters.q ? 1 : 0),
    [filters],
  );

  const toast = useCallback((t: Omit<Toast, "id">) => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { ...t, id }]);
    setTimeout(() => setToasts((prev) => prev.filter((x) => x.id !== id)), 5000);
  }, []);
  const dismissToast = useCallback((id: number) => setToasts((prev) => prev.filter((x) => x.id !== id)), []);

  const value: Store = {
    filters,
    setFilters,
    setFilterValues,
    clearFilters,
    activeFilterCount,
    theme,
    setTheme: setThemeState,
    dataVersion,
    bumpData: () => setDataVersion((v) => v + 1),
    toasts,
    toast,
    dismissToast,
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore(): Store {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useStore must be used inside StoreProvider");
  return ctx;
}

/** Generic async loader with loading/error state that re-runs when deps change. */
export function useAsync<T>(fn: () => Promise<T>, deps: unknown[]): { data: T | null; loading: boolean; error: string | null; reload: () => void } {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let alive = true;
    setLoading(true);
    setError(null);
    fn()
      .then((d) => {
        if (alive) setData(d);
      })
      .catch((e: Error) => {
        if (alive) setError(e.message || "Erro ao carregar dados");
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick]);
  return { data, loading, error, reload: () => setTick((t) => t + 1) };
}

/* Typed client for the SIEM Firewalls API (same origin, /api). */

export type Rec = Record<string, any>;

export interface Cards {
  total_assets: number;
  total_executed: number;
  pct_executed: number;
  new_executed_last_import: number;
  executed_concluded: number;
  executed_not_concluded: number;
  not_executed: number;
  concluded_inventory: number;
  concluded_inventory_raw: number;
  concluded_executed: number;
  in_progress: number;
  pending: number;
  blocked: number;
  not_started: number;
  executed_with_pendencies: number;
  conflicts: number;
  orphans: number;
  missing_from_last_file: number;
}

export interface DistRow {
  label: string;
  total: number;
  executed: number;
  remaining: number;
  executed_concluded: number;
  pct: number;
}

export interface EvolutionPoint {
  import_id: number;
  date: string;
  reference_date: string | null;
  file_name: string;
  total_assets: number;
  total_executed: number;
  new_executed: number;
  pct_executed: number;
  total_concluded: number;
}

export interface Indicators {
  universe_filtered: boolean;
  filters_description: string;
  last_import_id: number | null;
  cards: Cards;
  distributions: Record<"estado" | "regiao" | "onda" | "status" | "tipo" | "criticidade", DistRow[]>;
  pendencies: { key: string; label: string; count: number }[];
  evolution?: EvolutionPoint[];
}

export interface Page<T = Rec> {
  items: T[];
  total: number;
  page: number;
  page_size: number;
  pages: number;
  [k: string]: any;
}

export interface ImportInfo {
  id: number;
  file_name: string;
  file_hash: string;
  size_bytes: number;
  created_at: string;
  reference_date: string | null;
  status: string;
  total_assets: number;
  total_executed: number;
  new_assets: number;
  new_executed: number;
  total_concluded: number;
  total_pending: number;
  total_blocked: number;
  pct_executed: number;
  summary: Rec;
  warnings: string[];
  rules: Rec;
}

export interface FilterState {
  values: Record<string, string[]>;
  q?: string;
  executed?: boolean | null;
  pendency?: string | null;
  has_conflict?: boolean | null;
}

export const emptyFilters = (): FilterState => ({ values: {} });

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

async function handle<T>(res: Response): Promise<T> {
  if (!res.ok) {
    let msg = `Erro ${res.status}`;
    try {
      const body = await res.json();
      if (body?.detail) msg = typeof body.detail === "string" ? body.detail : JSON.stringify(body.detail);
    } catch {
      /* ignore */
    }
    throw new ApiError(res.status, msg);
  }
  return (await res.json()) as T;
}

export function filtersToParams(f: FilterState, extra: Record<string, any> = {}): URLSearchParams {
  const p = new URLSearchParams();
  for (const [k, vals] of Object.entries(f.values || {})) {
    if (vals && vals.length) p.set(k === "model" ? "modelo" : k, vals.join("|"));
  }
  if (f.q) p.set("q", f.q);
  if (f.executed === true || f.executed === false) p.set("executed", String(f.executed));
  if (f.pendency) p.set("pendency", f.pendency);
  if (f.has_conflict === true || f.has_conflict === false) p.set("has_conflict", String(f.has_conflict));
  for (const [k, v] of Object.entries(extra)) if (v !== undefined && v !== null && v !== "") p.set(k, String(v));
  return p;
}

const get = <T,>(url: string) => fetch(url).then((r) => handle<T>(r));

export const api = {
  health: () => get<{ status: string; version: string }>("/api/health"),
  meta: () => get<Rec>("/api/meta"),
  indicators: (f: FilterState) => get<Indicators>(`/api/indicators?${filtersToParams(f)}`),
  filterOptions: () =>
    get<{ fields: string[]; labels: Record<string, string>; options: Record<string, string[]>; pendencies: Record<string, string> }>(
      "/api/filters/options",
    ),
  assets: (f: FilterState, extra: Rec) => get<Page>(`/api/assets?${filtersToParams(f, extra)}`),
  asset: (id: string) => get<Rec>(`/api/assets/${encodeURIComponent(id)}`),
  executions: (f: FilterState, extra: Rec) => get<Page>(`/api/executions?${filtersToParams(f, extra)}`),
  pendencies: (f: FilterState, extra: Rec) => get<Page>(`/api/executions/pendencies?${filtersToParams(f, extra)}`),
  imports: () => get<ImportInfo[]>("/api/imports"),
  importDetail: (id: number, params: Rec = {}) => get<Rec>(`/api/imports/${id}?${new URLSearchParams(params)}`),
  importIndicators: (id: number, f: FilterState) => get<Indicators & { import: ImportInfo }>(`/api/imports/${id}/indicators?${filtersToParams(f)}`),
  compare: (a: number, b: number) => get<Rec>(`/api/imports/compare?a=${a}&b=${b}`),
  previewImport: (file: File) => {
    const fd = new FormData();
    fd.append("file", file);
    return fetch("/api/imports/preview", { method: "POST", body: fd }).then((r) => handle<Rec>(r));
  },
  confirmImport: (token: string, referenceDate?: string, force = false) => {
    const fd = new FormData();
    if (referenceDate) fd.append("reference_date", referenceDate);
    fd.append("force", String(force));
    return fetch(`/api/imports/${token}/confirm`, { method: "POST", body: fd }).then((r) => handle<ImportInfo>(r));
  },
  discardImport: (token: string) => fetch(`/api/imports/${token}`, { method: "DELETE" }).then((r) => handle<Rec>(r)),
  reportColumns: () => get<{ default: string[]; all: { key: string; label: string }[] }>("/api/reports/columns"),
  reportHistory: () => get<Rec[]>("/api/reports/history"),
  settings: () => get<Rec>("/api/settings"),
  updateSettings: (body: Rec) =>
    fetch("/api/settings", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then((r) =>
      handle<Rec>(r),
    ),
  backups: () => get<{ dir: string; items: Rec[] }>("/api/backups"),
  createBackup: () => fetch("/api/backups", { method: "POST" }).then((r) => handle<Rec>(r)),
  restoreBackup: (file: File | null, path: string | null) => {
    const fd = new FormData();
    if (file) fd.append("file", file);
    if (path) fd.append("path", path);
    fd.append("confirm", "true");
    return fetch("/api/backups/restore", { method: "POST", body: fd }).then((r) => handle<Rec>(r));
  },
};

/** POST that returns a file and triggers the browser download. */
export async function downloadReport(kind: "pdf" | "excel", body: Rec): Promise<string> {
  const res = await fetch(`/api/reports/${kind}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    let msg = `Erro ${res.status}`;
    try {
      msg = (await res.json()).detail || msg;
    } catch {
      /* ignore */
    }
    throw new ApiError(res.status, msg);
  }
  const blob = await res.blob();
  const cd = res.headers.get("Content-Disposition") || "";
  let name = kind === "pdf" ? "relatorio.pdf" : "relatorio.xlsx";
  const m = /filename\*=UTF-8''([^;]+)/.exec(cd) || /filename="?([^";]+)"?/.exec(cd);
  if (m) name = decodeURIComponent(m[1]);
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  return name;
}

export function filterBody(f: FilterState): Rec {
  return {
    values: f.values,
    q: f.q || null,
    executed: f.executed ?? null,
    pendency: f.pendency ?? null,
    has_conflict: f.has_conflict ?? null,
  };
}

@echo off
setlocal
chcp 65001 >nul
title SIEM Firewalls - Desenvolvimento
cd /d "%~dp0"
echo Iniciando backend (http://127.0.0.1:8000) e frontend com hot-reload (http://127.0.0.1:5173)...
start "SIEM Firewalls - API" cmd /k "cd backend && .venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload"
start "SIEM Firewalls - Frontend" cmd /k "cd frontend && npm run dev"
endlocal
